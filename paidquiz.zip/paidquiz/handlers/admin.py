import io
import csv
from datetime import datetime
from aiogram import Router, F, types
from aiogram.filters import StateFilter
from aiogram.fsm.context import FSMContext
from aiogram.types import Message, CallbackQuery, InputFile

from db.mongo import get_db
from keyboards.inline import (
    get_admin_main_keyboard, get_quiz_manage_keyboard,
    get_admin_list_keyboard, get_back_to_admin_keyboard,
    get_quiz_list_keyboard
)
from states.admin_states import AdminStates
from utils.helpers import is_admin, is_super_admin
from utils.json_loader import load_questions_from_json
from services.quiz_service import update_quiz_status
from services.payment_service import get_total_earnings, get_today_earnings

router = Router()

@router.message(CommandStart())
async def admin_start(message: Message):
    if not await is_admin(message.from_user.id):
        return
    await message.answer("Admin Panel", reply_markup=get_admin_main_keyboard())

@router.callback_query(F.data == "admin_panel")
async def admin_panel(callback: CallbackQuery):
    if not await is_admin(callback.from_user.id):
        await callback.answer("Access denied.")
        return
    await callback.message.edit_text("Admin Panel", reply_markup=get_admin_main_keyboard())

# ---------- Add Quiz ----------
@router.callback_query(F.data == "add_quiz")
async def add_quiz(callback: CallbackQuery, state: FSMContext):
    if not await is_admin(callback.from_user.id):
        return
    await callback.message.edit_text("Enter quiz ID (unique):")
    await state.set_state(AdminStates.waiting_quiz_id)

@router.message(StateFilter(AdminStates.waiting_quiz_id))
async def process_quiz_id(message: Message, state: FSMContext):
    quiz_id = message.text.strip()
    db = get_db()
    existing = await db.quizzes.find_one({"quiz_id": quiz_id})
    if existing:
        await message.answer("Quiz ID already exists. Choose another:")
        return
    await state.update_data(quiz_id=quiz_id)
    await message.answer("Enter quiz title:")
    await state.set_state(AdminStates.waiting_quiz_title)

@router.message(StateFilter(AdminStates.waiting_quiz_title))
async def process_quiz_title(message: Message, state: FSMContext):
    title = message.text.strip()
    await state.update_data(title=title)
    await message.answer("Enter quiz description (optional):")
    await state.set_state(AdminStates.waiting_quiz_description)

@router.message(StateFilter(AdminStates.waiting_quiz_description))
async def process_quiz_description(message: Message, state: FSMContext):
    description = message.text.strip() if message.text else ""
    await state.update_data(description=description)
    await message.answer("Enter price in INR:")
    await state.set_state(AdminStates.waiting_quiz_price)

@router.message(StateFilter(AdminStates.waiting_quiz_price))
async def process_quiz_price(message: Message, state: FSMContext):
    try:
        price = int(message.text.strip())
    except:
        await message.answer("Invalid number. Enter price in INR:")
        return
    await state.update_data(price=price)
    await message.answer("Time per question (seconds, default 30):")
    await state.set_state(AdminStates.waiting_quiz_time)

@router.message(StateFilter(AdminStates.waiting_quiz_time))
async def process_quiz_time(message: Message, state: FSMContext):
    try:
        t = int(message.text.strip())
    except:
        t = 30
    data = await state.get_data()
    quiz_data = {
        "quiz_id": data['quiz_id'],
        "title": data['title'],
        "description": data.get('description', ''),
        "price": data['price'],
        "time_per_question": t,
        "question_order": "fixed",
        "status": "created"
    }
    db = get_db()
    await db.quizzes.insert_one(quiz_data)
    await message.answer(f"Quiz {quiz_data['quiz_id']} created successfully.", reply_markup=get_admin_main_keyboard())
    await state.clear()

# ---------- Manage Questions ----------
@router.callback_query(F.data == "manage_questions")
async def manage_questions(callback: CallbackQuery):
    if not await is_admin(callback.from_user.id):
        return
    db = get_db()
    quizzes = await db.quizzes.find({}, {"quiz_id": 1, "title": 1}).to_list(100)
    if not quizzes:
        await callback.message.edit_text("No quizzes found. Add one first.", reply_markup=get_admin_main_keyboard())
        return
    await callback.message.edit_text(
        "Select quiz to manage questions:",
        reply_markup=get_quiz_manage_keyboard(quizzes)
    )

@router.callback_query(F.data.startswith("quiz_manage_"))
async def quiz_manage(callback: CallbackQuery, state: FSMContext):
    quiz_id = callback.data.split("_")[2]
    await state.update_data(quiz_id=quiz_id)
    await callback.message.edit_text(
        "Options:\n"
        "- Upload JSON file\n"
        "- Delete all questions\n"
        "- View count\n"
        "- Shuffle ON/OFF (toggle)\n\n"
        "Send me a JSON file to upload questions.",
        reply_markup=get_back_to_admin_keyboard()
    )
    await state.set_state(AdminStates.waiting_questions_file)

@router.message(StateFilter(AdminStates.waiting_questions_file), F.document)
async def handle_questions_file(message: Message, state: FSMContext):
    document = message.document
    if not document.file_name.endswith('.json'):
        await message.answer("Please send a JSON file.")
        return
    file = await message.bot.get_file(document.file_id)
    file_bytes = await message.bot.download_file(file.file_path)
    content = file_bytes.read().decode('utf-8')
    data = await state.get_data()
    quiz_id = data['quiz_id']
    success, msg = await load_questions_from_json(content, quiz_id)
    if success:
        await message.answer(f"Questions uploaded successfully. {msg}")
    else:
        await message.answer(f"Failed: {msg}")
    await state.clear()
    await message.answer("Back to admin panel.", reply_markup=get_admin_main_keyboard())

# ---------- Start Quiz ----------
@router.callback_query(F.data == "start_quiz")
async def start_quiz(callback: CallbackQuery, state: FSMContext):
    if not await is_admin(callback.from_user.id):
        return
    db = get_db()
    quizzes = await db.quizzes.find({"status": "created"}).to_list(100)
    if not quizzes:
        await callback.answer("No quizzes ready to start.")
        return
    await callback.message.edit_text(
        "Select quiz to start:",
        reply_markup=get_quiz_list_keyboard(quizzes, action="start")
    )
    await state.set_state(AdminStates.waiting_quiz_start)

@router.callback_query(StateFilter(AdminStates.waiting_quiz_start), F.data.startswith("quiz_start_"))
async def process_start_quiz(callback: CallbackQuery, state: FSMContext):
    quiz_id = callback.data.split("_")[2]
    db = get_db()
    count = await db.questions.count_documents({"quiz_id": quiz_id})
    if count == 0:
        await callback.answer("Cannot start quiz with no questions.", show_alert=True)
        return
    await update_quiz_status(quiz_id, "active")
    await callback.message.edit_text(f"Quiz {quiz_id} started!", reply_markup=get_admin_main_keyboard())
    await state.clear()

# ---------- Stop Quiz ----------
@router.callback_query(F.data == "stop_quiz")
async def stop_quiz(callback: CallbackQuery, state: FSMContext):
    if not await is_admin(callback.from_user.id):
        return
    db = get_db()
    quizzes = await db.quizzes.find({"status": "active"}).to_list(100)
    if not quizzes:
        await callback.answer("No active quizzes.")
        return
    await callback.message.edit_text(
        "Select quiz to stop:",
        reply_markup=get_quiz_list_keyboard(quizzes, action="stop")
    )
    await state.set_state(AdminStates.waiting_quiz_stop)

@router.callback_query(StateFilter(AdminStates.waiting_quiz_stop), F.data.startswith("quiz_stop_"))
async def process_stop_quiz(callback: CallbackQuery, state: FSMContext):
    quiz_id = callback.data.split("_")[2]
    await update_quiz_status(quiz_id, "completed")
    await callback.message.edit_text(f"Quiz {quiz_id} stopped.", reply_markup=get_admin_main_keyboard())
    await state.clear()

# ---------- Broadcast ----------
@router.callback_query(F.data == "broadcast_menu")
async def broadcast_menu(callback: CallbackQuery):
    if not await is_admin(callback.from_user.id):
        return
    from keyboards.inline import get_broadcast_keyboard
    await callback.message.edit_text("Broadcast options:", reply_markup=get_broadcast_keyboard())

# ---------- Stats & Earnings ----------
@router.callback_query(F.data == "stats_earnings")
async def stats_earnings(callback: CallbackQuery):
    if not await is_admin(callback.from_user.id):
        return
    db = get_db()
    total_users = await db.users.count_documents({})
    total_quizzes = await db.quizzes.count_documents({})
    total_earnings = await get_total_earnings()
    today_earnings = await get_today_earnings()
    payments_breakdown = await db.payments.aggregate([
        {"$match": {"status": "paid"}},
        {"$group": {"_id": "$quiz_id", "count": {"$sum": 1}, "total": {"$sum": "$amount"}}}
    ]).to_list(100)
    text = (
        f"📊 <b>Stats & Earnings</b>\n"
        f"Total users: {total_users}\n"
        f"Total quizzes: {total_quizzes}\n"
        f"Total earnings: ₹{total_earnings}\n"
        f"Today earnings: ₹{today_earnings}\n\n"
        f"<b>Per Quiz:</b>\n"
    )
    for item in payments_breakdown:
        text += f"- {item['_id']}: {item['count']} payments, ₹{item['total']}\n"
    from keyboards.inline import get_export_csv_keyboard
    await callback.message.edit_text(text, reply_markup=get_export_csv_keyboard())

@router.callback_query(F.data == "export_csv")
async def export_csv(callback: CallbackQuery):
    if not await is_admin(callback.from_user.id):
        return
    db = get_db()
    payments = await db.payments.find({"status": "paid"}).to_list(1000)
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["Payment ID", "User ID", "Quiz ID", "Amount", "Created At", "Verified At"])
    for p in payments:
        writer.writerow([p['payment_id'], p['user_id'], p['quiz_id'], p['amount'], p['created_at'], p.get('verified_at', '')])
    csv_bytes = output.getvalue().encode()
    await callback.message.answer_document(
        InputFile(io.BytesIO(csv_bytes), filename="payments.csv"),
        caption="Payments export"
    )

# ---------- Manage Admin ----------
@router.callback_query(F.data == "manage_admin")
async def manage_admin(callback: CallbackQuery):
    if not await is_super_admin(callback.from_user.id):
        await callback.answer("Only super admin can manage admins.")
        return
    db = get_db()
    admins = await db.admins.find().to_list(100)
    await callback.message.edit_text(
        "Manage Admins:",
        reply_markup=get_admin_list_keyboard(admins)
    )

@router.callback_query(F.data.startswith("admin_add_"))
async def admin_add_prompt(callback: CallbackQuery, state: FSMContext):
    await callback.message.edit_text("Send me the Telegram user ID of the new admin:")
    await state.set_state(AdminStates.waiting_new_admin_id)

@router.message(StateFilter(AdminStates.waiting_new_admin_id))
async def process_new_admin(message: Message, state: FSMContext):
    try:
        new_id = int(message.text.strip())
    except:
        await message.answer("Invalid ID. Enter a numeric user ID.")
        return
    db = get_db()
    user = await db.users.find_one({"user_id": new_id})
    if not user:
        await message.answer("User has not started the bot yet. Ask them to send /start first.")
        return
    existing = await db.admins.find_one({"user_id": new_id})
    if existing:
        await message.answer("User is already an admin.")
        await state.clear()
        return
    await db.admins.insert_one({"user_id": new_id, "role": "admin", "added_by": message.from_user.id})
    await message.answer(f"User {new_id} added as admin.", reply_markup=get_admin_main_keyboard())
    await state.clear()

@router.callback_query(F.data.startswith("admin_remove_"))
async def admin_remove(callback: CallbackQuery):
    user_id = int(callback.data.split("_")[2])
    db = get_db()
    await db.admins.delete_one({"user_id": user_id})
    await callback.answer(f"Admin {user_id} removed.")
    await manage_admin(callback)

# ---------- Admin Help ----------
@router.callback_query(F.data == "admin_help")
async def admin_help(callback: CallbackQuery):
    help_text = (
        "ℹ️ <b>Admin Help</b>\n"
        "Use the buttons to manage quizzes, questions, broadcasts, and admins.\n"
        "Super admins can add/remove admins.\n"
        "CSV export available in stats."
    )
    await callback.message.edit_text(help_text, reply_markup=get_admin_main_keyboard())