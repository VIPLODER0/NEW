import uuid
from datetime import datetime, timedelta
from aiogram import Router, F
from aiogram.types import CallbackQuery, Message
from aiogram.fsm.context import FSMContext

from config import PAYMENT_EXPIRY_MINUTES
from db.mongo import get_db
from keyboards.inline import (
    get_razorpay_payment_keyboard,
    get_quiz_start_keyboard,
    get_user_main_keyboard
)
from services.payment_service import has_user_paid, verify_razorpay_payment
from services.razorpay_client import create_order_async
from states.payment_states import PaymentWaiting

router = Router()

@router.callback_query(F.data.startswith("pay_"))
async def initiate_payment(callback: CallbackQuery, state: FSMContext):
    parts = callback.data.split("_")
    if len(parts) != 3:
        await callback.answer("Invalid data")
        return
    quiz_id = parts[1]
    amount = int(parts[2])

    db = get_db()
    user_id = callback.from_user.id

    if await has_user_paid(db, user_id, quiz_id):
        await callback.answer("You already have access to this quiz.", show_alert=True)
        return

    try:
        order = await create_order_async(amount)
    except Exception as e:
        await callback.message.edit_text(
            "Payment service temporarily unavailable. Please try later.",
            reply_markup=get_user_main_keyboard()
        )
        return

    order_id = order["id"]

    payment_record = {
        "payment_id": order_id,
        "user_id": user_id,
        "quiz_id": quiz_id,
        "amount": amount,
        "status": "pending",
        "created_at": datetime.utcnow(),
        "expires_at": datetime.utcnow() + timedelta(minutes=PAYMENT_EXPIRY_MINUTES),
        "razorpay_order_id": order_id,
        "razorpay_payment_id": None,
        "razorpay_signature": None
    }
    await db.payments.insert_one(payment_record)

    # In production, you would generate a proper checkout link.
    # For demo, we use a placeholder link.
    payment_link = f"https://rzp.io/i/{order_id}"   # Replace with your actual checkout URL

    await callback.message.edit_text(
        f"💳 <b>Payment for Quiz {quiz_id}</b>\n"
        f"Amount: ₹{amount}\n\n"
        f"Click the button below to complete payment.\n"
        f"After successful payment, come back and click 'I have paid'.",
        reply_markup=get_razorpay_payment_keyboard(payment_link, order_id)
    )
    await state.set_state(PaymentWaiting.verification)
    await state.update_data(payment_id=order_id, quiz_id=quiz_id)

@router.callback_query(PaymentWaiting.verification, F.data.startswith("verify_pay_"))
async def verify_payment_prompt(callback: CallbackQuery, state: FSMContext):
    payment_id = callback.data.split("_")[2]
    await state.update_data(order_id=payment_id)
    await callback.message.edit_text(
        "Please send me the <b>Razorpay Payment ID</b> that you received after successful payment.\n"
        "It looks like: <code>pay_123456789</code>"
    )
    await state.set_state(PaymentWaiting.waiting_payment_id)

@router.message(PaymentWaiting.waiting_payment_id)
async def receive_payment_id(message: Message, state: FSMContext):
    data = await state.get_data()
    order_id = data['order_id']
    quiz_id = data.get('quiz_id')
    razorpay_payment_id = message.text.strip()

    db = get_db()

    payment = await db.payments.find_one({"payment_id": order_id})
    if not payment or payment['status'] != 'pending':
        await message.answer("Invalid or already processed payment.")
        await state.clear()
        return

    is_valid = await verify_razorpay_payment(order_id, razorpay_payment_id)

    if not is_valid:
        await message.answer(
            "❌ Verification failed. Please make sure you sent the correct Payment ID.\n"
            "If you think this is a mistake, contact admin."
        )
        return

    await db.payments.update_one(
        {"payment_id": order_id},
        {"$set": {
            "status": "paid",
            "razorpay_payment_id": razorpay_payment_id,
            "verified_at": datetime.utcnow()
        }}
    )

    await message.answer(
        "✅ Payment successful! You can now start the quiz.",
        reply_markup=get_quiz_start_keyboard(quiz_id)
    )
    await state.clear()