from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.filters import CommandStart
from keyboards.inline import (
    get_user_main_keyboard, get_quiz_list_keyboard,
    get_payment_keyboard, get_quiz_start_keyboard
)
from db.mongo import get_db
from utils.helpers import get_user
from services.payment_service import has_user_paid
from services.quiz_service import get_active_quizzes

router = Router()

@router.message(CommandStart())
async def cmd_start(message: Message):
    db = get_db()
    user = await get_user(db, message.from_user)
    await message.answer(
        f"👋 Welcome {user.first_name}!\n\nChoose an option below:",
        reply_markup=get_user_main_keyboard()
    )

@router.callback_query(F.data == "back_to_main")
async def back_to_main(callback: CallbackQuery):
    await callback.message.edit_text(
        "Main Menu:",
        reply_markup=get_user_main_keyboard()
    )

@router.callback_query(F.data == "join_quiz")
async def join_quiz(callback: CallbackQuery):
    db = get_db()
    quizzes = await get_active_quizzes(db)
    if not quizzes:
        await callback.message.edit_text(
            "No quizzes available at the moment.",
            reply_markup=get_user_main_keyboard()
        )
        return
    await callback.message.edit_text(
        "Select a quiz to join:",
        reply_markup=get_quiz_list_keyboard(quizzes)
    )

@router.callback_query(F.data.startswith("quiz_select_"))
async def quiz_selected(callback: CallbackQuery):
    db = get_db()
    quiz_id = callback.data.split("_")[2]
    user_id = callback.from_user.id

    if await has_user_paid(db, user_id, quiz_id):
        await callback.message.edit_text(
            "You have already paid. Ready to start the quiz?",
            reply_markup=get_quiz_start_keyboard(quiz_id)
        )
    else:
        quiz = await db.quizzes.find_one({"quiz_id": quiz_id})
        if not quiz:
            await callback.answer("Quiz not found.")
            return
        await callback.message.edit_text(
            f"You need to pay ₹{quiz['price']} to join this quiz.\n"
            f"Choose payment method:",
            reply_markup=get_payment_keyboard(quiz_id, quiz['price'])
        )

@router.callback_query(F.data == "quiz_rules")
async def quiz_rules(callback: CallbackQuery):
    rules_text = (
        "📋 <b>Quiz Rules</b>\n"
        "- Each question has a time limit (default 30 seconds).\n"
        "- You can select only one answer.\n"
        "- If time runs out or you skip, it's counted as wrong.\n"
        "- Correct answers are not shown during the quiz.\n"
        "- After the quiz ends, you can see your score and rank.\n"
        "- You must pay to join a quiz."
    )
    await callback.message.edit_text(rules_text, reply_markup=get_user_main_keyboard())

@router.callback_query(F.data == "my_result")
async def my_result(callback: CallbackQuery):
    db = get_db()
    user_id = callback.from_user.id
    last_answer = await db.answers.find_one({"user_id": user_id}, sort=[("answered_at", -1)])
    if not last_answer:
        await callback.answer("You haven't taken any quiz yet.", show_alert=True)
        return
    quiz_id = last_answer['quiz_id']
    total_q = await db.questions.count_documents({"quiz_id": quiz_id})
    correct = await db.answers.count_documents({"user_id": user_id, "quiz_id": quiz_id, "is_correct": True})
    wrong = total_q - correct
    score = correct

    pipeline = [
        {"$match": {"quiz_id": quiz_id, "is_correct": True}},
        {"$group": {"_id": "$user_id", "score": {"$sum": 1}}},
        {"$sort": {"score": -1}}
    ]
    rankings = await db.answers.aggregate(pipeline).to_list(None)
    rank = 1
    for i, r in enumerate(rankings):
        if r['_id'] == user_id:
            rank = i+1
            break

    await callback.message.edit_text(
        f"📊 <b>Your Result for Quiz {quiz_id}</b>\n"
        f"Total Questions: {total_q}\n"
        f"✅ Correct: {correct}\n"
        f"❌ Wrong: {wrong}\n"
        f"⭐ Score: {score}\n"
        f"🏆 Rank: {rank}",
        reply_markup=get_user_main_keyboard()
    )

@router.callback_query(F.data == "leaderboard")
async def leaderboard(callback: CallbackQuery):
    db = get_db()
    pipeline = [
        {"$match": {"is_correct": True}},
        {"$group": {"_id": "$user_id", "score": {"$sum": 1}}},
        {"$sort": {"score": -1}},
        {"$limit": 3}
    ]
    top_users = await db.answers.aggregate(pipeline).to_list(None)
    text = "🏆 <b>Leaderboard</b>\n\n"
    if not top_users:
        text += "No data yet."
    else:
        for i, user in enumerate(top_users, 1):
            user_info = await db.users.find_one({"user_id": user['_id']})
            name = user_info.get('first_name', 'Unknown') if user_info else 'Unknown'
            text += f"{i}. {name} – {user['score']} points\n"
    await callback.message.edit_text(text, reply_markup=get_user_main_keyboard())

@router.callback_query(F.data == "payment_status")
async def payment_status(callback: CallbackQuery):
    db = get_db()
    user_id = callback.from_user.id
    payments = await db.payments.find({"user_id": user_id}).sort("created_at", -1).to_list(5)
    if not payments:
        await callback.answer("No payment records found.", show_alert=True)
        return
    text = "💳 <b>Recent Payments</b>\n"
    for p in payments:
        status_emoji = {"paid": "✅", "pending": "⏳", "failed": "❌", "expired": "⌛"}
        emoji = status_emoji.get(p['status'], "❓")
        text += f"\n{emoji} Quiz: {p['quiz_id']} – ₹{p['amount']} ({p['status'].upper()})"
    await callback.message.edit_text(text, reply_markup=get_user_main_keyboard())

@router.callback_query(F.data == "help_user")
async def help_user(callback: CallbackQuery):
    help_text = (
        "ℹ️ <b>Help</b>\n"
        "Use the buttons below to navigate.\n"
        "If you face any issues, contact admin.\n"
        "Bot is fully button-based – no commands needed."
    )
    await callback.message.edit_text(help_text, reply_markup=get_user_main_keyboard())