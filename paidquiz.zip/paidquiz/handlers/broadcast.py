import asyncio
import uuid
import logging
from datetime import datetime
from aiogram import Router, F, Bot
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext
from aiogram.exceptions import TelegramRetryAfter, TelegramForbiddenError

from db.mongo import get_db
from keyboards.inline import get_broadcast_target_keyboard, get_broadcast_confirm_keyboard
from states.admin_states import BroadcastStates
from services.broadcast_service import get_all_users, get_paid_users
from utils.helpers import is_admin

router = Router()

@router.callback_query(F.data == "broadcast_new")
async def broadcast_new(callback: CallbackQuery, state: FSMContext):
    if not await is_admin(callback.from_user.id):
        return
    await callback.message.edit_text(
        "Choose broadcast target:",
        reply_markup=get_broadcast_target_keyboard()
    )
    await state.set_state(BroadcastStates.waiting_target)

@router.callback_query(BroadcastStates.waiting_target, F.data.startswith("target_"))
async def broadcast_target(callback: CallbackQuery, state: FSMContext):
    target = callback.data.split("_")[1]
    await state.update_data(target=target)
    await callback.message.edit_text(
        "Send me the content to broadcast.\n"
        "You can send text, photo, video, or animation.\n"
        "For media with caption, send the media with caption."
    )
    await state.set_state(BroadcastStates.waiting_content)

@router.message(BroadcastStates.waiting_content)
async def broadcast_content(message: Message, state: FSMContext):
    content_type = None
    content_data = {}
    if message.text:
        content_type = "text"
        content_data = {"text": message.text}
    elif message.photo:
        content_type = "photo"
        content_data = {"photo": message.photo[-1].file_id, "caption": message.caption or ""}
    elif message.video:
        content_type = "video"
        content_data = {"video": message.video.file_id, "caption": message.caption or ""}
    elif message.animation:
        content_type = "animation"
        content_data = {"animation": message.animation.file_id, "caption": message.caption or ""}
    else:
        await message.answer("Unsupported content type. Please send text, photo, video, or GIF.")
        return
    await state.update_data(content_type=content_type, content_data=content_data)
    data = await state.get_data()
    target = data['target']
    summary = f"Target: {target}\nType: {content_type}\nPreview:\n"
    await message.answer(summary, reply_markup=get_broadcast_confirm_keyboard())
    await state.set_state(BroadcastStates.confirm)

@router.callback_query(BroadcastStates.confirm, F.data == "broadcast_confirm")
async def broadcast_confirm(callback: CallbackQuery, state: FSMContext):
    data = await state.get_data()
    target = data['target']
    content_type = data['content_type']
    content = data['content_data']
    admin_id = callback.from_user.id
    job_id = str(uuid.uuid4())
    db = get_db()

    if target == "all":
        users = await get_all_users(db)
    else:
        users = await get_paid_users(db)

    total = len(users)
    job = {
        "job_id": job_id,
        "admin_id": admin_id,
        "target": target,
        "content_type": content_type,
        "content": content,
        "status": "in_progress",
        "created_at": datetime.utcnow(),
        "sent_count": 0,
        "total_count": total
    }
    await db.broadcast_jobs.insert_one(job)
    await callback.message.edit_text(f"Broadcast started to {total} users. Job ID: {job_id}")
    asyncio.create_task(execute_broadcast(job_id, users, content_type, content))
    await state.clear()

async def execute_broadcast(job_id, users, content_type, content):
    db = get_db()
    bot = Bot.get_current()
    sent = 0
    for user in users:
        try:
            if content_type == "text":
                await bot.send_message(user['user_id'], content['text'])
            elif content_type == "photo":
                await bot.send_photo(user['user_id'], content['photo'], caption=content.get('caption', ''))
            elif content_type == "video":
                await bot.send_video(user['user_id'], content['video'], caption=content.get('caption', ''))
            elif content_type == "animation":
                await bot.send_animation(user['user_id'], content['animation'], caption=content.get('caption', ''))
            sent += 1
            await asyncio.sleep(0.05)
        except TelegramRetryAfter as e:
            await asyncio.sleep(e.retry_after)
        except TelegramForbiddenError:
            await db.users.update_one({"user_id": user['user_id']}, {"$set": {"is_blocked": True}})
        except Exception as e:
            logging.error(f"Broadcast error to {user['user_id']}: {e}")
    await db.broadcast_jobs.update_one(
        {"job_id": job_id},
        {"$set": {"status": "completed", "sent_count": sent}}
    )