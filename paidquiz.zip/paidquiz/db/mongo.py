from motor.motor_asyncio import AsyncIOMotorDatabase

db: AsyncIOMotorDatabase = None

async def init_db(database: AsyncIOMotorDatabase):
    global db
    db = database
    # Create indexes
    await db.users.create_index("user_id", unique=True)
    await db.quizzes.create_index("quiz_id", unique=True)
    await db.questions.create_index([("quiz_id", 1), ("qid", 1)], unique=True)
    await db.payments.create_index("payment_id", unique=True)
    await db.payments.create_index([("user_id", 1), ("quiz_id", 1), ("status", 1)])
    await db.answers.create_index([("user_id", 1), ("quiz_id", 1)])
    await db.admins.create_index("user_id", unique=True)
    await db.broadcast_jobs.create_index("job_id")

def get_db() -> AsyncIOMotorDatabase:
    return db