import csv
import io

def export_payments_to_csv(payments):
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["Payment ID", "User ID", "Quiz ID", "Amount", "Status", "Created At", "Verified At"])
    for p in payments:
        writer.writerow([
            p['payment_id'],
            p['user_id'],
            p['quiz_id'],
            p['amount'],
            p['status'],
            p['created_at'],
            p.get('verified_at', '')
        ])
    return output.getvalue().encode()