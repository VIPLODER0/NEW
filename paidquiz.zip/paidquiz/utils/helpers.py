from datetime import datetime
from db.mongo import get_db
from config import SUPER_ADMIN_IDS

async def get_user(db, tg_user):
    user = await db.users.find_one({"user_id": tg_user.id})
    if not user:
        user = {
            "user_id": tg_user.id,
            "username": tg_user.username,
            "first_name": tg_user.first_name,
            "last_name": tg_user.last_name,
            "registered_at": datetime.utcnow(),
            "is_blocked": False
        }
        await db.users.insert_one(user)
    return user

async def is_admin(user_id: int) -> bool:
    if user_id in SUPER_ADMIN_IDS:
        return True
    db = get_db()
    admin = await db.admins.find_one({"user_id": user_id})
    return admin is not None

async def is_super_admin(user_id: int) -> bool:
    return user_id in SUPER_ADMIN_IDS