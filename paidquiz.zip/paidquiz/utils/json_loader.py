import json
from db.mongo import get_db

async def load_questions_from_json(content: str, quiz_id: str):
    try:
        data = json.loads(content)
    except json.JSONDecodeError:
        return False, "Invalid JSON format."

    if not isinstance(data, dict) or "questions" not in data:
        return False, "JSON must contain 'questions' array."

    if data.get("quiz_id") != quiz_id:
        return False, f"Quiz ID mismatch. Expected {quiz_id}."

    questions = data["questions"]
    if not isinstance(questions, list):
        return False, "'questions' must be an array."

    db = get_db()
    for q in questions:
        if not all(k in q for k in ("id", "question", "options", "correct")):
            return False, "Each question must have id, question, options, correct."
        if not isinstance(q["options"], list) or len(q["options"]) < 2:
            return False, "Options must be a list with at least 2 items."
        if not isinstance(q["correct"], int) or q["correct"] >= len(q["options"]):
            return False, "Correct option index out of range."

    await db.questions.delete_many({"quiz_id": quiz_id})

    to_insert = []
    for q in questions:
        to_insert.append({
            "quiz_id": quiz_id,
            "qid": q["id"],
            "question_text": q["question"],
            "options": q["options"],
            "correct_option": q["correct"],
            "image_url": q.get("image_url"),
            "audio_url": q.get("audio_url")
        })
    await db.questions.insert_many(to_insert)
    return True, f"Loaded {len(to_insert)} questions."