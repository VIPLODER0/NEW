import asyncio

async def start_question_timer(seconds, callback):
    await asyncio.sleep(seconds)
    await callback()