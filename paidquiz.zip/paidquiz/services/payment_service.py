from datetime import datetime, date
from db.mongo import get_db
from services.razorpay_client import fetch_payment_async

async def has_user_paid(db, user_id, quiz_id):
    payment = await db.payments.find_one({"user_id": user_id, "quiz_id": quiz_id, "status": "paid"})
    return payment is not None

async def get_total_earnings():
    db = get_db()
    pipeline = [{"$match": {"status": "paid"}}, {"$group": {"_id": None, "total": {"$sum": "$amount"}}}]
    result = await db.payments.aggregate(pipeline).to_list(1)
    return result[0]['total'] if result else 0

async def get_today_earnings():
    db = get_db()
    today_start = datetime.combine(date.today(), datetime.min.time())
    today_end = datetime.combine(date.today(), datetime.max.time())
    pipeline = [
        {"$match": {"status": "paid", "verified_at": {"$gte": today_start, "$lte": today_end}}},
        {"$group": {"_id": None, "total": {"$sum": "$amount"}}}
    ]
    result = await db.payments.aggregate(pipeline).to_list(1)
    return result[0]['total'] if result else 0

async def verify_razorpay_payment(order_id: str, razorpay_payment_id: str) -> bool:
    """Verify that the payment belongs to the order and is captured."""
    try:
        payment = await fetch_payment_async(razorpay_payment_id)
        if payment.get('order_id') != order_id:
            return False
        if payment.get('status') != 'captured':
            return False
        return True
    except Exception:
        return False