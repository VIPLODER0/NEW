import asyncio
import razorpay
from config import RAZORPAY_KEY_ID, RAZORPAY_KEY_SECRET

# Synchronous Razorpay client
client = razorpay.Client(auth=(RAZORPAY_KEY_ID, RAZORPAY_KEY_SECRET))

async def create_order_async(amount: int, currency: str = "INR") -> dict:
    """Create a Razorpay order asynchronously."""
    data = {
        "amount": amount * 100,   # Convert INR to paise
        "currency": currency,
        "payment_capture": 1
    }
    loop = asyncio.get_event_loop()
    order = await loop.run_in_executor(None, lambda: client.order.create(data))
    return order

async def fetch_payment_async(payment_id: str) -> dict:
    """Fetch payment details from Razorpay."""
    loop = asyncio.get_event_loop()
    payment = await loop.run_in_executor(None, lambda: client.payment.fetch(payment_id))
    return payment

def verify_payment_signature(payment_id: str, order_id: str, signature: str) -> bool:
    """Verify payment signature locally."""
    params = {
        'razorpay_payment_id': payment_id,
        'razorpay_order_id': order_id,
        'razorpay_signature': signature
    }
    try:
        client.utility.verify_payment_signature(params)
        return True
    except razorpay.errors.SignatureVerificationError:
        return False