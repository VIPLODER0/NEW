from aiogram.fsm.state import State, StatesGroup

class AdminStates(StatesGroup):
    waiting_quiz_id = State()
    waiting_quiz_title = State()
    waiting_quiz_description = State()
    waiting_quiz_price = State()
    waiting_quiz_time = State()
    waiting_questions_file = State()
    waiting_quiz_start = State()
    waiting_quiz_stop = State()
    waiting_new_admin_id = State()

class BroadcastStates(StatesGroup):
    waiting_target = State()
    waiting_content = State()
    confirm = State()