import asyncio
from datetime import datetime
from aiogram import Router, F, Bot
from aiogram.types import CallbackQuery, Message
from aiogram.fsm.context import FSMContext

from db.mongo import get_db
from keyboards.inline import get_question_keyboard, get_quiz_complete_keyboard
from states.quiz_states import QuizTaking
from services.quiz_service import get_quiz_session, save_quiz_session

router = Router()

async def send_question(message, state, user_id, quiz_id, qid, time_limit):
    db = get_db()
    question = await db.questions.find_one({"quiz_id": quiz_id, "qid": qid})
    if not question:
        await complete_quiz(message, state, user_id, quiz_id)
        return

    text = f"<b>Question {qid}</b>\n\n{question['question_text']}"
    await message.answer(text, reply_markup=get_question_keyboard(quiz_id, qid, question['options']))

    # Start timer
    task = asyncio.create_task(question_timer(message.chat.id, user_id, quiz_id, qid, time_limit, state))
    await state.update_data(timer_task=task, q_start_time=datetime.utcnow())

async def question_timer(chat_id, user_id, quiz_id, qid, time_limit, state: FSMContext):
    await asyncio.sleep(time_limit)
    data = await state.get_data()
    if data.get('current_qid') == qid:
        # Timeout – record wrong answer
        await record_answer(user_id, quiz_id, qid, -1, False, time_limit)
        next_qid = qid + 1
        await state.update_data(current_qid=next_qid)
        await send_question_to_chat(chat_id, state, user_id, quiz_id, next_qid, time_limit)

async def send_question_to_chat(chat_id, state, user_id, quiz_id, qid, time_limit):
    bot = Bot.get_current()
    await send_question(await bot.send_message(chat_id, "⏳ Loading next question..."),
                        state, user_id, quiz_id, qid, time_limit)

async def record_answer(user_id, quiz_id, qid, selected_option, is_correct, time_taken):
    db = get_db()
    answer = {
        "user_id": user_id,
        "quiz_id": quiz_id,
        "qid": qid,
        "selected_option": selected_option,
        "is_correct": is_correct,
        "time_taken": time_taken,
        "answered_at": datetime.utcnow()
    }
    await db.answers.insert_one(answer)
    await db.quiz_sessions.update_one(
        {"user_id": user_id, "quiz_id": quiz_id},
        {"$set": {f"answers.{qid}": answer}}
    )

async def complete_quiz(message, state, user_id, quiz_id):
    db = get_db()
    await db.quiz_sessions.update_one(
        {"user_id": user_id, "quiz_id": quiz_id},
        {"$set": {"completed": True}}
    )

    total_q = await db.questions.count_documents({"quiz_id": quiz_id})
    correct = await db.answers.count_documents({"user_id": user_id, "quiz_id": quiz_id, "is_correct": True})
    wrong = total_q - correct

    pipeline = [
        {"$match": {"quiz_id": quiz_id, "is_correct": True}},
        {"$group": {"_id": "$user_id", "score": {"$sum": 1}}},
        {"$sort": {"score": -1}},
        {"$limit": 3}
    ]
    top = await db.answers.aggregate(pipeline).to_list(3)
    leaderboard = "🏆 <b>Top 3</b>\n"
    for i, t in enumerate(top, 1):
        u = await db.users.find_one({"user_id": t['_id']})
        name = u.get('first_name', 'Unknown') if u else 'Unknown'
        leaderboard += f"{i}. {name} – {t['score']}\n"

    result = (
        f"✅ <b>Quiz Completed!</b>\n\n"
        f"Your Score: {correct}/{total_q}\n"
        f"Correct: {correct}\n"
        f"Wrong: {wrong}\n\n"
        f"{leaderboard}"
    )
    await message.answer(result, reply_markup=get_quiz_complete_keyboard())
    await state.clear()

@router.callback_query(F.data.startswith("quiz_start_"))
async def start_quiz(callback: CallbackQuery, state: FSMContext):
    quiz_id = callback.data.split("_")[2]
    db = get_db()
    user_id = callback.from_user.id

    payment = await db.payments.find_one({"user_id": user_id, "quiz_id": quiz_id, "status": "paid"})
    if not payment:
        await callback.answer("You need to pay first.", show_alert=True)
        return

    quiz = await db.quizzes.find_one({"quiz_id": quiz_id, "status": "active"})
    if not quiz:
        await callback.answer("Quiz is not active right now.", show_alert=True)
        return

    session = await get_quiz_session(user_id, quiz_id)
    if session and not session.get('completed'):
        current_qid = session['current_qid']
    else:
        total_questions = await db.questions.count_documents({"quiz_id": quiz_id})
        session = {
            "user_id": user_id,
            "quiz_id": quiz_id,
            "current_qid": 1,
            "start_time": datetime.utcnow(),
            "answers": {},
            "completed": False
        }
        await save_quiz_session(session)
        current_qid = 1

    await state.set_state(QuizTaking.answering)
    await state.update_data(quiz_id=quiz_id, current_qid=current_qid, timer_task=None)
    await send_question(callback.message, state, user_id, quiz_id, current_qid, quiz['time_per_question'])
    await callback.message.delete()

@router.callback_query(QuizTaking.answering, F.data.startswith("answer_"))
async def handle_answer(callback: CallbackQuery, state: FSMContext):
    data = await state.get_data()
    quiz_id = data['quiz_id']
    current_qid = data['current_qid']

    parts = callback.data.split("_")
    if len(parts) != 4:
        await callback.answer("Invalid data")
        return
    _, qz, qid, opt = parts
    if qz != quiz_id or int(qid) != current_qid:
        await callback.answer("This question is not active.", show_alert=True)
        return
    option = int(opt)
    user_id = callback.from_user.id
    db = get_db()

    timer_task = data.get('timer_task')
    if timer_task:
        timer_task.cancel()

    question = await db.questions.find_one({"quiz_id": quiz_id, "qid": current_qid})
    is_correct = (option == question['correct_option'])
    time_taken = (datetime.utcnow() - data.get('q_start_time', datetime.utcnow())).total_seconds()
    await record_answer(user_id, quiz_id, current_qid, option, is_correct, time_taken)

    await callback.answer("Answer recorded!" if is_correct else "❌ Wrong answer.")

    next_qid = current_qid + 1
    total_q = await db.questions.count_documents({"quiz_id": quiz_id})
    if next_qid > total_q:
        await complete_quiz(callback.message, state, user_id, quiz_id)
    else:
        await state.update_data(current_qid=next_qid)
        quiz = await db.quizzes.find_one({"quiz_id": quiz_id})
        await send_question(callback.message, state, user_id, quiz_id, next_qid, quiz['time_per_question'])