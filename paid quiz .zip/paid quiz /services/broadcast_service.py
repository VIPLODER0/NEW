from db.mongo import get_db

async def get_all_users(db):
    return await db.users.find({}, {"user_id": 1}).to_list(None)

async def get_paid_users(db):
    pipeline = [
        {"$match": {"status": "paid"}},
        {"$group": {"_id": "$user_id"}}
    ]
    paid_ids = await db.payments.aggregate(pipeline).to_list(None)
    user_ids = [p['_id'] for p in paid_ids]
    return [{"user_id": uid} for uid in user_ids]