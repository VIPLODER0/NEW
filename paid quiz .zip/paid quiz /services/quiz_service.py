from datetime import datetime
from db.mongo import get_db

async def get_active_quizzes(db):
    return await db.quizzes.find({"status": {"$in": ["created", "active"]}}).to_list(100)

async def get_quiz_session(user_id, quiz_id):
    db = get_db()
    return await db.quiz_sessions.find_one({"user_id": user_id, "quiz_id": quiz_id})

async def save_quiz_session(session):
    db = get_db()
    await db.quiz_sessions.update_one(
        {"user_id": session["user_id"], "quiz_id": session["quiz_id"]},
        {"$set": session},
        upsert=True
    )

async def update_quiz_status(quiz_id, status):
    db = get_db()
    await db.quizzes.update_one({"quiz_id": quiz_id}, {"$set": {"status": status}})
    if status == "active":
        await db.quizzes.update_one({"quiz_id": quiz_id}, {"$set": {"started_at": datetime.utcnow()}})
    elif status == "completed":
        await db.quizzes.update_one({"quiz_id": quiz_id}, {"$set": {"ended_at": datetime.utcnow()}})