from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils.keyboard import InlineKeyboardBuilder

# ---------- User Main Keyboard ----------
def get_user_main_keyboard() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="▶️ Join Quiz", callback_data="join_quiz"),
        InlineKeyboardButton(text="🧠 Quiz Rules", callback_data="quiz_rules")
    )
    builder.row(
        InlineKeyboardButton(text="📊 My Result", callback_data="my_result"),
        InlineKeyboardButton(text="🏆 Leaderboard", callback_data="leaderboard")
    )
    builder.row(
        InlineKeyboardButton(text="💳 Payment Status", callback_data="payment_status"),
        InlineKeyboardButton(text="ℹ️ Help", callback_data="help_user")
    )
    return builder.as_markup()

# ---------- Quiz List ----------
def get_quiz_list_keyboard(quizzes, action="select") -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for q in quizzes:
        builder.button(text=q.get('title', q['quiz_id']), callback_data=f"quiz_{action}_{q['quiz_id']}")
    builder.adjust(1)
    builder.row(InlineKeyboardButton(text="🔙 Back", callback_data="back_to_main"))
    return builder.as_markup()

# ---------- Payment ----------
def get_payment_keyboard(quiz_id, amount) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(text="💳 Pay Now", callback_data=f"pay_{quiz_id}_{amount}")
    builder.button(text="🔙 Back", callback_data="join_quiz")
    builder.adjust(1)
    return builder.as_markup()

def get_razorpay_payment_keyboard(payment_link: str, order_id: str) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(text="💳 Pay with Razorpay", url=payment_link)
    builder.button(text="✅ I have paid", callback_data=f"verify_pay_{order_id}")
    builder.button(text="🔙 Cancel", callback_data="back_to_main")
    builder.adjust(1)
    return builder.as_markup()

# ---------- Quiz Start ----------
def get_quiz_start_keyboard(quiz_id) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(text="▶️ Start Quiz", callback_data=f"quiz_start_{quiz_id}")
    builder.button(text="🔙 Back", callback_data="join_quiz")
    return builder.as_markup()

# ---------- Question Options ----------
def get_question_keyboard(quiz_id, qid, options) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for idx, opt in enumerate(options):
        builder.button(text=opt, callback_data=f"answer_{quiz_id}_{qid}_{idx}")
    builder.adjust(1)
    return builder.as_markup()

# ---------- Quiz Complete ----------
def get_quiz_complete_keyboard() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(text="📊 My Result", callback_data="my_result")
    builder.button(text="🏆 Leaderboard", callback_data="leaderboard")
    builder.button(text="🔙 Main Menu", callback_data="back_to_main")
    builder.adjust(1)
    return builder.as_markup()

# ---------- Admin Main Keyboard ----------
def get_admin_main_keyboard() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="➕ Add Quiz", callback_data="add_quiz"),
        InlineKeyboardButton(text="🧠 Manage Questions", callback_data="manage_questions")
    )
    builder.row(
        InlineKeyboardButton(text="▶️ Start Quiz", callback_data="start_quiz"),
        InlineKeyboardButton(text="⏹ Stop Quiz", callback_data="stop_quiz")
    )
    builder.row(
        InlineKeyboardButton(text="📢 Broadcast", callback_data="broadcast_menu"),
        InlineKeyboardButton(text="📊 Stats & Earnings", callback_data="stats_earnings")
    )
    builder.row(
        InlineKeyboardButton(text="👤 Manage Admin", callback_data="manage_admin"),
        InlineKeyboardButton(text="ℹ️ Help (Admin)", callback_data="admin_help")
    )
    return builder.as_markup()

def get_quiz_manage_keyboard(quizzes) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for q in quizzes:
        builder.button(text=q['title'], callback_data=f"quiz_manage_{q['quiz_id']}")
    builder.adjust(1)
    builder.row(InlineKeyboardButton(text="🔙 Back", callback_data="admin_panel"))
    return builder.as_markup()

def get_broadcast_keyboard() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(text="📢 New Broadcast", callback_data="broadcast_new")
    builder.button(text="🔙 Back", callback_data="admin_panel")
    return builder.as_markup()

def get_broadcast_target_keyboard() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(text="👥 All Users", callback_data="target_all")
    builder.button(text="💳 Paid Users", callback_data="target_paid")
    builder.button(text="🔙 Back", callback_data="broadcast_menu")
    builder.adjust(1)
    return builder.as_markup()

def get_broadcast_confirm_keyboard() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(text="✅ Confirm Broadcast", callback_data="broadcast_confirm")
    builder.button(text="❌ Cancel", callback_data="broadcast_menu")
    return builder.as_markup()

def get_export_csv_keyboard() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(text="📥 Export CSV", callback_data="export_csv")
    builder.button(text="🔙 Back", callback_data="stats_earnings")
    return builder.as_markup()

def get_admin_list_keyboard(admins) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for a in admins:
        text = f"{a['user_id']} ({a['role']})"
        if a['role'] != 'superadmin':
            builder.button(text=f"❌ Remove {a['user_id']}", callback_data=f"admin_remove_{a['user_id']}")
        else:
            builder.button(text=f"👑 {a['user_id']}", callback_data="noop")
    builder.button(text="➕ Add Admin", callback_data="admin_add_")
    builder.button(text="🔙 Back", callback_data="admin_panel")
    builder.adjust(1)
    return builder.as_markup()

def get_back_to_admin_keyboard() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(text="🔙 Back", callback_data="admin_panel")
    return builder.as_markup()

def get_back_to_main_keyboard() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(text="🔙 Main Menu", callback_data="back_to_main")
    return builder.as_markup()