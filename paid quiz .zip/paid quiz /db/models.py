from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from datetime import datetime

class User(BaseModel):
    user_id: int
    username: Optional[str] = None
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    registered_at: datetime = Field(default_factory=datetime.utcnow)
    is_blocked: bool = False

class Quiz(BaseModel):
    quiz_id: str
    title: str
    description: Optional[str] = None
    price: int
    question_order: str = "fixed"  # "fixed" or "random"
    time_per_question: int = 30
    status: str = "created"  # created, active, completed
    created_at: datetime = Field(default_factory=datetime.utcnow)
    started_at: Optional[datetime] = None
    ended_at: Optional[datetime] = None

class Question(BaseModel):
    quiz_id: str
    qid: int
    question_text: str
    options: List[str]
    correct_option: int
    image_url: Optional[str] = None
    audio_url: Optional[str] = None

class Payment(BaseModel):
    payment_id: str          # Razorpay order id
    user_id: int
    quiz_id: str
    amount: int
    status: str = "pending"  # pending, paid, failed, expired
    created_at: datetime = Field(default_factory=datetime.utcnow)
    expires_at: Optional[datetime] = None
    verified_at: Optional[datetime] = None
    razorpay_order_id: str
    razorpay_payment_id: Optional[str] = None
    razorpay_signature: Optional[str] = None

class Answer(BaseModel):
    user_id: int
    quiz_id: str
    qid: int
    selected_option: int
    is_correct: bool
    time_taken: float
    answered_at: datetime = Field(default_factory=datetime.utcnow)

class Admin(BaseModel):
    user_id: int
    role: str = "admin"  # "superadmin" or "admin"
    added_by: Optional[int] = None
    added_at: datetime = Field(default_factory=datetime.utcnow)

class BroadcastJob(BaseModel):
    job_id: str
    admin_id: int
    target: str  # "all" or "paid"
    content_type: str  # "text", "photo", "video", "animation"
    content: Dict[str, Any]
    status: str = "pending"
    created_at: datetime = Field(default_factory=datetime.utcnow)
    sent_count: int = 0
    total_count: int = 0

class QuizSession(BaseModel):
    user_id: int
    quiz_id: str
    current_qid: int
    start_time: datetime
    answers: Dict[int, Answer]  # qid -> Answer
    completed: bool = False