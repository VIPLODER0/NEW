from aiogram.fsm.state import State, StatesGroup

class QuizTaking(StatesGroup):
    answering = State()