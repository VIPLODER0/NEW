from aiogram.fsm.state import State, StatesGroup

class PaymentWaiting(StatesGroup):
    verification = State()
    waiting_payment_id = State()