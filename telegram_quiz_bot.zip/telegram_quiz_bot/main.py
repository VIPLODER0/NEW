import asyncio
import signal
import sys
from contextlib import asynccontextmanager
from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from config import settings
from services.database import db
from services.quiz_service import quiz_service
from loader import get_dispatcher, get_bot
from utils.logger import logger, setup_logger


async def on_startup(dispatcher: Dispatcher, bot: Bot):
    """Run on bot startup"""
    logger.info("Bot starting up...")
    
    try:
        # Connect to databases
        await db.connect_redis()
        logger.info("Connected to Redis")
        
        # Cleanup stale sessions
        await quiz_service.cleanup_stale_sessions()
        logger.info("Cleaned up stale quiz sessions")
        
        # Set bot commands
        await set_bot_commands(bot)
        
        # Send startup message to super admins
        await notify_admins(bot, "🚀 Bot started successfully!")
        
        logger.info(f"Bot started as @{(await bot.me()).username}")
        
    except Exception as e:
        logger.error(f"Startup error: {e}", exc_info=True)


async def on_shutdown(dispatcher: Dispatcher, bot: Bot):
    """Run on bot shutdown"""
    logger.info("Bot shutting down...")
    
    try:
        # Send shutdown notification
        await notify_admins(bot, "🛑 Bot shutting down...")
        
        # Close database connections
        await db.close()
        logger.info("Database connections closed")
        
        # Cancel all background tasks
        tasks = [t for t in asyncio.all_tasks() if t is not asyncio.current_task()]
        for task in tasks:
            task.cancel()
        
        await asyncio.gather(*tasks, return_exceptions=True)
        
    except Exception as e:
        logger.error(f"Shutdown error: {e}", exc_info=True)
    
    logger.info("Bot shutdown complete")


async def set_bot_commands(bot: Bot):
    """Set bot commands menu"""
    from aiogram.types import BotCommand, BotCommandScopeDefault
    
    commands = [
        BotCommand(command="start", description="Start the bot"),
        BotCommand(command="id", description="Get your user ID"),
        BotCommand(command="stats", description="View your statistics"),
        BotCommand(command="admin", description="Admin panel (admins only)"),
        BotCommand(command="help", description="Show help information"),
    ]
    
    await bot.set_my_commands(commands, scope=BotCommandScopeDefault())


async def notify_admins(bot: Bot, message: str):
    """Notify super admins about bot status"""
    from services.admin_service import admin_service
    
    for admin_id in settings.SUPER_ADMIN_IDS:
        try:
            await bot.send_message(admin_id, message)
        except Exception as e:
            logger.error(f"Failed to notify admin {admin_id}: {e}")


async def main():
    """Main application entry point"""
    # Setup logging
    setup_logger("quiz_bot", settings.LOG_FILE)
    
    logger.info("Initializing Quiz Bot...")
    
    # Create bot and dispatcher
    bot = await get_bot()
    dp = await get_dispatcher()
    
    # Setup startup/shutdown handlers
    dp.startup.register(on_startup)
    dp.shutdown.register(on_shutdown)
    
    # Handle signals for graceful shutdown
    loop = asyncio.get_event_loop()
    
    def signal_handler():
        logger.info("Received shutdown signal")
        # This will be handled by aiogram's shutdown
    
    for sig in (signal.SIGINT, signal.SIGTERM):
        loop.add_signal_handler(sig, signal_handler)
    
    try:
        # Start polling
        logger.info("Starting bot polling...")
        await dp.start_polling(
            bot,
            allowed_updates=dp.resolve_used_update_types(),
            handle_signals=False  # We handle signals manually
        )
        
    except asyncio.CancelledError:
        logger.info("Bot polling cancelled")
    except Exception as e:
        logger.error(f"Bot polling error: {e}", exc_info=True)
        raise
    finally:
        logger.info("Bot stopped")


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Bot stopped by user")
        sys.exit(0)
    except Exception as e:
        logger.error(f"Fatal error: {e}", exc_info=True)
        sys.exit(1)