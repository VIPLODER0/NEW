from typing import List, Dict, Optional
from datetime import datetime
from services.database import db
from models.admin import AdminRole


class AdminService:
    async def is_admin(self, user_id: int) -> bool:
        """Check if user is an admin"""
        admin = await db.get_admin(user_id)
        return admin is not None
    
    async def is_super_admin(self, user_id: int) -> bool:
        """Check if user is super admin"""
        admin = await db.get_admin(user_id)
        return admin and admin.get('role') == AdminRole.SUPER_ADMIN
    
    async def get_admin_permissions(self, user_id: int) -> List[str]:
        """Get admin permissions"""
        admin = await db.get_admin(user_id)
        if not admin:
            return []
        
        # Base permissions based on role
        role = admin.get('role', AdminRole.ADMIN)
        
        if role == AdminRole.SUPER_ADMIN:
            permissions = [
                "manage_admins",
                "manage_quizzes",
                "manage_questions",
                "start_quiz",
                "stop_quiz",
                "broadcast",
                "view_stats",
                "view_earnings",
                "export_data",
                "maintenance_mode",
                "edit_leaderboard"
            ]
        elif role == AdminRole.ADMIN:
            permissions = [
                "manage_quizzes",
                "manage_questions",
                "start_quiz",
                "stop_quiz",
                "broadcast",
                "view_stats"
            ]
        else:  # MODERATOR
            permissions = [
                "view_stats",
                "broadcast"
            ]
        
        # Add custom permissions
        custom_perms = admin.get('permissions', [])
        permissions.extend(custom_perms)
        
        return list(set(permissions))
    
    async def can_perform_action(self, user_id: int, action: str) -> bool:
        """Check if admin can perform specific action"""
        permissions = await self.get_admin_permissions(user_id)
        return action in permissions
    
    async def add_admin(self, admin_id: int, added_by: int, 
                       role: AdminRole = AdminRole.ADMIN,
                       permissions: List[str] = None) -> bool:
        """Add new admin"""
        # Check if adder is super admin
        if not await self.is_super_admin(added_by):
            return False
        
        # Check if user already admin
        existing = await db.get_admin(admin_id)
        if existing:
            return False
        
        # Get user info (would need to fetch from Telegram)
        # For now, create with minimal info
        admin_data = {
            "id": admin_id,
            "first_name": f"Admin_{admin_id}",
            "role": role,
            "permissions": permissions or [],
            "added_by": added_by,
            "added_at": datetime.utcnow(),
            "is_active": True,
            "last_active": datetime.utcnow()
        }
        
        await db.create_admin(admin_data)
        
        # Log admin action
        await self._log_admin_action(
            added_by,
            "add_admin",
            admin_id,
            {"role": role, "permissions": permissions}
        )
        
        return True
    
    async def remove_admin(self, admin_id: int, removed_by: int) -> bool:
        """Remove admin"""
        # Check if remover is super admin
        if not await self.is_super_admin(removed_by):
            return False
        
        # Cannot remove self
        if admin_id == removed_by:
            return False
        
        result = await db.remove_admin(admin_id)
        
        if result:
            await self._log_admin_action(
                removed_by,
                "remove_admin",
                admin_id,
                {}
            )
        
        return result
    
    async def update_admin_role(self, admin_id: int, updated_by: int,
                              new_role: AdminRole) -> bool:
        """Update admin role"""
        if not await self.is_super_admin(updated_by):
            return False
        
        result = await db.db.admins.update_one(
            {"id": admin_id},
            {"$set": {"role": new_role}}
        )
        
        if result.modified_count > 0:
            await self._log_admin_action(
                updated_by,
                "update_admin_role",
                admin_id,
                {"new_role": new_role}
            )
        
        return result.modified_count > 0
    
    async def get_all_admins(self) -> List[Dict]:
        """Get all admins with details"""
        admins = await db.get_all_admins()
        
        # Add user info (would fetch from Telegram in real scenario)
        result = []
        for admin in admins:
            result.append({
                "id": admin['id'],
                "username": admin.get('username'),
                "first_name": admin.get('first_name'),
                "role": admin.get('role'),
                "added_by": admin.get('added_by'),
                "added_at": admin.get('added_at'),
                "last_active": admin.get('last_active'),
                "is_active": admin.get('is_active', True)
            })
        
        return result
    
    async def get_admin_stats(self) -> Dict:
        """Get admin dashboard statistics"""
        user_count = await db.get_user_count()
        active_quiz = await db.get_active_quiz()
        
        # Get recent payments
        recent_payments = await db.db.payments.find(
            {"payment_status": "success"}
        ).sort("created_at", -1).limit(10).to_list(length=10)
        
        # Get earnings stats
        earnings_stats = await db.get_earnings_stats()
        
        return {
            "total_users": user_count,
            "active_quiz": active_quiz.get('title') if active_quiz else None,
            "quiz_status": active_quiz.get('status') if active_quiz else 'no_active_quiz',
            "total_earnings": earnings_stats.get('total_earnings', 0),
            "today_earnings": earnings_stats.get('today_earnings', 0),
            "recent_payments": [
                {
                    "user_id": p['user_id'],
                    "amount": p['amount'],
                    "date": p['created_at']
                } for p in recent_payments
            ]
        }
    
    async def toggle_maintenance_mode(self, admin_id: int, enable: bool) -> bool:
        """Toggle maintenance mode"""
        if not await self.is_super_admin(admin_id):
            return False
        
        # In real scenario, update in Redis or database
        # For now, update in config
        from config import settings
        settings.MAINTENANCE_MODE = enable
        
        await self._log_admin_action(
            admin_id,
            "toggle_maintenance",
            None,
            {"enabled": enable}
        )
        
        return True
    
    async def edit_leaderboard(self, admin_id: int, quiz_id: str,
                             user_id: int, new_score: float) -> bool:
        """Edit leaderboard entry (super admin only)"""
        if not await self.is_super_admin(admin_id):
            return False
        
        # Find and update quiz session
        session = await db.db.quiz_sessions.find_one({
            "user_id": user_id,
            "quiz_id": quiz_id
        })
        
        if not session:
            return False
        
        result = await db.db.quiz_sessions.update_one(
            {"id": session['id']},
            {"$set": {"score": new_score}}
        )
        
        if result.modified_count > 0:
            await self._log_admin_action(
                admin_id,
                "edit_leaderboard",
                user_id,
                {"quiz_id": quiz_id, "old_score": session.get('score', 0), "new_score": new_score}
            )
        
        return result.modified_count > 0
    
    async def export_data(self, admin_id: int, data_type: str,
                         start_date: datetime = None,
                         end_date: datetime = None) -> List[Dict]:
        """Export data as CSV-ready format"""
        if not await self.can_perform_action(admin_id, "export_data"):
            return []
        
        if data_type == "users":
            users = await db.get_all_users()
            return [
                {
                    "user_id": u['id'],
                    "username": u.get('username'),
                    "first_name": u.get('first_name'),
                    "joined_date": u.get('joined_date'),
                    "payment_status": u.get('payment_status', False),
                    "payment_expiry": u.get('payment_expiry'),
                    "is_blocked": u.get('is_blocked', False)
                } for u in users
            ]
        
        elif data_type == "payments":
            query = {"payment_status": "success"}
            if start_date and end_date:
                query["created_at"] = {"$gte": start_date, "$lte": end_date}
            
            payments = await db.db.payments.find(query).to_list(length=None)
            return [
                {
                    "payment_id": p['id'],
                    "user_id": p['user_id'],
                    "quiz_id": p['quiz_id'],
                    "amount": p['amount'],
                    "currency": p['currency'],
                    "payment_method": p['payment_method'],
                    "created_at": p['created_at'],
                    "completed_at": p.get('completed_at')
                } for p in payments
            ]
        
        elif data_type == "quiz_results":
            query = {"status": "completed"}
            if start_date and end_date:
                query["end_time"] = {"$gte": start_date, "$lte": end_date}
            
            sessions = await db.db.quiz_sessions.find(query).to_list(length=None)
            return [
                {
                    "session_id": s['id'],
                    "user_id": s['user_id'],
                    "quiz_id": s['quiz_id'],
                    "score": s['score'],
                    "time_taken": s.get('time_taken', 0),
                    "start_time": s['start_time'],
                    "end_time": s.get('end_time')
                } for s in sessions
            ]
        
        return []
    
    async def _log_admin_action(self, admin_id: int, action: str,
                              target_id: Optional[int], details: Dict):
        """Log admin action for audit"""
        log_data = {
            "admin_id": admin_id,
            "action": action,
            "target_id": target_id,
            "details": details,
            "timestamp": datetime.utcnow()
        }
        await db.db.admin_logs.insert_one(log_data)


# Admin service instance
admin_service = AdminService()