import asyncio
from datetime import datetime
from typing import List, Dict, Optional, Union
from aiogram import Bot
from aiogram.types import Message, InputFile, InlineKeyboardMarkup
from services.database import db
from utils.helpers import split_message


class BroadcastService:
    def __init__(self):
        self.broadcast_tasks = {}
        self.rate_limit = 30  # messages per second
        self.max_retries = 3
    
    async def broadcast_to_all(self, bot: Bot, message: Union[str, InputFile],
                             keyboard: Optional[InlineKeyboardMarkup] = None,
                             message_type: str = "text") -> Dict:
        """Broadcast message to all users"""
        users = await db.get_all_users()
        return await self._send_broadcast(bot, users, message, keyboard, message_type, "all_users")
    
    async def broadcast_to_paid(self, bot: Bot, message: Union[str, InputFile],
                              keyboard: Optional[InlineKeyboardMarkup] = None,
                              message_type: str = "text") -> Dict:
        """Broadcast message to paid users only"""
        users = await db.get_paid_users()
        return await self._send_broadcast(bot, users, message, keyboard, message_type, "paid_users")
    
    async def broadcast_to_single(self, bot: Bot, user_id: int,
                                message: Union[str, InputFile],
                                keyboard: Optional[InlineKeyboardMarkup] = None,
                                message_type: str = "text") -> bool:
        """Send message to single user"""
        try:
            if message_type == "photo" and isinstance(message, InputFile):
                await bot.send_photo(
                    chat_id=user_id,
                    photo=message,
                    reply_markup=keyboard
                )
            elif message_type == "document" and isinstance(message, InputFile):
                await bot.send_document(
                    chat_id=user_id,
                    document=message,
                    reply_markup=keyboard
                )
            else:
                # Split long messages
                if isinstance(message, str) and len(message) > 4096:
                    message_parts = split_message(message, 4096)
                    for part in message_parts:
                        await bot.send_message(
                            chat_id=user_id,
                            text=part,
                            reply_markup=keyboard if part == message_parts[-1] else None
                        )
                        await asyncio.sleep(0.1)  # Small delay between parts
                else:
                    await bot.send_message(
                        chat_id=user_id,
                        text=message,
                        reply_markup=keyboard
                    )
            
            # Log broadcast
            await self._log_broadcast(user_id, "single", True, message_type)
            return True
            
        except Exception as e:
            print(f"Error broadcasting to user {user_id}: {e}")
            await self._log_broadcast(user_id, "single", False, message_type, str(e))
            return False
    
    async def _send_broadcast(self, bot: Bot, users: List[Dict],
                            message: Union[str, InputFile],
                            keyboard: Optional[InlineKeyboardMarkup],
                            message_type: str, target: str) -> Dict:
        """Send broadcast to list of users"""
        total_users = len(users)
        successful = 0
        failed = 0
        failed_users = []
        
        # Create broadcast task ID
        task_id = f"broadcast_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}"
        self.broadcast_tasks[task_id] = {
            "status": "running",
            "total": total_users,
            "sent": 0,
            "failed": 0,
            "started_at": datetime.utcnow()
        }
        
        # Rate limiting
        semaphore = asyncio.Semaphore(self.rate_limit)
        
        async def send_to_user(user_data, index):
            nonlocal successful, failed
            user_id = user_data['id']
            
            async with semaphore:
                try:
                    if message_type == "photo" and isinstance(message, InputFile):
                        await bot.send_photo(
                            chat_id=user_id,
                            photo=message,
                            reply_markup=keyboard
                        )
                    elif message_type == "document" and isinstance(message, InputFile):
                        await bot.send_document(
                            chat_id=user_id,
                            document=message,
                            reply_markup=keyboard
                        )
                    else:
                        # Split long messages
                        if isinstance(message, str) and len(message) > 4096:
                            message_parts = split_message(message, 4096)
                            for part_idx, part in enumerate(message_parts):
                                await bot.send_message(
                                    chat_id=user_id,
                                    text=part,
                                    reply_markup=keyboard if part_idx == len(message_parts) - 1 else None
                                )
                                await asyncio.sleep(0.1)
                        else:
                            await bot.send_message(
                                chat_id=user_id,
                                text=message,
                                reply_markup=keyboard
                            )
                    
                    successful += 1
                    await self._log_broadcast(user_id, target, True, message_type)
                    
                except Exception as e:
                    error_msg = str(e)
                    if "blocked" in error_msg.lower() or "deactivated" in error_msg.lower():
                        # Mark user as blocked
                        await db.update_user(user_id, {"is_blocked": True})
                    
                    failed += 1
                    failed_users.append({"user_id": user_id, "error": error_msg[:100]})
                    await self._log_broadcast(user_id, target, False, message_type, error_msg)
                
                finally:
                    # Update task progress
                    self.broadcast_tasks[task_id]["sent"] = successful + failed
                    self.broadcast_tasks[task_id]["failed"] = failed
                    
                    # Small delay to respect rate limits
                    await asyncio.sleep(1 / self.rate_limit)
        
        # Create and run tasks
        tasks = [send_to_user(user, idx) for idx, user in enumerate(users)]
        await asyncio.gather(*tasks, return_exceptions=True)
        
        # Update task status
        self.broadcast_tasks[task_id].update({
            "status": "completed",
            "completed_at": datetime.utcnow(),
            "successful": successful,
            "failed": failed,
            "failed_users": failed_users[:10]  # Store only first 10 failures
        })
        
        return {
            "task_id": task_id,
            "total_users": total_users,
            "successful": successful,
            "failed": failed,
            "success_rate": (successful / total_users * 100) if total_users > 0 else 0,
            "failed_users": failed_users[:5]  # Return only first 5 for report
        }
    
    async def get_broadcast_status(self, task_id: str) -> Optional[Dict]:
        """Get status of a broadcast task"""
        return self.broadcast_tasks.get(task_id)
    
    async def cancel_broadcast(self, task_id: str) -> bool:
        """Cancel ongoing broadcast"""
        # Note: Cannot actually cancel running asyncio tasks easily
        # This just marks it as cancelled in our tracking
        if task_id in self.broadcast_tasks:
            self.broadcast_tasks[task_id]["status"] = "cancelled"
            return True
        return False
    
    async def _log_broadcast(self, user_id: int, target: str, success: bool,
                           message_type: str, error: str = None):
        """Log broadcast attempt"""
        log_data = {
            "user_id": user_id,
            "target": target,
            "success": success,
            "message_type": message_type,
            "error": error,
            "timestamp": datetime.utcnow()
        }
        await db.db.broadcast_logs.insert_one(log_data)
    
    async def get_broadcast_stats(self, days: int = 7) -> Dict:
        """Get broadcast statistics"""
        cutoff = datetime.utcnow() - timedelta(days=days)
        
        # Get broadcast logs
        pipeline = [
            {"$match": {"timestamp": {"$gte": cutoff}}},
            {"$group": {
                "_id": {
                    "date": {"$dateToString": {"format": "%Y-%m-%d", "date": "$timestamp"}},
                    "target": "$target",
                    "success": "$success"
                },
                "count": {"$sum": 1}
            }},
            {"$sort": {"_id.date": 1}}
        ]
        
        logs = await db.db.broadcast_logs.aggregate(pipeline).to_list(length=None)
        
        # Calculate daily stats
        daily_stats = {}
        for log in logs:
            date = log['_id']['date']
            if date not in daily_stats:
                daily_stats[date] = {
                    "date": date,
                    "total": 0,
                    "successful": 0,
                    "failed": 0
                }
            
            daily_stats[date]["total"] += log['count']
            if log['_id']['success']:
                daily_stats[date]["successful"] += log['count']
            else:
                daily_stats[date]["failed"] += log['count']
        
        # Convert to list and sort
        daily_list = list(daily_stats.values())
        daily_list.sort(key=lambda x: x["date"])
        
        # Calculate totals
        total_sent = sum(day["total"] for day in daily_list)
        total_success = sum(day["successful"] for day in daily_list)
        
        return {
            "period_days": days,
            "total_sent": total_sent,
            "total_successful": total_success,
            "total_failed": total_sent - total_success,
            "success_rate": (total_success / total_sent * 100) if total_sent > 0 else 0,
            "daily_stats": daily_list
        }


# Broadcast service instance
broadcast_service = BroadcastService()