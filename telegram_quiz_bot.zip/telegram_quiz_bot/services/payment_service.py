import hashlib
import hmac
import json
from datetime import datetime, timedelta
from typing import Dict, Optional, Tuple
import razorpay
from config import settings
from services.database import db


class PaymentService:
    def __init__(self):
        self.razorpay_client = None
        if settings.PAYMENT_PROVIDER == "razorpay" and settings.RAZORPAY_KEY_ID:
            self.razorpay_client = razorpay.Client(
                auth=(settings.RAZORPAY_KEY_ID, settings.RAZORPAY_KEY_SECRET)
            )
    
    async def create_payment_order(self, user_id: int, quiz_id: str, 
                                 amount: float = None) -> Optional[Dict]:
        """Create a new payment order"""
        if not amount:
            amount = settings.PAYMENT_AMOUNT / 100  # Convert paise to rupees
        
        # Check for existing pending payment
        existing_payments = await db.db.payments.find({
            "user_id": user_id,
            "quiz_id": quiz_id,
            "payment_status": "pending",
            "expires_at": {"$gt": datetime.utcnow()}
        }).to_list(length=1)
        
        if existing_payments:
            return {
                "payment_id": existing_payments[0]['id'],
                "order_id": existing_payments[0].get('razorpay_order_id'),
                "amount": existing_payments[0]['amount'],
                "status": "pending"
            }
        
        # Create payment record
        payment_data = {
            "id": str(ObjectId()),
            "user_id": user_id,
            "quiz_id": quiz_id,
            "amount": amount,
            "currency": "INR",
            "payment_method": "razorpay",
            "payment_status": "pending",
            "created_at": datetime.utcnow(),
            "expires_at": datetime.utcnow() + timedelta(hours=24),
            "metadata": {}
        }
        
        if self.razorpay_client:
            # Create Razorpay order
            try:
                order_data = {
                    "amount": int(amount * 100),  # Convert to paise
                    "currency": "INR",
                    "payment_capture": 1,
                    "notes": {
                        "user_id": str(user_id),
                        "quiz_id": quiz_id
                    }
                }
                
                razorpay_order = self.razorpay_client.order.create(data=order_data)
                
                payment_data["razorpay_order_id"] = razorpay_order["id"]
                payment_data["metadata"]["razorpay_order"] = razorpay_order
                
            except Exception as e:
                print(f"Error creating Razorpay order: {e}")
                # Fallback to mock payment for testing
                payment_data["razorpay_order_id"] = f"mock_order_{payment_data['id']}"
        
        payment = await db.create_payment(payment_data)
        
        # Create payment log
        log_data = {
            "payment_id": payment['id'],
            "user_id": user_id,
            "action": "created",
            "status": "pending",
            "amount": amount,
            "timestamp": datetime.utcnow()
        }
        await db.db.payment_logs.insert_one(log_data)
        
        return {
            "payment_id": payment['id'],
            "order_id": payment.get('razorpay_order_id'),
            "amount": payment['amount'],
            "currency": payment['currency'],
            "status": "pending"
        }
    
    async def verify_payment(self, payment_id: str, 
                           razorpay_payment_id: str,
                           razorpay_signature: str) -> Tuple[bool, str]:
        """Verify Razorpay payment"""
        payment = await db.db.payments.find_one({"id": payment_id})
        if not payment:
            return False, "Payment not found"
        
        if payment['payment_status'] != 'pending':
            return False, f"Payment already {payment['payment_status']}"
        
        # Verify signature
        if self.razorpay_client:
            try:
                params_dict = {
                    'razorpay_order_id': payment['razorpay_order_id'],
                    'razorpay_payment_id': razorpay_payment_id,
                    'razorpay_signature': razorpay_signature
                }
                
                self.razorpay_client.utility.verify_payment_signature(params_dict)
                
            except razorpay.errors.SignatureVerificationError:
                return False, "Invalid payment signature"
        
        # Update payment status
        update_data = {
            "payment_status": "success",
            "razorpay_payment_id": razorpay_payment_id,
            "razorpay_signature": razorpay_signature,
            "completed_at": datetime.utcnow()
        }
        
        await db.update_payment_status(payment_id, "success", update_data)
        
        # Update user payment status
        expiry_date = datetime.utcnow() + timedelta(days=1)  # 24-hour access
        await db.update_user(payment['user_id'], {
            "payment_status": True,
            "payment_expiry": expiry_date
        })
        
        # Create success log
        log_data = {
            "payment_id": payment_id,
            "user_id": payment['user_id'],
            "action": "verified",
            "status": "success",
            "amount": payment['amount'],
            "timestamp": datetime.utcnow()
        }
        await db.db.payment_logs.insert_one(log_data)
        
        return True, "Payment verified successfully"
    
    async def check_payment_status(self, user_id: int, quiz_id: str) -> Dict:
        """Check user's payment status for a quiz"""
        user = await db.get_user(user_id)
        
        if not user:
            return {
                "has_payment": False,
                "status": "user_not_found",
                "message": "User not registered"
            }
        
        # Check general payment status
        if user.get('payment_status') and user.get('payment_expiry'):
            if user['payment_expiry'] > datetime.utcnow():
                return {
                    "has_payment": True,
                    "status": "active",
                    "expires_at": user['payment_expiry'],
                    "message": "Payment active"
                }
            else:
                # Payment expired
                await db.update_user(user_id, {"payment_status": False})
        
        # Check quiz-specific payment
        payment = await db.db.payments.find_one({
            "user_id": user_id,
            "quiz_id": quiz_id,
            "payment_status": "success"
        })
        
        if payment:
            return {
                "has_payment": True,
                "status": "active",
                "payment_id": payment['id'],
                "message": "Quiz payment found"
            }
        
        return {
            "has_payment": False,
            "status": "no_payment",
            "message": "Payment required"
        }
    
    async def get_payment_history(self, user_id: int) -> List[Dict]:
        """Get user's payment history"""
        payments = await db.get_user_payments(user_id)
        
        result = []
        for payment in payments:
            result.append({
                "id": payment['id'],
                "quiz_id": payment['quiz_id'],
                "amount": payment['amount'],
                "currency": payment['currency'],
                "status": payment['payment_status'],
                "created_at": payment['created_at'],
                "completed_at": payment.get('completed_at'),
                "method": payment['payment_method']
            })
        
        return result
    
    async def get_earnings_report(self, start_date: datetime = None, 
                                end_date: datetime = None) -> Dict:
        """Get earnings report for admin"""
        if not start_date:
            start_date = datetime.utcnow().replace(day=1)  # Start of current month
        if not end_date:
            end_date = datetime.utcnow()
        
        # Get successful payments in date range
        payments = await db.db.payments.find({
            "payment_status": "success",
            "created_at": {"$gte": start_date, "$lte": end_date}
        }).to_list(length=None)
        
        total_earnings = sum(p['amount'] for p in payments)
        
        # Group by day
        daily_earnings = {}
        for payment in payments:
            date_str = payment['created_at'].strftime("%Y-%m-%d")
            if date_str not in daily_earnings:
                daily_earnings[date_str] = {
                    "date": date_str,
                    "amount": 0,
                    "count": 0
                }
            daily_earnings[date_str]["amount"] += payment['amount']
            daily_earnings[date_str]["count"] += 1
        
        # Convert to list
        daily_list = list(daily_earnings.values())
        daily_list.sort(key=lambda x: x["date"])
        
        return {
            "total_earnings": total_earnings,
            "total_payments": len(payments),
            "date_range": {
                "start": start_date,
                "end": end_date
            },
            "daily_breakdown": daily_list,
            "average_order_value": total_earnings / len(payments) if payments else 0
        }
    
    async def create_upi_payment(self, user_id: int, quiz_id: str, 
                               upi_id: str) -> Dict:
        """Create UPI payment request"""
        # For now, mock UPI payment
        payment_data = {
            "id": str(ObjectId()),
            "user_id": user_id,
            "quiz_id": quiz_id,
            "amount": settings.PAYMENT_AMOUNT / 100,
            "currency": "INR",
            "payment_method": "upi",
            "payment_status": "pending",
            "upi_transaction_id": f"UPI_{str(ObjectId())[:8]}",
            "created_at": datetime.utcnow(),
            "expires_at": datetime.utcnow() + timedelta(minutes=30),
            "metadata": {
                "upi_id": upi_id,
                "instructions": "Please send payment to quiz@upi and mention transaction ID"
            }
        }
        
        payment = await db.create_payment(payment_data)
        
        return {
            "payment_id": payment['id'],
            "upi_transaction_id": payment['upi_transaction_id'],
            "amount": payment['amount'],
            "status": "pending",
            "instructions": payment['metadata']['instructions'],
            "expires_in": 30  # minutes
        }
    
    async def process_coupon(self, user_id: int, quiz_id: str, 
                           coupon_code: str) -> Tuple[bool, str, Dict]:
        """Process coupon code"""
        # Mock coupon validation
        valid_coupons = {
            "WELCOME50": {"discount": 50, "type": "percentage", "max_uses": 100},
            "QUIZ100": {"discount": 100, "type": "fixed", "max_uses": 50},
            "FIRSTFREE": {"discount": 100, "type": "percentage", "max_uses": 1}
        }
        
        if coupon_code not in valid_coupons:
            return False, "Invalid coupon code", {}
        
        coupon = valid_coupons[coupon_code]
        
        # Check if user already used this coupon
        existing = await db.db.payments.find_one({
            "user_id": user_id,
            "coupon_code": coupon_code,
            "payment_status": "success"
        })
        
        if existing:
            return False, "Coupon already used", {}
        
        # Calculate discounted amount
        original_amount = settings.PAYMENT_AMOUNT / 100
        
        if coupon['type'] == 'percentage':
            discount_amount = original_amount * (coupon['discount'] / 100)
            final_amount = original_amount - discount_amount
        else:  # fixed
            discount_amount = coupon['discount']
            final_amount = max(0, original_amount - discount_amount)
        
        # Create payment with coupon
        payment_data = {
            "id": str(ObjectId()),
            "user_id": user_id,
            "quiz_id": quiz_id,
            "amount": final_amount,
            "original_amount": original_amount,
            "discount_amount": discount_amount,
            "currency": "INR",
            "payment_method": "coupon",
            "payment_status": "success",
            "coupon_code": coupon_code,
            "created_at": datetime.utcnow(),
            "completed_at": datetime.utcnow(),
            "expires_at": datetime.utcnow() + timedelta(days=1),
            "metadata": {"coupon_details": coupon}
        }
        
        payment = await db.create_payment(payment_data)
        
        # Update user payment status
        await db.update_user(user_id, {
            "payment_status": True,
            "payment_expiry": datetime.utcnow() + timedelta(days=1)
        })
        
        return True, "Coupon applied successfully", {
            "payment_id": payment['id'],
            "original_amount": original_amount,
            "discount_amount": discount_amount,
            "final_amount": final_amount,
            "coupon_code": coupon_code
        }


# Payment service instance
payment_service = PaymentService()