import json
import aiofiles
import asyncio
from typing import List, Dict, Optional, Tuple
from datetime import datetime
from pathlib import Path
from utils.json_validator import validate_quiz_json


class FileProcessor:
    def __init__(self, upload_dir: str = "data/uploads"):
        self.upload_dir = Path(upload_dir)
        self.upload_dir.mkdir(parents=True, exist_ok=True)
    
    async def save_uploaded_file(self, file_content: bytes, filename: str) -> str:
        """Save uploaded file to disk"""
        filepath = self.upload_dir / filename
        async with aiofiles.open(filepath, 'wb') as f:
            await f.write(file_content)
        return str(filepath)
    
    async def process_quiz_json(self, filepath: str) -> Tuple[bool, Optional[Dict], str]:
        """Process and validate quiz JSON file"""
        try:
            # Read file
            async with aiofiles.open(filepath, 'r', encoding='utf-8') as f:
                content = await f.read()
            
            # Parse JSON
            data = json.loads(content)
            
            # Validate structure
            is_valid, message, validated_data = validate_quiz_json(data)
            
            if not is_valid:
                return False, None, message
            
            return True, validated_data, "Quiz JSON validated successfully"
            
        except json.JSONDecodeError as e:
            return False, None, f"Invalid JSON format: {str(e)}"
        except Exception as e:
            return False, None, f"Error processing file: {str(e)}"
    
    async def prepare_questions_for_db(self, quiz_data: Dict, quiz_id: str) -> List[Dict]:
        """Prepare questions for database insertion"""
        questions = []
        
        for idx, q_data in enumerate(quiz_data.get('questions', [])):
            question = {
                "id": f"q_{quiz_id}_{idx + 1}_{datetime.utcnow().timestamp()}",
                "quiz_id": quiz_id,
                "question_number": idx + 1,
                "question_text": q_data.get('question', '').strip(),
                "question_type": "mcq",
                "options": [opt.strip() for opt in q_data.get('options', [])],
                "correct_option": q_data.get('correct', 0),  # 0-based index
                "points": 1.0,
                "time_limit": quiz_data.get('time_limit', 30),
                "difficulty": quiz_data.get('difficulty', 'medium'),
                "tags": quiz_data.get('tags', []),
                "created_at": datetime.utcnow()
            }
            
            # Validate question
            if (len(question['question_text']) < 3 or 
                len(question['options']) < 2 or
                question['correct_option'] >= len(question['options'])):
                continue  # Skip invalid questions
            
            questions.append(question)
        
        return questions
    
    async def create_quiz_from_json(self, quiz_data: Dict, admin_id: int) -> Dict:
        """Create quiz from validated JSON data"""
        quiz_id = quiz_data.get('quiz_id', f"quiz_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}")
        
        # Create quiz document
        quiz_doc = {
            "id": quiz_id,
            "title": quiz_data.get('title', 'Unnamed Quiz'),
            "description": quiz_data.get('description', ''),
            "quiz_type": "paid",
            "price": quiz_data.get('price', 100.0),
            "duration_minutes": quiz_data.get('duration', 60),
            "questions_count": len(quiz_data.get('questions', [])),
            "shuffle_questions": quiz_data.get('shuffle', True),
            "shuffle_options": quiz_data.get('shuffle_options', True),
            "negative_marking": quiz_data.get('negative_marking', False),
            "negative_mark_percentage": quiz_data.get('negative_mark_percentage', 25.0),
            "status": "draft",
            "created_by": admin_id,
            "created_at": datetime.utcnow(),
            "updated_at": datetime.utcnow(),
            "participant_count": 0,
            "is_locked": False
        }
        
        return {
            "quiz": quiz_doc,
            "questions": await self.prepare_questions_for_db(quiz_data, quiz_id)
        }
    
    async def export_quiz_to_json(self, quiz_id: str) -> Optional[Dict]:
        """Export quiz and questions to JSON format"""
        from services.database import db
        
        # Get quiz
        quiz = await db.get_quiz_by_id(quiz_id)
        if not quiz:
            return None
        
        # Get questions
        questions = await db.get_questions_by_quiz(quiz_id)
        
        # Prepare JSON structure
        quiz_json = {
            "quiz_id": quiz_id,
            "title": quiz.get('title', ''),
            "description": quiz.get('description', ''),
            "duration": quiz.get('duration_minutes', 60),
            "price": quiz.get('price', 0.0),
            "shuffle": quiz.get('shuffle_questions', True),
            "shuffle_options": quiz.get('shuffle_options', True),
            "negative_marking": quiz.get('negative_marking', False),
            "negative_mark_percentage": quiz.get('negative_mark_percentage', 25.0),
            "questions": []
        }
        
        for q in questions:
            question_data = {
                "id": q.get('question_number', 0),
                "question": q.get('question_text', ''),
                "options": q.get('options', []),
                "correct": q.get('correct_option', 0),
                "points": q.get('points', 1.0),
                "time_limit": q.get('time_limit', 30),
                "difficulty": q.get('difficulty', 'medium'),
                "explanation": q.get('explanation'),
                "tags": q.get('tags', [])
            }
            quiz_json["questions"].append(question_data)
        
        return quiz_json
    
    async def generate_stats_csv(self, stats_data: List[Dict]) -> str:
        """Generate CSV from statistics data"""
        if not stats_data:
            return ""
        
        # Get headers from first dict
        headers = list(stats_data[0].keys())
        
        # Build CSV
        csv_lines = [','.join(headers)]
        
        for row in stats_data:
            values = []
            for header in headers:
                value = row.get(header, '')
                # Convert to string and escape commas
                if isinstance(value, str) and ',' in value:
                    value = f'"{value}"'
                elif isinstance(value, datetime):
                    value = value.isoformat()
                else:
                    value = str(value)
                values.append(value)
            csv_lines.append(','.join(values))
        
        return '\n'.join(csv_lines)
    
    async def cleanup_old_files(self, days_old: int = 7):
        """Clean up old uploaded files"""
        cutoff = datetime.utcnow().timestamp() - (days_old * 24 * 3600)
        
        for filepath in self.upload_dir.glob('*'):
            if filepath.stat().st_mtime < cutoff:
                try:
                    filepath.unlink()
                except Exception as e:
                    print(f"Error deleting file {filepath}: {e}")


# File processor instance
file_processor = FileProcessor()