import motor.motor_asyncio
from typing import Optional, List, Dict, Any
from bson import ObjectId
from datetime import datetime
import redis.asyncio as redis
import json
from config import settings


class Database:
    def __init__(self):
        self.client = motor.motor_asyncio.AsyncIOMotorClient(settings.MONGODB_URI)
        self.db = self.client[settings.DATABASE_NAME]
        self.redis_client = None
        
    async def connect_redis(self):
        """Connect to Redis for caching"""
        if not self.redis_client:
            self.redis_client = await redis.from_url(
                settings.REDIS_URL,
                decode_responses=True
            )
        return self.redis_client
    
    async def close(self):
        """Close database connections"""
        if self.redis_client:
            await self.redis_client.close()
        self.client.close()
    
    # User collection operations
    async def get_user(self, user_id: int) -> Optional[Dict]:
        """Get user by Telegram ID"""
        user = await self.db.users.find_one({"id": user_id})
        return user
    
    async def create_user(self, user_data: Dict) -> Dict:
        """Create new user"""
        user_data["joined_date"] = datetime.utcnow()
        user_data["last_active"] = datetime.utcnow()
        result = await self.db.users.insert_one(user_data)
        user_data["_id"] = result.inserted_id
        return user_data
    
    async def update_user(self, user_id: int, update_data: Dict) -> bool:
        """Update user data"""
        update_data["last_active"] = datetime.utcnow()
        result = await self.db.users.update_one(
            {"id": user_id},
            {"$set": update_data}
        )
        return result.modified_count > 0
    
    async def get_all_users(self) -> List[Dict]:
        """Get all users"""
        cursor = self.db.users.find({"is_blocked": False})
        return await cursor.to_list(length=None)
    
    async def get_paid_users(self) -> List[Dict]:
        """Get all users with active payments"""
        cursor = self.db.users.find({
            "payment_status": True,
            "is_blocked": False,
            "$or": [
                {"payment_expiry": {"$exists": False}},
                {"payment_expiry": {"$gt": datetime.utcnow()}}
            ]
        })
        return await cursor.to_list(length=None)
    
    async def get_user_count(self) -> int:
        """Get total user count"""
        return await self.db.users.count_documents({})
    
    # Quiz collection operations
    async def get_active_quiz(self) -> Optional[Dict]:
        """Get currently active quiz"""
        quiz = await self.db.quizzes.find_one({
            "status": "active",
            "is_locked": False
        })
        return quiz
    
    async def get_quiz_by_id(self, quiz_id: str) -> Optional[Dict]:
        """Get quiz by ID"""
        quiz = await self.db.quizzes.find_one({"id": quiz_id})
        return quiz
    
    async def create_quiz(self, quiz_data: Dict) -> Dict:
        """Create new quiz"""
        result = await self.db.quizzes.insert_one(quiz_data)
        quiz_data["_id"] = result.inserted_id
        return quiz_data
    
    async def update_quiz(self, quiz_id: str, update_data: Dict) -> bool:
        """Update quiz data"""
        update_data["updated_at"] = datetime.utcnow()
        result = await self.db.quizzes.update_one(
            {"id": quiz_id},
            {"$set": update_data}
        )
        return result.modified_count > 0
    
    async def get_all_quizzes(self) -> List[Dict]:
        """Get all quizzes"""
        cursor = self.db.quizzes.find().sort("created_at", -1)
        return await cursor.to_list(length=None)
    
    async def get_quiz_participants(self, quiz_id: str) -> List[Dict]:
        """Get all participants for a quiz"""
        cursor = self.db.quiz_sessions.find({
            "quiz_id": quiz_id,
            "status": "completed"
        })
        return await cursor.to_list(length=None)
    
    # Question collection operations
    async def get_questions_by_quiz(self, quiz_id: str) -> List[Dict]:
        """Get all questions for a quiz"""
        cursor = self.db.questions.find({"quiz_id": quiz_id}).sort("question_number", 1)
        return await cursor.to_list(length=None)
    
    async def get_question_by_id(self, question_id: str) -> Optional[Dict]:
        """Get question by ID"""
        question = await self.db.questions.find_one({"id": question_id})
        return question
    
    async def create_question(self, question_data: Dict) -> Dict:
        """Create new question"""
        result = await self.db.questions.insert_one(question_data)
        question_data["_id"] = result.inserted_id
        return question_data
    
    async def bulk_insert_questions(self, questions: List[Dict]) -> List[ObjectId]:
        """Insert multiple questions at once"""
        result = await self.db.questions.insert_many(questions)
        return result.inserted_ids
    
    async def delete_questions_by_quiz(self, quiz_id: str) -> bool:
        """Delete all questions for a quiz"""
        result = await self.db.questions.delete_many({"quiz_id": quiz_id})
        return result.deleted_count > 0
    
    # Quiz session operations
    async def create_quiz_session(self, session_data: Dict) -> Dict:
        """Create new quiz session for user"""
        result = await self.db.quiz_sessions.insert_one(session_data)
        session_data["_id"] = result.inserted_id
        return session_data
    
    async def get_user_session(self, user_id: int, quiz_id: str) -> Optional[Dict]:
        """Get user's active quiz session"""
        session = await self.db.quiz_sessions.find_one({
            "user_id": user_id,
            "quiz_id": quiz_id,
            "status": "in_progress"
        })
        return session
    
    async def update_quiz_session(self, session_id: str, update_data: Dict) -> bool:
        """Update quiz session"""
        result = await self.db.quiz_sessions.update_one(
            {"id": session_id},
            {"$set": update_data}
        )
        return result.modified_count > 0
    
    async def complete_quiz_session(self, session_id: str, score: float) -> bool:
        """Mark quiz session as completed"""
        result = await self.db.quiz_sessions.update_one(
            {"id": session_id},
            {
                "$set": {
                    "status": "completed",
                    "score": score,
                    "end_time": datetime.utcnow()
                }
            }
        )
        return result.modified_count > 0
    
    # Payment operations
    async def create_payment(self, payment_data: Dict) -> Dict:
        """Create new payment record"""
        result = await self.db.payments.insert_one(payment_data)
        payment_data["_id"] = result.inserted_id
        return payment_data
    
    async def get_payment_by_order_id(self, order_id: str) -> Optional[Dict]:
        """Get payment by Razorpay order ID"""
        payment = await self.db.payments.find_one({"razorpay_order_id": order_id})
        return payment
    
    async def update_payment_status(self, payment_id: str, status: str, 
                                   payment_data: Dict = None) -> bool:
        """Update payment status"""
        update_data = {
            "payment_status": status,
            "completed_at": datetime.utcnow() if status == "success" else None
        }
        if payment_data:
            update_data.update(payment_data)
        
        result = await self.db.payments.update_one(
            {"id": payment_id},
            {"$set": update_data}
        )
        return result.modified_count > 0
    
    async def get_user_payments(self, user_id: int) -> List[Dict]:
        """Get all payments for a user"""
        cursor = self.db.payments.find({"user_id": user_id}).sort("created_at", -1)
        return await cursor.to_list(length=None)
    
    async def get_successful_payments(self) -> List[Dict]:
        """Get all successful payments"""
        cursor = self.db.payments.find({"payment_status": "success"})
        return await cursor.to_list(length=None)
    
    # Admin operations
    async def get_admin(self, admin_id: int) -> Optional[Dict]:
        """Get admin by Telegram ID"""
        admin = await self.db.admins.find_one({"id": admin_id, "is_active": True})
        return admin
    
    async def create_admin(self, admin_data: Dict) -> Dict:
        """Create new admin"""
        result = await self.db.admins.insert_one(admin_data)
        admin_data["_id"] = result.inserted_id
        return admin_data
    
    async def get_all_admins(self) -> List[Dict]:
        """Get all active admins"""
        cursor = self.db.admins.find({"is_active": True})
        return await cursor.to_list(length=None)
    
    async def remove_admin(self, admin_id: int) -> bool:
        """Deactivate admin"""
        result = await self.db.admins.update_one(
            {"id": admin_id},
            {"$set": {"is_active": False}}
        )
        return result.modified_count > 0
    
    # Stats and analytics
    async def get_leaderboard(self, quiz_id: str, limit: int = 10) -> List[Dict]:
        """Get quiz leaderboard"""
        pipeline = [
            {"$match": {"quiz_id": quiz_id, "status": "completed"}},
            {"$sort": {"score": -1, "time_taken": 1}},
            {"$limit": limit},
            {"$lookup": {
                "from": "users",
                "localField": "user_id",
                "foreignField": "id",
                "as": "user_info"
            }},
            {"$unwind": "$user_info"},
            {"$project": {
                "user_id": 1,
                "score": 1,
                "time_taken": 1,
                "username": "$user_info.username",
                "first_name": "$user_info.first_name",
                "last_name": "$user_info.last_name"
            }}
        ]
        cursor = self.db.quiz_sessions.aggregate(pipeline)
        return await cursor.to_list(length=None)
    
    async def get_user_stats(self, user_id: int) -> Dict:
        """Get user statistics"""
        pipeline = [
            {"$match": {"user_id": user_id, "status": "completed"}},
            {"$group": {
                "_id": "$user_id",
                "total_quizzes": {"$sum": 1},
                "total_score": {"$sum": "$score"},
                "average_score": {"$avg": "$score"},
                "average_time": {"$avg": "$time_taken"},
                "last_quiz": {"$max": "$end_time"}
            }}
        ]
        cursor = self.db.quiz_sessions.aggregate(pipeline)
        stats = await cursor.to_list(length=1)
        return stats[0] if stats else {}
    
    async def get_earnings_stats(self) -> Dict:
        """Get earnings statistics"""
        pipeline = [
            {"$match": {"payment_status": "success"}},
            {"$group": {
                "_id": None,
                "total_earnings": {"$sum": "$amount"},
                "total_payments": {"$sum": 1},
                "today_earnings": {
                    "$sum": {
                        "$cond": [
                            {"$gte": ["$created_at", datetime.utcnow().replace(hour=0, minute=0, second=0)]},
                            "$amount",
                            0
                        ]
                    }
                },
                "today_payments": {
                    "$sum": {
                        "$cond": [
                            {"$gte": ["$created_at", datetime.utcnow().replace(hour=0, minute=0, second=0)]},
                            1,
                            0
                        ]
                    }
                }
            }}
        ]
        cursor = self.db.payments.aggregate(pipeline)
        stats = await cursor.to_list(length=1)
        return stats[0] if stats else {
            "total_earnings": 0,
            "total_payments": 0,
            "today_earnings": 0,
            "today_payments": 0
        }


# Database instance
db = Database()