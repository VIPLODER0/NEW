import asyncio
import random
from datetime import datetime, timedelta
from typing import List, Dict, Optional, Tuple
from services.database import db
from models.quiz import Quiz, QuizSession, UserQuizAttempt
from models.question import Question
from utils.helpers import format_time


class QuizService:
    def __init__(self):
        self.active_sessions = {}  # user_id -> session_id
        self.question_timers = {}  # session_id -> timer_task
    
    async def start_quiz_for_user(self, user_id: int, quiz_id: str) -> Optional[Dict]:
        """Start quiz for a user"""
        # Check if user has active payment
        user = await db.get_user(user_id)
        if not user or not user.get('payment_status', False):
            # Check payment expiry
            if user and user.get('payment_expiry'):
                if user['payment_expiry'] < datetime.utcnow():
                    await db.update_user(user_id, {"payment_status": False})
                    return None
        
        # Check if quiz exists and is active
        quiz = await db.get_quiz_by_id(quiz_id)
        if not quiz or quiz.get('status') != 'active' or quiz.get('is_locked'):
            return None
        
        # Check if user already has active session
        existing_session = await db.get_user_session(user_id, quiz_id)
        if existing_session:
            return existing_session
        
        # Get questions for the quiz
        questions = await db.get_questions_by_quiz(quiz_id)
        if not questions:
            return None
        
        # Shuffle questions if enabled
        if quiz.get('shuffle_questions', True):
            random.shuffle(questions)
        
        # Create quiz session
        session_data = {
            "id": str(ObjectId()),
            "quiz_id": quiz_id,
            "user_id": user_id,
            "start_time": datetime.utcnow(),
            "current_question_index": 0,
            "answers": [],
            "score": 0.0,
            "status": "in_progress",
            "questions_count": len(questions)
        }
        
        session = await db.create_quiz_session(session_data)
        
        # Store in active sessions
        self.active_sessions[user_id] = session['id']
        
        # Start timer for first question
        await self._start_question_timer(session['id'], 0, quiz.get('duration_minutes', 30))
        
        return session
    
    async def get_current_question(self, session_id: str) -> Optional[Dict]:
        """Get current question for a session"""
        session = await db.quiz_sessions.find_one({"id": session_id})
        if not session:
            return None
        
        quiz_id = session['quiz_id']
        question_index = session['current_question_index']
        
        questions = await db.get_questions_by_quiz(quiz_id)
        if question_index >= len(questions):
            return None
        
        # Don't show correct answer
        question = questions[question_index]
        question_data = {
            "id": question['id'],
            "question_number": question_index + 1,
            "question_text": question['question_text'],
            "options": question['options'],
            "question_type": question.get('question_type', 'mcq'),
            "image_url": question.get('image_url'),
            "time_limit": question.get('time_limit', 30)
        }
        
        return question_data
    
    async def submit_answer(self, user_id: int, session_id: str, 
                          selected_option: int) -> Tuple[bool, Optional[Dict]]:
        """Submit answer for current question"""
        session = await db.quiz_sessions.find_one({"id": session_id})
        if not session or session['user_id'] != user_id:
            return False, None
        
        # Check if already answered
        current_q_index = session['current_question_index']
        for answer in session.get('answers', []):
            if answer.get('question_index') == current_q_index:
                return False, None  # Already answered
        
        # Get current question
        quiz_id = session['quiz_id']
        questions = await db.get_questions_by_quiz(quiz_id)
        
        if current_q_index >= len(questions):
            return False, None
        
        question = questions[current_q_index]
        is_correct = selected_option == question['correct_option']
        
        # Calculate points
        points = question.get('points', 1.0)
        if not is_correct and question.get('negative_marking', False):
            negative_percentage = question.get('negative_mark_percentage', 25.0)
            points = -(points * (negative_percentage / 100))
        
        # Record answer
        answer_data = {
            "question_index": current_q_index,
            "question_id": question['id'],
            "selected_option": selected_option,
            "is_correct": is_correct,
            "points_earned": points if is_correct else 0,
            "answered_at": datetime.utcnow(),
            "time_taken": (datetime.utcnow() - session['start_time']).total_seconds()
        }
        
        # Update session
        await db.quiz_sessions.update_one(
            {"id": session_id},
            {
                "$push": {"answers": answer_data},
                "$inc": {
                    "current_question_index": 1,
                    "score": points if is_correct else 0
                }
            }
        )
        
        # Also record in user attempts collection
        attempt_data = {
            "user_id": user_id,
            "quiz_id": quiz_id,
            "question_id": question['id'],
            "selected_option": selected_option,
            "is_correct": is_correct,
            "time_taken": answer_data['time_taken'],
            "points_earned": points if is_correct else 0
        }
        await db.db.user_attempts.insert_one(attempt_data)
        
        # Stop current timer
        if session_id in self.question_timers:
            self.question_timers[session_id].cancel()
            del self.question_timers[session_id]
        
        # Check if quiz is complete
        session = await db.quiz_sessions.find_one({"id": session_id})
        if session['current_question_index'] >= len(questions):
            await self._complete_quiz(session_id)
            return True, {"quiz_complete": True}
        
        # Start timer for next question
        next_q_index = session['current_question_index']
        if next_q_index < len(questions):
            next_question = questions[next_q_index]
            await self._start_question_timer(session_id, next_q_index, next_question.get('time_limit', 30))
        
        return True, {
            "is_correct": is_correct,
            "next_question_ready": True,
            "current_score": session['score'] + (points if is_correct else 0)
        }
    
    async def skip_question(self, user_id: int, session_id: str) -> bool:
        """Skip current question (mark as wrong)"""
        session = await db.quiz_sessions.find_one({"id": session_id})
        if not session or session['user_id'] != user_id:
            return False
        
        current_q_index = session['current_question_index']
        
        # Record as skipped (wrong)
        answer_data = {
            "question_index": current_q_index,
            "selected_option": None,
            "is_correct": False,
            "points_earned": 0,
            "answered_at": datetime.utcnow(),
            "time_taken": 0
        }
        
        await db.quiz_sessions.update_one(
            {"id": session_id},
            {
                "$push": {"answers": answer_data},
                "$inc": {"current_question_index": 1}
            }
        )
        
        # Move to next question or complete
        quiz_id = session['quiz_id']
        questions = await db.get_questions_by_quiz(quiz_id)
        
        session = await db.quiz_sessions.find_one({"id": session_id})
        if session['current_question_index'] >= len(questions):
            await self._complete_quiz(session_id)
        
        return True
    
    async def _start_question_timer(self, session_id: str, question_index: int, 
                                  time_limit: int):
        """Start timer for a question"""
        async def timer_callback():
            await asyncio.sleep(time_limit)
            
            # Check if question still unanswered
            session = await db.quiz_sessions.find_one({"id": session_id})
            if not session:
                return
            
            # Find if this question was answered
            answered = False
            for answer in session.get('answers', []):
                if answer.get('question_index') == question_index:
                    answered = True
                    break
            
            # If not answered, mark as wrong
            if not answered:
                await self.skip_question(session['user_id'], session_id)
            
            # Clean up timer
            if session_id in self.question_timers:
                del self.question_timers[session_id]
        
        timer_task = asyncio.create_task(timer_callback())
        self.question_timers[session_id] = timer_task
    
    async def _complete_quiz(self, session_id: str):
        """Mark quiz as completed and calculate final score"""
        session = await db.quiz_sessions.find_one({"id": session_id})
        if not session:
            return
        
        # Calculate time taken
        start_time = session['start_time']
        time_taken = (datetime.utcnow() - start_time).total_seconds()
        
        # Update session
        await db.quiz_sessions.update_one(
            {"id": session_id},
            {
                "$set": {
                    "status": "completed",
                    "end_time": datetime.utcnow(),
                    "time_taken": time_taken
                }
            }
        )
        
        # Remove from active sessions
        user_id = session['user_id']
        if user_id in self.active_sessions:
            del self.active_sessions[user_id]
        
        # Update quiz participant count
        quiz_id = session['quiz_id']
        await db.quizzes.update_one(
            {"id": quiz_id},
            {"$inc": {"participant_count": 1}}
        )
    
    async def get_quiz_results(self, user_id: int, quiz_id: str) -> Optional[Dict]:
        """Get quiz results for a user"""
        session = await db.quiz_sessions.find_one({
            "user_id": user_id,
            "quiz_id": quiz_id,
            "status": "completed"
        })
        
        if not session:
            return None
        
        # Calculate stats
        answers = session.get('answers', [])
        total_questions = len(answers)
        correct = sum(1 for a in answers if a.get('is_correct', False))
        wrong = total_questions - correct
        score = session.get('score', 0)
        
        # Get rank
        leaderboard = await db.get_leaderboard(quiz_id, 1000)  # Get all for rank
        rank = None
        for idx, entry in enumerate(leaderboard, 1):
            if entry['user_id'] == user_id:
                rank = idx
                break
        
        return {
            "quiz_id": quiz_id,
            "total_questions": total_questions,
            "correct": correct,
            "wrong": wrong,
            "score": score,
            "rank": rank,
            "time_taken": session.get('time_taken', 0),
            "completed_at": session.get('end_time')
        }
    
    async def get_quiz_summary(self, quiz_id: str) -> Dict:
        """Get summary of quiz for admin"""
        quiz = await db.get_quiz_by_id(quiz_id)
        if not quiz:
            return {}
        
        participants = await db.get_quiz_participants(quiz_id)
        leaderboard = await db.get_leaderboard(quiz_id, 3)
        
        return {
            "title": quiz.get('title', ''),
            "participant_count": len(participants),
            "average_score": sum(p.get('score', 0) for p in participants) / len(participants) if participants else 0,
            "top_3": leaderboard[:3],
            "status": quiz.get('status', ''),
            "start_time": quiz.get('start_time'),
            "end_time": quiz.get('end_time')
        }
    
    async def cleanup_stale_sessions(self):
        """Clean up stale quiz sessions"""
        # Find sessions older than 24 hours
        cutoff = datetime.utcnow() - timedelta(hours=24)
        
        stale_sessions = await db.quiz_sessions.find({
            "status": "in_progress",
            "start_time": {"$lt": cutoff}
        }).to_list(length=None)
        
        for session in stale_sessions:
            await db.quiz_sessions.update_one(
                {"id": session['id']},
                {"$set": {"status": "abandoned"}}
            )
            
            # Remove from active sessions
            user_id = session['user_id']
            if user_id in self.active_sessions:
                del self.active_sessions[user_id]
            
            # Cancel timer if exists
            if session['id'] in self.question_timers:
                self.question_timers[session['id']].cancel()
                del self.question_timers[session['id']]


# Quiz service instance
quiz_service = QuizService()