import os
from typing import List, Optional
from pydantic_settings import BaseSettings
from dotenv import load_dotenv

load_dotenv()

class Settings(BaseSettings):
    # Bot Configuration
    BOT_TOKEN: str
    SUPER_ADMIN_IDS: List[int] = []
    QUIZ_DURATION: int = 60
    MAINTENANCE_MODE: bool = False
    
    # Database
    MONGODB_URI: str = "mongodb://localhost:27017"
    DATABASE_NAME: str = "quiz_bot"
    REDIS_URL: str = "redis://localhost:6379/0"
    
    # Payment
    PAYMENT_PROVIDER: str = "razorpay"
    RAZORPAY_KEY_ID: Optional[str] = None
    RAZORPAY_KEY_SECRET: Optional[str] = None
    PAYMENT_AMOUNT: int = 10  # in paise
    
    # Security
    MAX_QUIZ_JOIN_ATTEMPTS: int = 3
    BROADCAST_RATE_LIMIT: int = 10  # messages per minute
    
    # Logging
    LOG_LEVEL: str = "INFO"
    LOG_FILE: str = "logs/bot.log"
    
    class Config:
        env_file = ".env"
        
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        # Parse SUPER_ADMIN_IDS from comma-separated string
        if isinstance(self.SUPER_ADMIN_IDS, str):
            self.SUPER_ADMIN_IDS = [
                int(id.strip()) for id in self.SUPER_ADMIN_IDS.split(",") if id.strip()
            ]

settings = Settings()