from datetime import datetime
from typing import List, Optional
from enum import Enum
from pydantic import BaseModel, Field
from bson import ObjectId


class AdminRole(str, Enum):
    SUPER_ADMIN = "super_admin"
    ADMIN = "admin"
    MODERATOR = "moderator"


class Admin(BaseModel):
    id: int  # Telegram user ID
    username: Optional[str] = None
    first_name: str
    last_name: Optional[str] = None
    role: AdminRole = AdminRole.ADMIN
    permissions: List[str] = Field(default_factory=list)
    added_by: int  # Who added this admin
    added_at: datetime = Field(default_factory=datetime.utcnow)
    is_active: bool = True
    last_active: datetime = Field(default_factory=datetime.utcnow)
    
    class Config:
        arbitrary_types_allowed = True
        json_encoders = {
            ObjectId: str,
            datetime: lambda dt: dt.isoformat()
        }


class AdminAction(BaseModel):
    id: str = Field(default_factory=lambda: str(ObjectId()))
    admin_id: int
    action: str
    target_id: Optional[int] = None
    details: dict = Field(default_factory=dict)
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    ip_address: Optional[str] = None
    
    class Config:
        arbitrary_types_allowed = True