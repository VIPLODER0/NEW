from datetime import datetime
from typing import Optional
from enum import Enum
from pydantic import BaseModel, Field, validator
from bson import ObjectId


class PaymentStatus(str, Enum):
    PENDING = "pending"
    SUCCESS = "success"
    FAILED = "failed"
    REFUNDED = "refunded"
    CANCELLED = "cancelled"


class PaymentMethod(str, Enum):
    RAZORPAY = "razorpay"
    UPI = "upi"
    WALLET = "wallet"
    COUPON = "coupon"


class Payment(BaseModel):
    id: str = Field(default_factory=lambda: str(ObjectId()))
    user_id: int
    quiz_id: str
    amount: float
    currency: str = "INR"
    payment_method: PaymentMethod
    payment_status: PaymentStatus = PaymentStatus.PENDING
    razorpay_order_id: Optional[str] = None
    razorpay_payment_id: Optional[str] = None
    razorpay_signature: Optional[str] = None
    upi_transaction_id: Optional[str] = None
    coupon_code: Optional[str] = None
    wallet_deduction: float = 0.0
    created_at: datetime = Field(default_factory=datetime.utcnow)
    completed_at: Optional[datetime] = None
    expires_at: Optional[datetime] = None
    metadata: dict = Field(default_factory=dict)
    
    @validator('expires_at', pre=True, always=True)
    def set_expires_at(cls, v, values):
        if v is None and values.get('created_at'):
            from datetime import timedelta
            return values['created_at'] + timedelta(days=1)  # 24-hour validity
        return v
    
    class Config:
        arbitrary_types_allowed = True


class PaymentLog(BaseModel):
    id: str = Field(default_factory=lambda: str(ObjectId()))
    payment_id: str
    user_id: int
    action: str  # created, verified, failed, refunded
    status: PaymentStatus
    amount: float
    metadata: dict = Field(default_factory=dict)
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    ip_address: Optional[str] = None
    user_agent: Optional[str] = None
    
    class Config:
        arbitrary_types_allowed = True