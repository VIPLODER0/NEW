from typing import List, Optional, Dict, Any
from enum import Enum
from pydantic import BaseModel, Field, validator
from bson import ObjectId


class QuestionType(str, Enum):
    MCQ = "mcq"
    TRUE_FALSE = "true_false"
    MULTI_SELECT = "multi_select"


class Question(BaseModel):
    id: str = Field(default_factory=lambda: str(ObjectId()))
    quiz_id: str
    question_number: int
    question_text: str
    question_type: QuestionType = QuestionType.MCQ
    options: List[str] = Field(default_factory=list)
    correct_option: int  # Index of correct option (0-based)
    correct_options: List[int] = Field(default_factory=list)  # For multi-select
    explanation: Optional[str] = None
    points: float = 1.0
    time_limit: int = 30  # seconds per question
    image_url: Optional[str] = None
    audio_url: Optional[str] = None
    difficulty: str = "medium"  # easy, medium, hard
    tags: List[str] = Field(default_factory=list)
    
    @validator('options')
    def validate_options(cls, v):
        if len(v) < 2:
            raise ValueError('At least 2 options required')
        if len(v) > 6:
            raise ValueError('Maximum 6 options allowed')
        return v
    
    @validator('correct_option')
    def validate_correct_option(cls, v, values):
        if 'options' in values and v >= len(values['options']):
            raise ValueError('Correct option index out of range')
        return v
    
    class Config:
        arbitrary_types_allowed = True


class QuestionSet(BaseModel):
    id: str = Field(default_factory=lambda: str(ObjectId()))
    name: str
    description: Optional[str] = None
    quiz_id: str
    questions: List[Question] = Field(default_factory=list)
    total_questions: int = 0
    created_at: datetime = Field(default_factory=datetime.utcnow)
    is_active: bool = True
    
    class Config:
        arbitrary_types_allowed = True