from datetime import datetime
from typing import Optional, List
from pydantic import BaseModel, Field
from bson import ObjectId


class User(BaseModel):
    id: int  # Telegram user ID
    username: Optional[str] = None
    first_name: str
    last_name: Optional[str] = None
    is_premium: bool = False
    quiz_attempts: List[str] = Field(default_factory=list)  # List of quiz IDs attempted
    payment_status: bool = False
    payment_expiry: Optional[datetime] = None
    joined_date: datetime = Field(default_factory=datetime.utcnow)
    last_active: datetime = Field(default_factory=datetime.utcnow)
    is_blocked: bool = False
    wallet_balance: float = 0.0
    
    class Config:
        arbitrary_types_allowed = True
        json_encoders = {
            ObjectId: str,
            datetime: lambda dt: dt.isoformat()
        }


class UserStats(BaseModel):
    user_id: int
    total_quizzes: int = 0
    total_correct: int = 0
    total_wrong: int = 0
    total_skipped: int = 0
    total_score: float = 0.0
    average_time: float = 0.0
    rank: Optional[int] = None
    last_quiz_date: Optional[datetime] = None