from datetime import datetime
from typing import List, Optional, Dict, Any
from enum import Enum
from pydantic import BaseModel, Field
from bson import ObjectId


class QuizStatus(str, Enum):
    DRAFT = "draft"
    SCHEDULED = "scheduled"
    ACTIVE = "active"
    COMPLETED = "completed"
    CANCELLED = "cancelled"


class QuizType(str, Enum):
    PAID = "paid"
    FREE = "free"
    DAILY = "daily"


class Quiz(BaseModel):
    id: str = Field(default_factory=lambda: str(ObjectId()))
    title: str
    description: str
    quiz_type: QuizType = QuizType.PAID
    price: float = 0.0
    duration_minutes: int = 30
    questions_count: int = 0
    shuffle_questions: bool = True
    shuffle_options: bool = True
    negative_marking: bool = False
    negative_mark_percentage: float = 25.0  # 25% negative marking
    start_time: Optional[datetime] = None
    end_time: Optional[datetime] = None
    status: QuizStatus = QuizStatus.DRAFT
    created_by: int  # Admin ID
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    participant_count: int = 0
    question_set_id: Optional[str] = None
    max_participants: Optional[int] = None
    is_locked: bool = False  # Prevent joining after start
    
    class Config:
        arbitrary_types_allowed = True
        json_encoders = {
            ObjectId: str,
            datetime: lambda dt: dt.isoformat()
        }


class QuizSession(BaseModel):
    id: str = Field(default_factory=lambda: str(ObjectId()))
    quiz_id: str
    user_id: int
    start_time: datetime = Field(default_factory=datetime.utcnow)
    end_time: Optional[datetime] = None
    current_question_index: int = 0
    answers: List[Dict[str, Any]] = Field(default_factory=list)
    score: float = 0.0
    status: str = "in_progress"  # in_progress, completed, abandoned
    time_taken: Optional[float] = None  # in seconds
    
    class Config:
        arbitrary_types_allowed = True


class UserQuizAttempt(BaseModel):
    id: str = Field(default_factory=lambda: str(ObjectId()))
    user_id: int
    quiz_id: str
    question_id: str
    selected_option: int
    is_correct: bool
    time_taken: float  # in seconds
    answered_at: datetime = Field(default_factory=datetime.utcnow)
    points_earned: float = 0.0
    
    class Config:
        arbitrary_types_allowed = True