from aiogram import BaseMiddleware
from aiogram.types import Message, CallbackQuery
from typing import Callable, Dict, Any, Awaitable
from datetime import datetime, timedelta
import asyncio


class ThrottlingMiddleware(BaseMiddleware):
    def __init__(self, rate_limit: float = 0.5):
        self.rate_limit = rate_limit
        self.user_last_message = {}
        super().__init__()
    
    async def __call__(
        self,
        handler: Callable[[Message, Dict[str, Any]], Awaitable[Any]],
        event: Message | CallbackQuery,
        data: Dict[str, Any]
    ) -> Any:
        user_id = event.from_user.id
        current_time = datetime.now()
        
        # Check if user is throttled
        if user_id in self.user_last_message:
            last_time = self.user_last_message[user_id]
            time_diff = (current_time - last_time).total_seconds()
            
            if time_diff < self.rate_limit:
                # User is sending messages too fast
                if isinstance(event, Message):
                    await event.answer(
                        "⏳ Please wait a moment before sending another message.",
                        show_alert=True
                    )
                elif isinstance(event, CallbackQuery):
                    await event.answer(
                        "⏳ Please wait...",
                        show_alert=True
                    )
                return
        
        # Update last message time
        self.user_last_message[user_id] = current_time
        
        # Clean old entries (older than 1 hour)
        self._clean_old_entries()
        
        # Call handler
        return await handler(event, data)
    
    def _clean_old_entries(self):
        """Clean old throttle entries"""
        current_time = datetime.now()
        one_hour_ago = current_time - timedelta(hours=1)
        
        to_remove = [
            user_id for user_id, last_time in self.user_last_message.items()
            if last_time < one_hour_ago
        ]
        
        for user_id in to_remove:
            del self.user_last_message[user_id]