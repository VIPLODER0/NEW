import json
from typing import Dict, List, Any, Tuple, Optional
from datetime import datetime


def validate_quiz_json(data: Dict) -> Tuple[bool, Optional[Dict], str]:
    """Validate quiz JSON structure"""
    try:
        # Check required fields
        required_fields = ['quiz_id', 'questions']
        for field in required_fields:
            if field not in data:
                return False, None, f"Missing required field: {field}"
        
        # Validate quiz_id
        quiz_id = data['quiz_id']
        if not isinstance(quiz_id, str) or len(quiz_id.strip()) < 3:
            return False, None, "quiz_id must be a string with at least 3 characters"
        
        # Validate questions
        questions = data['questions']
        if not isinstance(questions, list):
            return False, None, "questions must be a list"
        
        if len(questions) == 0:
            return False, None, "At least one question is required"
        
        if len(questions) > 100:
            return False, None, "Maximum 100 questions allowed"
        
        validated_questions = []
        
        for idx, q in enumerate(questions):
            # Check question structure
            if not isinstance(q, dict):
                return False, None, f"Question {idx + 1} must be a dictionary"
            
            # Check required question fields
            q_required = ['question', 'options', 'correct']
            for field in q_required:
                if field not in q:
                    return False, None, f"Question {idx + 1} missing field: {field}"
            
            question_text = q['question']
            if not isinstance(question_text, str) or len(question_text.strip()) < 3:
                return False, None, f"Question {idx + 1} text must be at least 3 characters"
            
            options = q['options']
            if not isinstance(options, list):
                return False, None, f"Question {idx + 1} options must be a list"
            
            if len(options) < 2:
                return False, None, f"Question {idx + 1} must have at least 2 options"
            
            if len(options) > 6:
                return False, None, f"Question {idx + 1} can have maximum 6 options"
            
            # Validate all options are strings
            for opt_idx, option in enumerate(options):
                if not isinstance(option, str) or len(option.strip()) == 0:
                    return False, None, f"Question {idx + 1}, option {opt_idx + 1} must be non-empty string"
            
            correct = q['correct']
            if not isinstance(correct, int):
                return False, None, f"Question {idx + 1} correct must be an integer"
            
            if correct < 0 or correct >= len(options):
                return False, None, f"Question {idx + 1} correct index out of range"
            
            # Optional fields validation
            if 'points' in q and not isinstance(q['points'], (int, float)):
                return False, None, f"Question {idx + 1} points must be a number"
            
            if 'time_limit' in q and not isinstance(q['time_limit'], int):
                return False, None, f"Question {idx + 1} time_limit must be an integer"
            
            if 'explanation' in q and not isinstance(q['explanation'], str):
                return False, None, f"Question {idx + 1} explanation must be a string"
            
            if 'difficulty' in q and q['difficulty'] not in ['easy', 'medium', 'hard']:
                return False, None, f"Question {idx + 1} difficulty must be easy, medium, or hard"
            
            # Create validated question
            validated_q = {
                'id': idx + 1,
                'question': question_text.strip(),
                'options': [opt.strip() for opt in options],
                'correct': correct,
                'points': q.get('points', 1.0),
                'time_limit': q.get('time_limit', 30),
                'explanation': q.get('explanation', '').strip(),
                'difficulty': q.get('difficulty', 'medium'),
                'tags': q.get('tags', []) if isinstance(q.get('tags'), list) else []
            }
            
            validated_questions.append(validated_q)
        
        # Create validated data structure
        validated_data = {
            'quiz_id': quiz_id.strip(),
            'title': data.get('title', 'Unnamed Quiz').strip(),
            'description': data.get('description', '').strip(),
            'duration': data.get('duration', 60),
            'price': data.get('price', 100.0),
            'shuffle': data.get('shuffle', True),
            'shuffle_options': data.get('shuffle_options', True),
            'negative_marking': data.get('negative_marking', False),
            'negative_mark_percentage': data.get('negative_mark_percentage', 25.0),
            'questions': validated_questions,
            'validated_at': datetime.utcnow().isoformat()
        }
        
        return True, validated_data, f"Validation successful: {len(validated_questions)} questions"
        
    except Exception as e:
        return False, None, f"Validation error: {str(e)}"


def validate_question_data(question_data: Dict) -> Tuple[bool, str]:
    """Validate individual question data"""
    try:
        if 'question_text' not in question_data:
            return False, "Missing question_text"
        
        if 'options' not in question_data:
            return False, "Missing options"
        
        if 'correct_option' not in question_data:
            return False, "Missing correct_option"
        
        question_text = question_data['question_text']
        if len(question_text.strip()) < 3:
            return False, "Question text too short"
        
        options = question_data['options']
        if not isinstance(options, list) or len(options) < 2:
            return False, "Need at least 2 options"
        
        correct_option = question_data['correct_option']
        if not isinstance(correct_option, int) or correct_option < 0 or correct_option >= len(options):
            return False, "Invalid correct_option index"
        
        return True, "Question data is valid"
        
    except Exception as e:
        return False, f"Validation error: {str(e)}"


def export_questions_to_json(questions: List[Dict], quiz_id: str) -> Dict:
    """Export questions to JSON format"""
    export_data = {
        'quiz_id': quiz_id,
        'export_date': datetime.utcnow().isoformat(),
        'question_count': len(questions),
        'questions': []
    }
    
    for q in questions:
        question_export = {
            'question': q.get('question_text', ''),
            'options': q.get('options', []),
            'correct': q.get('correct_option', 0),
            'points': q.get('points', 1.0),
            'time_limit': q.get('time_limit', 30),
            'difficulty': q.get('difficulty', 'medium'),
            'explanation': q.get('explanation', ''),
            'tags': q.get('tags', [])
        }
        export_data['questions'].append(question_export)
    
    return export_data