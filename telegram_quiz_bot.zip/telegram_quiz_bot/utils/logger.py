import logging
import sys
from pathlib import Path
from typing import Optional
from config import settings


def setup_logger(name: str = "quiz_bot", log_file: Optional[str] = None) -> logging.Logger:
    """Setup logger with console and file handlers"""
    
    # Create logger
    logger = logging.getLogger(name)
    logger.setLevel(getattr(logging, settings.LOG_LEVEL.upper()))
    
    # Remove existing handlers
    logger.handlers.clear()
    
    # Create formatter
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    
    # Console handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)
    
    # File handler
    if log_file:
        # Create logs directory if not exists
        log_path = Path(log_file)
        log_path.parent.mkdir(parents=True, exist_ok=True)
        
        file_handler = logging.FileHandler(log_file, encoding='utf-8')
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
    
    return logger


# Global logger instance
logger = setup_logger("quiz_bot", settings.LOG_FILE)


def log_user_action(user_id: int, action: str, details: dict = None):
    """Log user actions"""
    log_msg = f"USER {user_id} - {action}"
    if details:
        log_msg += f" | {details}"
    logger.info(log_msg)


def log_admin_action(admin_id: int, action: str, target_id: int = None, details: dict = None):
    """Log admin actions"""
    log_msg = f"ADMIN {admin_id} - {action}"
    if target_id:
        log_msg += f" | Target: {target_id}"
    if details:
        log_msg += f" | {details}"
    logger.info(log_msg)


def log_payment(payment_id: str, user_id: int, amount: float, status: str):
    """Log payment events"""
    logger.info(f"PAYMENT {payment_id} - User: {user_id}, Amount: {amount}, Status: {status}")


def log_quiz_event(quiz_id: str, event: str, details: dict = None):
    """Log quiz events"""
    log_msg = f"QUIZ {quiz_id} - {event}"
    if details:
        log_msg += f" | {details}"
    logger.info(log_msg)


def log_error(error_type: str, error_msg: str, exc_info: bool = False):
    """Log errors"""
    logger.error(f"ERROR {error_type}: {error_msg}", exc_info=exc_info)