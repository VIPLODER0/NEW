from aiogram.fsm.state import State, StatesGroup


class UserStates(StatesGroup):
    """User states"""
    waiting_for_answer = State()
    viewing_results = State()
    payment_process = State()
    coupon_entry = State()


class AdminStates(StatesGroup):
    """Admin states"""
    waiting_for_quiz_title = State()
    waiting_for_quiz_description = State()
    waiting_for_quiz_price = State()
    waiting_for_quiz_duration = State()
    waiting_for_json_file = State()
    waiting_for_broadcast_message = State()
    waiting_for_single_broadcast = State()
    waiting_for_admin_id = State()
    waiting_for_coupon_code = State()
    editing_leaderboard = State()
    export_data_selection = State()


class QuizStates(StatesGroup):
    """Quiz management states"""
    quiz_active = State()
    quiz_ended = State()
    results_published = State()


class PaymentStates(StatesGroup):
    """Payment states"""
    waiting_for_payment = State()
    verifying_payment = State()
    processing_upi = State()