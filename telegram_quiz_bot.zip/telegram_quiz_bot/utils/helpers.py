import re
import random
import string
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional
from math import ceil


def format_time(seconds: int) -> str:
    """Format seconds to MM:SS"""
    minutes = seconds // 60
    seconds = seconds % 60
    return f"{minutes:02d}:{seconds:02d}"


def format_datetime(dt: datetime) -> str:
    """Format datetime to readable string"""
    if not dt:
        return "N/A"
    
    # Convert to local time (IST)
    local_dt = dt + timedelta(hours=5, minutes=30)
    return local_dt.strftime("%d %b %Y, %I:%M %p")


def format_currency(amount: float, currency: str = "INR") -> str:
    """Format currency amount"""
    if currency == "INR":
        return f"₹{amount:,.2f}"
    elif currency == "USD":
        return f"${amount:,.2f}"
    else:
        return f"{amount:,.2f} {currency}"


def split_message(message: str, max_length: int = 4096) -> List[str]:
    """Split long message into chunks"""
    if len(message) <= max_length:
        return [message]
    
    # Try to split at paragraph breaks
    paragraphs = message.split('\n\n')
    chunks = []
    current_chunk = ""
    
    for para in paragraphs:
        if len(current_chunk) + len(para) + 2 <= max_length:
            current_chunk += para + '\n\n'
        else:
            if current_chunk:
                chunks.append(current_chunk.strip())
            current_chunk = para + '\n\n'
    
    if current_chunk:
        chunks.append(current_chunk.strip())
    
    # If still too long, split by sentences
    if any(len(chunk) > max_length for chunk in chunks):
        chunks = []
        sentences = re.split(r'(?<=[.!?])\s+', message)
        current_chunk = ""
        
        for sentence in sentences:
            if len(current_chunk) + len(sentence) + 1 <= max_length:
                current_chunk += sentence + ' '
            else:
                if current_chunk:
                    chunks.append(current_chunk.strip())
                current_chunk = sentence + ' '
        
        if current_chunk:
            chunks.append(current_chunk.strip())
    
    return chunks


def generate_random_id(length: int = 8) -> str:
    """Generate random ID"""
    return ''.join(random.choices(string.ascii_letters + string.digits, k=length))


def calculate_score(correct: int, total: int, time_taken: float, 
                   max_time: float = 1800) -> float:
    """Calculate score with time bonus"""
    base_score = (correct / total) * 100 if total > 0 else 0
    
    # Time bonus: faster completion = higher bonus
    time_bonus = max(0, (max_time - time_taken) / max_time * 10)
    
    return round(base_score + time_bonus, 2)


def sanitize_text(text: str) -> str:
    """Sanitize text for safe display"""
    # Remove or escape HTML/Markdown
    text = re.sub(r'[<>*_`\[\]()]', '', text)
    # Limit length
    if len(text) > 2000:
        text = text[:1997] + "..."
    return text


def paginate_items(items: List[Any], page: int, per_page: int = 10) -> Dict:
    """Paginate list of items"""
    total_items = len(items)
    total_pages = ceil(total_items / per_page)
    
    if page < 1:
        page = 1
    elif page > total_pages:
        page = total_pages
    
    start_idx = (page - 1) * per_page
    end_idx = start_idx + per_page
    
    paginated_items = items[start_idx:end_idx]
    
    return {
        "items": paginated_items,
        "page": page,
        "per_page": per_page,
        "total_items": total_items,
        "total_pages": total_pages,
        "has_prev": page > 1,
        "has_next": page < total_pages
    }


def format_leaderboard_entry(entry: Dict, rank: int) -> str:
    """Format leaderboard entry for display"""
    username = entry.get('username') or entry.get('first_name', 'User')
    score = entry.get('score', 0)
    time_taken = entry.get('time_taken', 0)
    
    # Rank emoji
    if rank == 1:
        rank_emoji = "🥇"
    elif rank == 2:
        rank_emoji = "🥈"
    elif rank == 3:
        rank_emoji = "🥉"
    else:
        rank_emoji = f"{rank}."
    
    time_str = format_time(int(time_taken))
    
    return f"{rank_emoji} {username}: {score:.1f} points ({time_str})"


def validate_phone_number(phone: str) -> bool:
    """Validate Indian phone number"""
    pattern = r'^(\+91[\-\s]?)?[6-9]\d{9}$'
    return bool(re.match(pattern, phone))


def validate_email(email: str) -> bool:
    """Validate email address"""
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return bool(re.match(pattern, email))


def truncate_text(text: str, max_length: int = 50) -> str:
    """Truncate text with ellipsis"""
    if len(text) <= max_length:
        return text
    return text[:max_length-3] + "..."


def get_days_until(target_date: datetime) -> int:
    """Get days until target date"""
    now = datetime.utcnow()
    delta = target_date - now
    return max(0, delta.days)


def get_human_readable_time(seconds: int) -> str:
    """Convert seconds to human readable time"""
    if seconds < 60:
        return f"{seconds} seconds"
    elif seconds < 3600:
        minutes = seconds // 60
        return f"{minutes} minute{'s' if minutes > 1 else ''}"
    else:
        hours = seconds // 3600
        minutes = (seconds % 3600) // 60
        return f"{hours} hour{'s' if hours > 1 else ''} {minutes} minute{'s' if minutes > 1 else ''}"