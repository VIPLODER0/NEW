from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils.keyboard import InlineKeyboardBuilder
from typing import List, Optional


def get_admin_main_menu(is_super_admin: bool = False) -> InlineKeyboardMarkup:
    """Get admin main menu"""
    builder = InlineKeyboardBuilder()
    
    builder.row(
        InlineKeyboardButton(text="➕ Add Quiz", callback_data="admin_add_quiz"),
        InlineKeyboardButton(text="🧠 Manage Questions", callback_data="admin_manage_questions")
    )
    
    builder.row(
        InlineKeyboardButton(text="▶️ Start Quiz", callback_data="admin_start_quiz"),
        InlineKeyboardButton(text="⏹️ Stop Quiz", callback_data="admin_stop_quiz")
    )
    
    builder.row(
        InlineKeyboardButton(text="📢 Broadcast", callback_data="admin_broadcast"),
        InlineKeyboardButton(text="📊 Stats & Earnings", callback_data="admin_stats")
    )
    
    if is_super_admin:
        builder.row(
            InlineKeyboardButton(text="👤 Manage Admins", callback_data="admin_manage_admins"),
            InlineKeyboardButton(text="⚙️ Maintenance", callback_data="admin_maintenance")
        )
    
    builder.row(
        InlineKeyboardButton(text="ℹ️ Admin Help", callback_data="admin_help"),
        InlineKeyboardButton(text="🔙 User Menu", callback_data="back_to_main")
    )
    
    return builder.as_markup()


def get_admin_quiz_menu() -> InlineKeyboardMarkup:
    """Get admin quiz management menu"""
    builder = InlineKeyboardBuilder()
    
    builder.row(
        InlineKeyboardButton(text="📤 Upload JSON", callback_data="admin_upload_json"),
        InlineKeyboardButton(text="📝 Create Manually", callback_data="admin_create_manual")
    )
    
    builder.row(
        InlineKeyboardButton(text="📋 View All Quizzes", callback_data="admin_view_quizzes"),
        InlineKeyboardButton(text="✏️ Edit Quiz", callback_data="admin_edit_quiz")
    )
    
    builder.row(
        InlineKeyboardButton(text="🗑️ Delete Quiz", callback_data="admin_delete_quiz"),
        InlineKeyboardButton(text="📊 Quiz Stats", callback_data="admin_quiz_stats")
    )
    
    builder.row(
        InlineKeyboardButton(text="🔙 Back", callback_data="back_to_admin"),
        InlineKeyboardButton(text="🏠 Main", callback_data="back_to_main")
    )
    
    return builder.as_markup()


def get_admin_broadcast_menu() -> InlineKeyboardMarkup:
    """Get admin broadcast menu"""
    builder = InlineKeyboardBuilder()
    
    builder.row(
        InlineKeyboardButton(text="📢 To All Users", callback_data="broadcast_all"),
        InlineKeyboardButton(text="💰 To Paid Users", callback_data="broadcast_paid")
    )
    
    builder.row(
        InlineKeyboardButton(text="👤 To Single User", callback_data="broadcast_single"),
        InlineKeyboardButton(text="📋 Broadcast History", callback_data="broadcast_history")
    )
    
    builder.row(
        InlineKeyboardButton(text="🔙 Back", callback_data="back_to_admin"),
        InlineKeyboardButton(text="🏠 Main", callback_data="back_to_main")
    )
    
    return builder.as_markup()


def get_admin_stats_menu() -> InlineKeyboardMarkup:
    """Get admin stats menu"""
    builder = InlineKeyboardBuilder()
    
    builder.row(
        InlineKeyboardButton(text="📈 Total Earnings", callback_data="stats_earnings"),
        InlineKeyboardButton(text="👥 User Stats", callback_data="stats_users")
    )
    
    builder.row(
        InlineKeyboardButton(text="📊 Quiz Performance", callback_data="stats_quizzes"),
        InlineKeyboardButton(text="💳 Payment Report", callback_data="stats_payments")
    )
    
    builder.row(
        InlineKeyboardButton(text="📤 Export Data", callback_data="stats_export"),
        InlineKeyboardButton(text="📋 Daily Report", callback_data="stats_daily")
    )
    
    builder.row(
        InlineKeyboardButton(text="🔙 Back", callback_data="back_to_admin"),
        InlineKeyboardButton(text="🏠 Main", callback_data="back_to_main")
    )
    
    return builder.as_markup()


def get_admin_manage_admins_menu() -> InlineKeyboardMarkup:
    """Get admin management menu (super admin only)"""
    builder = InlineKeyboardBuilder()
    
    builder.row(
        InlineKeyboardButton(text="➕ Add Admin", callback_data="admin_add"),
        InlineKeyboardButton(text="➖ Remove Admin", callback_data="admin_remove")
    )
    
    builder.row(
        InlineKeyboardButton(text="📋 List Admins", callback_data="admin_list"),
        InlineKeyboardButton(text="🔄 Change Role", callback_data="admin_change_role")
    )
    
    builder.row(
        InlineKeyboardButton(text="🏆 Edit Leaderboard", callback_data="admin_edit_leaderboard"),
        InlineKeyboardButton(text="⚙️ Toggle Maintenance", callback_data="admin_toggle_maintenance")
    )
    
    builder.row(
        InlineKeyboardButton(text="🔙 Back", callback_data="back_to_admin"),
        InlineKeyboardButton(text="🏠 Main", callback_data="back_to_main")
    )
    
    return builder.as_markup()


def get_quiz_selection_keyboard(quizzes: List[Dict], action: str, 
                              page: int = 1) -> InlineKeyboardMarkup:
    """Get keyboard for selecting a quiz"""
    builder = InlineKeyboardBuilder()
    
    for quiz in quizzes:
        quiz_id = quiz.get('id', '')
        quiz_title = quiz.get('title', 'Unnamed Quiz')[:30]
        builder.add(InlineKeyboardButton(
            text=f"{quiz_title} ({quiz.get('status', 'draft')})",
            callback_data=f"{action}:{quiz_id}"
        ))
    
    builder.adjust(1)  # One button per row
    
    # Add navigation if needed
    builder.row(
        InlineKeyboardButton(text="🔙 Back", callback_data="back_to_admin"),
        InlineKeyboardButton(text="🔄 Refresh", callback_data=f"refresh_{action}")
    )
    
    return builder.as_markup()


def get_broadcast_confirmation() -> InlineKeyboardMarkup:
    """Get broadcast confirmation keyboard"""
    builder = InlineKeyboardBuilder()
    
    builder.row(
        InlineKeyboardButton(text="✅ Yes, Send Now", callback_data="broadcast_confirm"),
        InlineKeyboardButton(text="✏️ Edit Message", callback_data="broadcast_edit")
    )
    
    builder.row(
        InlineKeyboardButton(text="❌ Cancel", callback_data="broadcast_cancel"),
        InlineKeyboardButton(text="⏰ Schedule", callback_data="broadcast_schedule")
    )
    
    return builder.as_markup()


def get_admin_actions_keyboard(quiz_id: str) -> InlineKeyboardMarkup:
    """Get admin actions for a specific quiz"""
    builder = InlineKeyboardBuilder()
    
    builder.row(
        InlineKeyboardButton(text="▶️ Start Quiz", callback_data=f"quiz_start:{quiz_id}"),
        InlineKeyboardButton(text="⏹️ Stop Quiz", callback_data=f"quiz_stop:{quiz_id}")
    )
    
    builder.row(
        InlineKeyboardButton(text="🔒 Lock/Unlock", callback_data=f"quiz_lock:{quiz_id}"),
        InlineKeyboardButton(text="📊 View Results", callback_data=f"quiz_results:{quiz_id}")
    )
    
    builder.row(
        InlineKeyboardButton(text="✏️ Edit Questions", callback_data=f"quiz_edit:{quiz_id}"),
        InlineKeyboardButton(text="🗑️ Delete Quiz", callback_data=f"quiz_delete:{quiz_id}")
    )
    
    builder.row(
        InlineKeyboardButton(text="🔙 Back", callback_data="back_to_quizzes"),
        InlineKeyboardButton(text="🏠 Main", callback_data="back_to_main")
    )
    
    return builder.as_markup()


def get_export_options() -> InlineKeyboardMarkup:
    """Get data export options"""
    builder = InlineKeyboardBuilder()
    
    builder.row(
        InlineKeyboardButton(text="👤 Users Data", callback_data="export_users"),
        InlineKeyboardButton(text="💳 Payments Data", callback_data="export_payments")
    )
    
    builder.row(
        InlineKeyboardButton(text="📊 Quiz Results", callback_data="export_results"),
        InlineKeyboardButton(text="📈 Earnings Report", callback_data="export_earnings")
    )
    
    builder.row(
        InlineKeyboardButton(text="🔙 Back", callback_data="back_to_stats"),
        InlineKeyboardButton(text="🏠 Main", callback_data="back_to_main")
    )
    
    return builder.as_markup()


def get_maintenance_keyboard(maintenance_enabled: bool) -> InlineKeyboardMarkup:
    """Get maintenance mode keyboard"""
    builder = InlineKeyboardBuilder()
    
    status_text = "🟢 ON" if maintenance_enabled else "🔴 OFF"
    toggle_text = "🔴 Disable" if maintenance_enabled else "🟢 Enable"
    
    builder.row(
        InlineKeyboardButton(text=f"Maintenance: {status_text}", callback_data="no_action")
    )
    
    builder.row(
        InlineKeyboardButton(text=toggle_text, callback_data="maintenance_toggle"),
        InlineKeyboardButton(text="📋 Status", callback_data="maintenance_status")
    )
    
    builder.row(
        InlineKeyboardButton(text="🔙 Back", callback_data="back_to_admin"),
        InlineKeyboardButton(text="🏠 Main", callback_data="back_to_main")
    )
    
    return builder.as_markup()