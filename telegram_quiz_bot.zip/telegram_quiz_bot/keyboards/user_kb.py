from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils.keyboard import InlineKeyboardBuilder
from typing import List, Optional


def get_main_menu() -> InlineKeyboardMarkup:
    """Get main menu keyboard for users"""
    builder = InlineKeyboardBuilder()
    
    builder.row(
        InlineKeyboardButton(text="▶️ Join Quiz", callback_data="join_quiz"),
        InlineKeyboardButton(text="🧠 Quiz Rules", callback_data="quiz_rules")
    )
    
    builder.row(
        InlineKeyboardButton(text="📊 My Results", callback_data="my_results"),
        InlineKeyboardButton(text="🏆 Leaderboard", callback_data="leaderboard")
    )
    
    builder.row(
        InlineKeyboardButton(text="💳 Payment Status", callback_data="payment_status"),
        InlineKeyboardButton(text="ℹ️ Help", callback_data="help")
    )
    
    return builder.as_markup()


def get_quiz_options() -> InlineKeyboardMarkup:
    """Get quiz options keyboard"""
    builder = InlineKeyboardBuilder()
    
    builder.row(
        InlineKeyboardButton(text="✅ Start Quiz", callback_data="start_quiz"),
        InlineKeyboardButton(text="📋 Rules", callback_data="view_rules")
    )
    
    builder.row(
        InlineKeyboardButton(text="💳 Check Payment", callback_data="check_payment"),
        InlineKeyboardButton(text="🔙 Back", callback_data="back_to_main")
    )
    
    return builder.as_markup()


def get_payment_options(quiz_id: str) -> InlineKeyboardMarkup:
    """Get payment options keyboard"""
    builder = InlineKeyboardBuilder()
    
    builder.row(
        InlineKeyboardButton(text="💳 Pay with Razorpay", callback_data=f"pay_razorpay:{quiz_id}"),
        InlineKeyboardButton(text="📱 Pay with UPI", callback_data=f"pay_upi:{quiz_id}")
    )
    
    builder.row(
        InlineKeyboardButton(text="🎫 Apply Coupon", callback_data=f"apply_coupon:{quiz_id}"),
        InlineKeyboardButton(text="💰 Use Wallet", callback_data=f"use_wallet:{quiz_id}")
    )
    
    builder.row(
        InlineKeyboardButton(text="🔙 Back", callback_data="back_to_quiz"),
        InlineKeyboardButton(text="ℹ️ Help", callback_data="payment_help")
    )
    
    return builder.as_markup()


def get_question_keyboard(options: List[str], question_id: str, 
                         can_skip: bool = True) -> InlineKeyboardMarkup:
    """Get keyboard for quiz question with options"""
    builder = InlineKeyboardBuilder()
    
    # Add option buttons (A, B, C, D...)
    for idx, option in enumerate(options):
        button_text = f"{chr(65 + idx)}. {option[:30]}"
        builder.add(InlineKeyboardButton(
            text=button_text,
            callback_data=f"answer:{question_id}:{idx}"
        ))
    
    builder.adjust(2)  # 2 buttons per row
    
    if can_skip:
        builder.row(
            InlineKeyboardButton(text="⏭️ Skip", callback_data="skip_question"),
            InlineKeyboardButton(text="⏹️ End Quiz", callback_data="end_quiz")
        )
    
    return builder.as_markup()


def get_results_keyboard(quiz_id: str) -> InlineKeyboardMarkup:
    """Get keyboard for quiz results"""
    builder = InlineKeyboardBuilder()
    
    builder.row(
        InlineKeyboardButton(text="🏆 View Leaderboard", callback_data=f"view_leaderboard:{quiz_id}"),
        InlineKeyboardButton(text="📊 Detailed Results", callback_data=f"detailed_results:{quiz_id}")
    )
    
    builder.row(
        InlineKeyboardButton(text="📈 My Stats", callback_data="my_stats"),
        InlineKeyboardButton(text="💳 Next Quiz", callback_data="next_quiz")
    )
    
    builder.row(
        InlineKeyboardButton(text="🏠 Main Menu", callback_data="back_to_main")
    )
    
    return builder.as_markup()


def get_leaderboard_navigation(quiz_id: str, page: int, total_pages: int) -> InlineKeyboardMarkup:
    """Get navigation keyboard for leaderboard"""
    builder = InlineKeyboardBuilder()
    
    if page > 1:
        builder.add(InlineKeyboardButton(
            text="⬅️ Previous",
            callback_data=f"leaderboard:{quiz_id}:{page-1}"
        ))
    
    builder.add(InlineKeyboardButton(
        text=f"{page}/{total_pages}",
        callback_data="no_action"
    ))
    
    if page < total_pages:
        builder.add(InlineKeyboardButton(
            text="Next ➡️",
            callback_data=f"leaderboard:{quiz_id}:{page+1}"
        ))
    
    builder.row(
        InlineKeyboardButton(text="🔄 Refresh", callback_data=f"leaderboard:{quiz_id}:{page}"),
        InlineKeyboardButton(text="🏠 Main Menu", callback_data="back_to_main")
    )
    
    return builder.as_markup()


def get_wallet_options() -> InlineKeyboardMarkup:
    """Get wallet options keyboard"""
    builder = InlineKeyboardBuilder()
    
    builder.row(
        InlineKeyboardButton(text="💰 Add Money", callback_data="add_money"),
        InlineKeyboardButton(text="📜 Transaction History", callback_data="wallet_history")
    )
    
    builder.row(
        InlineKeyboardButton(text="🎫 Buy Coupon", callback_data="buy_coupon"),
        InlineKeyboardButton(text="🏠 Main Menu", callback_data="back_to_main")
    )
    
    return builder.as_markup()


def get_help_keyboard(is_admin: bool = False) -> InlineKeyboardMarkup:
    """Get help keyboard"""
    builder = InlineKeyboardBuilder()
    
    builder.row(
        InlineKeyboardButton(text="❓ How to Play", callback_data="help_play"),
        InlineKeyboardButton(text="💳 Payment Help", callback_data="help_payment")
    )
    
    builder.row(
        InlineKeyboardButton(text="📱 Contact Support", url="https://t.me/quiz_support"),
        InlineKeyboardButton(text="📜 Terms & Conditions", callback_data="help_terms")
    )
    
    if is_admin:
        builder.row(
            InlineKeyboardButton(text="👨‍💼 Admin Help", callback_data="admin_help")
        )
    
    builder.row(
        InlineKeyboardButton(text="🏠 Main Menu", callback_data="back_to_main")
    )
    
    return builder.as_markup()


def get_back_keyboard(target: str = "main") -> InlineKeyboardMarkup:
    """Simple back button keyboard"""
    builder = InlineKeyboardBuilder()
    
    builder.add(InlineKeyboardButton(
        text="🔙 Back",
        callback_data=f"back_to_{target}"
    ))
    
    return builder.as_markup()


def get_confirmation_keyboard(action: str, data: str = "") -> InlineKeyboardMarkup:
    """Get confirmation keyboard"""
    builder = InlineKeyboardBuilder()
    
    builder.row(
        InlineKeyboardButton(text="✅ Yes", callback_data=f"confirm:{action}:{data}"),
        InlineKeyboardButton(text="❌ No", callback_data="cancel_action")
    )
    
    return builder.as_markup()


def get_pagination_keyboard(current_page: int, total_pages: int, 
                          prefix: str) -> InlineKeyboardMarkup:
    """Get pagination keyboard"""
    builder = InlineKeyboardBuilder()
    
    if current_page > 1:
        builder.add(InlineKeyboardButton(
            text="⬅️",
            callback_data=f"{prefix}:{current_page-1}"
        ))
    
    builder.add(InlineKeyboardButton(
        text=f"{current_page}/{total_pages}",
        callback_data="no_action"
    ))
    
    if current_page < total_pages:
        builder.add(InlineKeyboardButton(
            text="➡️",
            callback_data=f"{prefix}:{current_page+1}"
        ))
    
    builder.row(
        InlineKeyboardButton(text="🔄 Refresh", callback_data=f"{prefix}:{current_page}"),
        InlineKeyboardButton(text="🏠 Main Menu", callback_data="back_to_main")
    )
    
    return builder.as_markup()