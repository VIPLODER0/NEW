# hosting_bot.py

import asyncio
import os
import shutil
import signal
import subprocess
import time
import zipfile
from aiogram import Bot, Dispatcher, types
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.filters import Command

# Hard-coded values (replace with actual values)
BOT_TOKEN = '7754507016:AAFbM2e3mm-LlM2bS3TOTDHYqhDNWGy5dj8'
ADMIN_ID = 1929943036  # Replace with actual admin Telegram ID

# Directories
UPLOADS_DIR = 'uploads'
EXTRACTED_PREFIX = 'extracted_'
RUNNING_BOT_PID_FILE = 'running_bot.pid'

# Ensure directories exist
os.makedirs(UPLOADS_DIR, exist_ok=True)

# Initialize bot and dispatcher
bot = Bot(token=BOT_TOKEN)
storage = MemoryStorage()
dp = Dispatcher(storage=storage)

def is_admin(user_id: int) -> bool:
    return user_id == ADMIN_ID

def get_bot_status() -> str:
    if os.path.exists(RUNNING_BOT_PID_FILE):
        try:
            with open(RUNNING_BOT_PID_FILE, 'r') as f:
                pid = int(f.read().strip())
            # Check if process is running
            result = subprocess.run(['ps', '-p', str(pid)], capture_output=True, text=True)
            if result.returncode == 0:
                return 'RUNNING'
        except (ValueError, FileNotFoundError):
            pass
    return 'STOPPED'

def stop_running_bot():
    if os.path.exists(RUNNING_BOT_PID_FILE):
        try:
            with open(RUNNING_BOT_PID_FILE, 'r') as f:
                pid = int(f.read().strip())
            os.kill(pid, signal.SIGTERM)
            # Wait a bit for graceful shutdown
            time.sleep(2)
            # Force kill if still running
            try:
                os.kill(pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
        except (ValueError, FileNotFoundError, ProcessLookupError):
            pass
        finally:
            os.remove(RUNNING_BOT_PID_FILE)

def start_new_bot(bot_path: str):
    stop_running_bot()
    process = subprocess.Popen(['python', 'main.py'], cwd=bot_path, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    with open(RUNNING_BOT_PID_FILE, 'w') as f:
        f.write(str(process.pid))

@dp.message(Command('start'))
async def start_command(message: types.Message):
    if not is_admin(message.from_user.id):
        return
    status = get_bot_status()
    text = f"""
**Hosting Bot Control Panel**

**Admin:** {message.from_user.full_name}
**Current Bot Status:** {status}

**Instructions:**
Upload a ZIP file containing the bot project to deploy it.
The ZIP must have the structure: `bot/` with `main.py` and `requirements.txt`.

**Security Notes:**
- Only ZIP files are accepted.
- Deployment will stop any running bot and start the new one.
- Ensure the uploaded code is trusted.
"""
    await message.reply(text, parse_mode='Markdown')

@dp.message(lambda message: message.document)
async def handle_zip_upload(message: types.Message):
    if not is_admin(message.from_user.id):
        return
    document = message.document
    if not document.file_name.endswith('.zip'):
        await message.reply("Only ZIP files are accepted.")
        return
    
    await message.reply("ZIP file received. Starting deployment process...")
    
    # Download the file
    file_path = os.path.join(UPLOADS_DIR, document.file_name)
    await bot.download(document, destination=file_path)
    await message.reply("ZIP downloaded. Extracting...")
    
    # Extract to a unique folder
    extracted_dir = os.path.join(UPLOADS_DIR, f"{EXTRACTED_PREFIX}{int(time.time())}")
    os.makedirs(extracted_dir, exist_ok=True)
    try:
        with zipfile.ZipFile(file_path, 'r') as zip_ref:
            zip_ref.extractall(extracted_dir)
    except Exception as e:
        await message.reply(f"Failed to extract ZIP: {str(e)}")
        shutil.rmtree(extracted_dir, ignore_errors=True)
        return
    
    bot_dir = os.path.join(extracted_dir, 'bot')
    main_py = os.path.join(bot_dir, 'main.py')
    requirements_txt = os.path.join(bot_dir, 'requirements.txt')
    
    if not os.path.exists(main_py) or not os.path.exists(requirements_txt):
        await message.reply("Invalid project structure. Missing `bot/main.py` or `bot/requirements.txt`.")
        shutil.rmtree(extracted_dir, ignore_errors=True)
        return
    
    await message.reply("Project structure validated. Installing dependencies...")
    
    # Install dependencies
    try:
        result = subprocess.run(['pip', 'install', '-r', 'requirements.txt'], cwd=bot_dir, capture_output=True, text=True)
        if result.returncode != 0:
            await message.reply(f"Failed to install dependencies: {result.stderr}")
            shutil.rmtree(extracted_dir, ignore_errors=True)
            return
    except Exception as e:
        await message.reply(f"Error installing dependencies: {str(e)}")
        shutil.rmtree(extracted_dir, ignore_errors=True)
        return
    
    await message.reply("Dependencies installed. Stopping old bot...")
    
    # Stop old bot
    stop_running_bot()
    
    await message.reply("Old bot stopped. Starting new bot...")
    
    # Start new bot
    try:
        start_new_bot(bot_dir)
        await message.reply("New bot started successfully!")
    except Exception as e:
        await message.reply(f"Failed to start new bot: {str(e)}")
        shutil.rmtree(extracted_dir, ignore_errors=True)

async def main():
    await dp.start_polling(bot)

if __name__ == '__main__':
    asyncio.run(main())