from aiogram import Router
from aiogram.types import ErrorEvent
from utils.logger import log_error

router = Router()


@router.errors()
async def error_handler(event: ErrorEvent):
    """Global error handler"""
    exception = event.exception
    
    # Log the error
    log_error(
        type(exception).__name__,
        str(exception),
        exc_info=True
    )
    
    # Don't propagate the error
    return True