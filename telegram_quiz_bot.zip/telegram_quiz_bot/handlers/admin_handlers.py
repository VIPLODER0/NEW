from aiogram import Router, F
from aiogram.types import Message, CallbackQuery, FSInputFile
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from datetime import datetime
import html

from config import settings
from services.database import db
from services.admin_service import admin_service
from services.broadcast_service import broadcast_service
from services.file_processor import file_processor
from keyboards.admin_kb import *
from keyboards.user_kb import get_back_keyboard
from utils.states import AdminStates
from utils.helpers import format_currency, format_datetime, paginate_items
from utils.logger import log_admin_action

router = Router()


@router.message(Command("admin"))
async def cmd_admin(message: Message):
    """Admin command to access admin panel"""
    user_id = message.from_user.id
    
    if not await admin_service.is_admin(user_id):
        await message.answer(
            "⛔ Access Denied\n"
            "You are not authorized to access the admin panel.",
            reply_markup=get_back_keyboard()
        )
        return
    
    is_super_admin = await admin_service.is_super_admin(user_id)
    
    await message.answer(
        f"👨‍💼 <b>Admin Panel</b>\n\n"
        f"🆔 Your ID: <code>{user_id}</code>\n"
        f"🔐 Role: {'Super Admin' if is_super_admin else 'Admin'}\n"
        f"📅 Login: {format_datetime(datetime.utcnow())}\n\n"
        "Please select an option:",
        parse_mode="HTML",
        reply_markup=get_admin_main_menu(is_super_admin)
    )
    
    log_admin_action(user_id, "accessed_admin_panel")


@router.callback_query(F.data == "back_to_admin")
async def back_to_admin(callback: CallbackQuery, state: FSMContext):
    """Return to admin main menu"""
    user_id = callback.from_user.id
    
    if not await admin_service.is_admin(user_id):
        await callback.answer("Access denied", show_alert=True)
        return
    
    await state.clear()
    
    is_super_admin = await admin_service.is_super_admin(user_id)
    
    await callback.message.edit_text(
        f"👨‍💼 <b>Admin Panel</b>\n\n"
        f"🆔 Your ID: <code>{user_id}</code>\n"
        f"🔐 Role: {'Super Admin' if is_super_admin else 'Admin'}\n\n"
        "Please select an option:",
        parse_mode="HTML",
        reply_markup=get_admin_main_menu(is_super_admin)
    )
    await callback.answer()


@router.callback_query(F.data == "admin_add_quiz")
async def admin_add_quiz(callback: CallbackQuery, state: FSMContext):
    """Add new quiz"""
    user_id = callback.from_user.id
    
    if not await admin_service.can_perform_action(user_id, "manage_quizzes"):
        await callback.answer("You don't have permission to add quizzes", show_alert=True)
        return
    
    await callback.message.edit_text(
        "➕ <b>Add New Quiz</b>\n\n"
        "Please select how you want to add questions:",
        parse_mode="HTML",
        reply_markup=get_admin_quiz_menu()
    )
    await callback.answer()


@router.callback_query(F.data == "admin_upload_json")
async def admin_upload_json(callback: CallbackQuery, state: FSMContext):
    """Upload quiz JSON file"""
    user_id = callback.from_user.id
    
    if not await admin_service.can_perform_action(user_id, "manage_quizzes"):
        await callback.answer("Permission denied", show_alert=True)
        return
    
    await state.set_state(AdminStates.waiting_for_json_file)
    
    await callback.message.edit_text(
        "📤 <b>Upload Quiz JSON</b>\n\n"
        "Please upload a JSON file with quiz questions.\n\n"
        "<b>JSON Format:</b>\n"
        "{\n"
        '  "quiz_id": "quiz_001",\n'
        '  "title": "General Knowledge",\n'
        '  "questions": [\n'
        '    {\n'
        '      "question": "2+2?",\n'
        '      "options": ["1", "2", "3", "4"],\n'
        '      "correct": 3\n'
        '    }\n'
        '  ]\n'
        "}\n\n"
        "<b>Note:</b>\n"
        "• Maximum 100 questions\n"
        "• Correct option is 0-based index\n"
        "• File size limit: 5MB",
        parse_mode="HTML",
        reply_markup=get_back_keyboard("admin")
    )
    await callback.answer()


@router.message(AdminStates.waiting_for_json_file)
async def process_json_file(message: Message, state: FSMContext):
    """Process uploaded JSON file"""
    user_id = message.from_user.id
    
    if not message.document:
        await message.answer(
            "❌ Please upload a JSON file.\n"
            "Click 'Back' to cancel.",
            reply_markup=get_back_keyboard("admin")
        )
        return
    
    if not message.document.file_name.endswith('.json'):
        await message.answer(
            "❌ File must be a JSON file (.json)\n"
            "Please upload a valid JSON file.",
            reply_markup=get_back_keyboard("admin")
        )
        return
    
    # Download file
    try:
        file_info = await message.bot.get_file(message.document.file_id)
        downloaded_file = await message.bot.download_file(file_info.file_path)
        file_content = downloaded_file.read()
        
        # Save file
        filename = f"quiz_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}_{user_id}.json"
        filepath = await file_processor.save_uploaded_file(file_content, filename)
        
        # Process JSON
        success, quiz_data, message_text = await file_processor.process_quiz_json(filepath)
        
        if not success:
            await message.answer(
                f"❌ {message_text}\n\n"
                "Please fix the errors and upload again.",
                reply_markup=get_back_keyboard("admin")
            )
            return
        
        # Create quiz from JSON
        quiz_info = await file_processor.create_quiz_from_json(quiz_data, user_id)
        
        # Save to database
        quiz_doc = quiz_info["quiz"]
        questions = quiz_info["questions"]
        
        await db.create_quiz(quiz_doc)
        await db.bulk_insert_questions(questions)
        
        await state.clear()
        
        await message.answer(
            f"✅ <b>Quiz Created Successfully!</b>\n\n"
            f"📝 Title: {quiz_doc['title']}\n"
            f"🆔 ID: {quiz_doc['id']}\n"
            f"📊 Questions: {len(questions)}\n"
            f"💰 Price: {format_currency(quiz_doc['price'])}\n"
            f"⏰ Duration: {quiz_doc['duration_minutes']} minutes\n\n"
            f"Status: <b>{quiz_doc['status'].upper()}</b>\n\n"
            "You can now start the quiz from the admin panel.",
            parse_mode="HTML",
            reply_markup=get_back_keyboard("admin")
        )
        
        log_admin_action(user_id, "created_quiz", None, {
            "quiz_id": quiz_doc['id'],
            "questions": len(questions)
        })
        
    except Exception as e:
        await message.answer(
            f"❌ Error processing file: {str(e)}\n"
            "Please try again or contact support.",
            reply_markup=get_back_keyboard("admin")
        )


@router.callback_query(F.data == "admin_start_quiz")
async def admin_start_quiz(callback: CallbackQuery):
    """Start a quiz"""
    user_id = callback.from_user.id
    
    if not await admin_service.can_perform_action(user_id, "start_quiz"):
        await callback.answer("You don't have permission to start quizzes", show_alert=True)
        return
    
    # Get all draft or scheduled quizzes
    quizzes = await db.db.quizzes.find({
        "status": {"$in": ["draft", "scheduled"]}
    }).sort("created_at", -1).to_list(length=10)
    
    if not quizzes:
        await callback.message.edit_text(
            "📭 No quizzes available to start.\n"
            "Create a quiz first or check scheduled quizzes.",
            reply_markup=get_back_keyboard("admin")
        )
        await callback.answer()
        return
    
    await callback.message.edit_text(
        "▶️ <b>Start Quiz</b>\n\n"
        "Select a quiz to start:",
        parse_mode="HTML",
        reply_markup=get_quiz_selection_keyboard(quizzes, "quiz_start")
    )
    await callback.answer()


@router.callback_query(F.data.startswith("quiz_start:"))
async def start_selected_quiz(callback: CallbackQuery):
    """Start selected quiz"""
    user_id = callback.from_user.id
    quiz_id = callback.data.split(":")[1]
    
    if not await admin_service.can_perform_action(user_id, "start_quiz"):
        await callback.answer("Permission denied", show_alert=True)
        return
    
    # Update quiz status
    await db.update_quiz(quiz_id, {
        "status": "active",
        "start_time": datetime.utcnow(),
        "is_locked": False
    })
    
    # Get quiz info
    quiz = await db.get_quiz_by_id(quiz_id)
    
    await callback.message.edit_text(
        f"✅ <b>Quiz Started!</b>\n\n"
        f"📝 {quiz['title']}\n"
        f"🆔 {quiz_id}\n"
        f"⏰ Started: {format_datetime(datetime.utcnow())}\n\n"
        "Users can now join this quiz.\n"
        "Use 'Stop Quiz' to end it.",
        parse_mode="HTML",
        reply_markup=get_back_keyboard("admin")
    )
    
    log_admin_action(user_id, "started_quiz", None, {"quiz_id": quiz_id})


@router.callback_query(F.data == "admin_stop_quiz")
async def admin_stop_quiz(callback: CallbackQuery):
    """Stop active quiz"""
    user_id = callback.from_user.id
    
    if not await admin_service.can_perform_action(user_id, "stop_quiz"):
        await callback.answer("Permission denied", show_alert=True)
        return
    
    # Get active quiz
    active_quiz = await db.get_active_quiz()
    
    if not active_quiz:
        await callback.message.edit_text(
            "📭 No active quiz to stop.",
            reply_markup=get_back_keyboard("admin")
        )
        await callback.answer()
        return
    
    quiz_id = active_quiz['id']
    
    # Update quiz status
    await db.update_quiz(quiz_id, {
        "status": "completed",
        "end_time": datetime.utcnow(),
        "is_locked": True
    })
    
    await callback.message.edit_text(
        f"⏹️ <b>Quiz Stopped!</b>\n\n"
        f"📝 {active_quiz['title']}\n"
        f"🆔 {quiz_id}\n"
        f"⏰ Ended: {format_datetime(datetime.utcnow())}\n\n"
        "Quiz is now completed. Users can view results.",
        parse_mode="HTML",
        reply_markup=get_back_keyboard("admin")
    )
    
    log_admin_action(user_id, "stopped_quiz", None, {"quiz_id": quiz_id})
    await callback.answer()


@router.callback_query(F.data == "admin_broadcast")
async def admin_broadcast(callback: CallbackQuery):
    """Admin broadcast menu"""
    user_id = callback.from_user.id
    
    if not await admin_service.can_perform_action(user_id, "broadcast"):
        await callback.answer("You don't have permission to broadcast", show_alert=True)
        return
    
    await callback.message.edit_text(
        "📢 <b>Broadcast Messages</b>\n\n"
        "Send messages to users:\n"
        "• All users (including unpaid)\n"
        "• Paid users only\n"
        "• Single user by ID\n\n"
        "Select an option:",
        parse_mode="HTML",
        reply_markup=get_admin_broadcast_menu()
    )
    await callback.answer()


@router.callback_query(F.data == "broadcast_all")
async def broadcast_all(callback: CallbackQuery, state: FSMContext):
    """Broadcast to all users"""
    user_id = callback.from_user.id
    
    if not await admin_service.can_perform_action(user_id, "broadcast"):
        await callback.answer("Permission denied", show_alert=True)
        return
    
    await state.set_state(AdminStates.waiting_for_broadcast_message)
    await state.update_data(broadcast_type="all")
    
    await callback.message.edit_text(
        "📢 <b>Broadcast to All Users</b>\n\n"
        "Please send the message you want to broadcast.\n\n"
        "<b>Supported:</b>\n"
        "• Text messages\n"
        "• Photos with captions\n"
        "• Documents\n\n"
        "<b>Note:</b> Messages longer than 4096 characters will be split automatically.",
        parse_mode="HTML",
        reply_markup=get_back_keyboard("admin")
    )
    await callback.answer()


@router.message(AdminStates.waiting_for_broadcast_message)
async def process_broadcast_message(message: Message, state: FSMContext):
    """Process broadcast message"""
    user_id = message.from_user.id
    state_data = await state.get_data()
    broadcast_type = state_data.get("broadcast_type", "all")
    
    # Get target users count
    if broadcast_type == "all":
        users = await db.get_all_users()
        target_text = "all users"
    else:  # paid
        users = await db.get_paid_users()
        target_text = "paid users"
    
    user_count = len(users)
    
    if user_count == 0:
        await message.answer(
            f"No {target_text} found to broadcast.",
            reply_markup=get_back_keyboard("admin")
        )
        await state.clear()
        return
    
    # Store message for confirmation
    await state.update_data({
        "broadcast_message": message.text or message.caption,
        "broadcast_media": None,
        "message_type": "text"
    })
    
    if message.photo:
        await state.update_data({
            "broadcast_media": message.photo[-1].file_id,
            "message_type": "photo"
        })
    elif message.document:
        await state.update_data({
            "broadcast_media": message.document.file_id,
            "message_type": "document"
        })
    
    await message.answer(
        f"📢 <b>Broadcast Confirmation</b>\n\n"
        f"Target: {target_text}\n"
        f"Recipients: {user_count} users\n\n"
        f"Message preview:\n"
        f"{'-'*30}\n"
        f"{message.text or message.caption or '[Media message]'[:100]}...\n"
        f"{'-'*30}\n\n"
        f"Are you sure you want to send this broadcast?",
        parse_mode="HTML",
        reply_markup=get_broadcast_confirmation()
    )


@router.callback_query(F.data == "broadcast_confirm")
async def confirm_broadcast(callback: CallbackQuery, state: FSMContext):
    """Confirm and send broadcast"""
    user_id = callback.from_user.id
    state_data = await state.get_data()
    
    broadcast_type = state_data.get("broadcast_type", "all")
    message_type = state_data.get("message_type", "text")
    
    # Send broadcast
    if broadcast_type == "all":
        result = await broadcast_service.broadcast_to_all(
            callback.bot,
            state_data.get("broadcast_message", ""),
            None,
            message_type
        )
    else:  # paid
        result = await broadcast_service.broadcast_to_paid(
            callback.bot,
            state_data.get("broadcast_message", ""),
            None,
            message_type
        )
    
    await state.clear()
    
    await callback.message.edit_text(
        f"✅ <b>Broadcast Sent!</b>\n\n"
        f"Task ID: {result['task_id']}\n"
        f"Target users: {result['total_users']}\n"
        f"Successful: {result['successful']}\n"
        f"Failed: {result['failed']}\n"
        f"Success rate: {result['success_rate']:.1f}%\n\n"
        f"Broadcast completed at: {format_datetime(datetime.utcnow())}",
        parse_mode="HTML",
        reply_markup=get_back_keyboard("admin")
    )
    
    log_admin_action(user_id, "sent_broadcast", None, {
        "type": broadcast_type,
        "users": result['total_users'],
        "successful": result['successful']
    })
    await callback.answer()


@router.callback_query(F.data == "admin_stats")
async def admin_stats(callback: CallbackQuery):
    """Admin statistics menu"""
    user_id = callback.from_user.id
    
    if not await admin_service.can_perform_action(user_id, "view_stats"):
        await callback.answer("You don't have permission to view stats", show_alert=True)
        return
    
    stats = await admin_service.get_admin_stats()
    
    stats_text = (
        "📊 <b>Admin Dashboard</b>\n\n"
        f"👥 Total Users: {stats['total_users']}\n"
        f"🏆 Active Quiz: {stats['active_quiz'] or 'None'}\n"
        f"📈 Quiz Status: {stats['quiz_status'].upper()}\n"
        f"💰 Total Earnings: {format_currency(stats['total_earnings'])}\n"
        f"📅 Today's Earnings: {format_currency(stats['today_earnings'])}\n\n"
        "<b>Recent Payments:</b>\n"
    )
    
    for payment in stats['recent_payments'][:5]:
        stats_text += f"• User {payment['user_id']}: {format_currency(payment['amount'])}\n"
    
    await callback.message.edit_text(
        stats_text,
        parse_mode="HTML",
        reply_markup=get_admin_stats_menu()
    )
    await callback.answer()


@router.callback_query(F.data == "stats_earnings")
async def stats_earnings(callback: CallbackQuery):
    """Show earnings statistics"""
    user_id = callback.from_user.id
    
    if not await admin_service.can_perform_action(user_id, "view_earnings"):
        await callback.answer("Permission denied", show_alert=True)
        return
    
    from services.payment_service import payment_service
    earnings = await payment_service.get_earnings_report()
    
    earnings_text = (
        "💰 <b>Earnings Report</b>\n\n"
        f"📅 Period: {format_datetime(earnings['date_range']['start'])} to {format_datetime(earnings['date_range']['end'])}\n\n"
        f"📈 Total Earnings: {format_currency(earnings['total_earnings'])}\n"
        f"📋 Total Payments: {earnings['total_payments']}\n"
        f"📊 Average Order Value: {format_currency(earnings['average_order_value'])}\n\n"
        "<b>Daily Breakdown:</b>\n"
    )
    
    for day in earnings['daily_breakdown'][-7:]:  # Last 7 days
        earnings_text += (
            f"• {day['date']}: {format_currency(day['amount'])} "
            f"({day['count']} payments)\n"
        )
    
    await callback.message.edit_text(
        earnings_text,
        parse_mode="HTML",
        reply_markup=get_back_keyboard("stats")
    )
    await callback.answer()


@router.callback_query(F.data == "admin_manage_admins")
async def admin_manage_admins(callback: CallbackQuery):
    """Manage admins (super admin only)"""
    user_id = callback.from_user.id
    
    if not await admin_service.is_super_admin(user_id):
        await callback.answer("Only super admins can manage admins", show_alert=True)
        return
    
    await callback.message.edit_text(
        "👤 <b>Manage Admins</b>\n\n"
        "Super Admin Panel:\n"
        "• Add new admins\n"
        "• Remove admins\n"
        "• Change roles\n"
        "• View all admins\n"
        "• Edit leaderboard\n"
        "• Maintenance mode\n\n"
        "Select an option:",
        parse_mode="HTML",
        reply_markup=get_admin_manage_admins_menu()
    )
    await callback.answer()


@router.callback_query(F.data == "admin_add")
async def admin_add(callback: CallbackQuery, state: FSMContext):
    """Add new admin"""
    user_id = callback.from_user.id
    
    if not await admin_service.is_super_admin(user_id):
        await callback.answer("Permission denied", show_alert=True)
        return
    
    await state.set_state(AdminStates.waiting_for_admin_id)
    
    await callback.message.edit_text(
        "➕ <b>Add New Admin</b>\n\n"
        "Please send the Telegram User ID of the person you want to make admin.\n\n"
        "<b>How to get User ID:</b>\n"
        "1. Ask user to send /id command\n"
        "2. They will receive their ID\n"
        "3. Forward that ID to you\n\n"
        "Enter the User ID:",
        parse_mode="HTML",
        reply_markup=get_back_keyboard("admin")
    )
    await callback.answer()


@router.message(AdminStates.waiting_for_admin_id)
async def process_admin_id(message: Message, state: FSMContext):
    """Process admin ID"""
    user_id = message.from_user.id
    new_admin_id = message.text.strip()
    
    try:
        new_admin_id = int(new_admin_id)
    except ValueError:
        await message.answer(
            "❌ Invalid User ID. Please enter a numeric ID.",
            reply_markup=get_back_keyboard("admin")
        )
        return
    
    # Check if user exists
    target_user = await db.get_user(new_admin_id)
    if not target_user:
        await message.answer(
            f"❌ User with ID {new_admin_id} not found.\n"
            "The user must use /start with the bot first.",
            reply_markup=get_back_keyboard("admin")
        )
        return
    
    # Add as admin
    success = await admin_service.add_admin(new_admin_id, user_id)
    
    if success:
        await message.answer(
            f"✅ <b>Admin Added Successfully!</b>\n\n"
            f"👤 User: {target_user.get('first_name', 'Unknown')}\n"
            f"🆔 ID: {new_admin_id}\n"
            f"👨‍💼 Role: Admin\n"
            f"📅 Added: {format_datetime(datetime.utcnow())}\n\n"
            "The user now has admin access.",
            parse_mode="HTML",
            reply_markup=get_back_keyboard("admin")
        )
        
        # Notify new admin
        try:
            await message.bot.send_message(
                new_admin_id,
                f"🎉 <b>You are now an Admin!</b>\n\n"
                f"Congratulations! You have been granted admin access to the Quiz Bot.\n\n"
                f"Use /admin to access the admin panel.\n"
                f"Use /start to return to user menu.",
                parse_mode="HTML"
            )
        except:
            pass  # Couldn't notify, but admin was added
    else:
        await message.answer(
            "❌ Failed to add admin.\n"
            "User might already be an admin.",
            reply_markup=get_back_keyboard("admin")
        )
    
    await state.clear()


@router.callback_query(F.data == "admin_list")
async def admin_list(callback: CallbackQuery):
    """List all admins"""
    user_id = callback.from_user.id
    
    if not await admin_service.is_super_admin(user_id):
        await callback.answer("Permission denied", show_alert=True)
        return
    
    admins = await admin_service.get_all_admins()
    
    if not admins:
        await callback.message.edit_text(
            "📭 No admins found.\n"
            "Add admins using the 'Add Admin' option.",
            reply_markup=get_back_keyboard("admin")
        )
        await callback.answer()
        return
    
    admins_text = "👥 <b>Admin List</b>\n\n"
    
    for admin in admins:
        role_emoji = "👑" if admin['role'] == 'super_admin' else "👨‍💼"
        status_emoji = "🟢" if admin['is_active'] else "🔴"
        
        admins_text += (
            f"{role_emoji} <b>{admin.get('first_name', 'Unknown')}</b>\n"
            f"   🆔 ID: {admin['id']}\n"
            f"   📛 Role: {admin['role'].replace('_', ' ').title()}\n"
            f"   📅 Added: {format_datetime(admin['added_at'])}\n"
            f"   {status_emoji} Status: {'Active' if admin['is_active'] else 'Inactive'}\n\n"
        )
    
    await callback.message.edit_text(
        admins_text,
        parse_mode="HTML",
        reply_markup=get_back_keyboard("admin")
    )
    await callback.answer()


@router.callback_query(F.data == "admin_maintenance")
async def admin_maintenance(callback: CallbackQuery):
    """Maintenance mode control"""
    user_id = callback.from_user.id
    
    if not await admin_service.is_super_admin(user_id):
        await callback.answer("Only super admins can control maintenance", show_alert=True)
        return
    
    await callback.message.edit_text(
        "⚙️ <b>Maintenance Mode</b>\n\n"
        "When enabled:\n"
        "• Users see maintenance message\n"
        "• New quiz joins are blocked\n"
        "• Admins can still access panel\n\n"
        "Current status:",
        parse_mode="HTML",
        reply_markup=get_maintenance_keyboard(settings.MAINTENANCE_MODE)
    )
    await callback.answer()


@router.callback_query(F.data == "maintenance_toggle")
async def maintenance_toggle(callback: CallbackQuery):
    """Toggle maintenance mode"""
    user_id = callback.from_user.id
    
    if not await admin_service.is_super_admin(user_id):
        await callback.answer("Permission denied", show_alert=True)
        return
    
    new_status = not settings.MAINTENANCE_MODE
    success = await admin_service.toggle_maintenance_mode(user_id, new_status)
    
    if success:
        status_text = "enabled" if new_status else "disabled"
        await callback.message.edit_text(
            f"✅ <b>Maintenance Mode {status_text.title()}</b>\n\n"
            f"Status changed at: {format_datetime(datetime.utcnow())}\n\n"
            "Users will {'see maintenance message' if new_status else 'have normal access'}.",
            parse_mode="HTML",
            reply_markup=get_maintenance_keyboard(new_status)
        )
    else:
        await callback.answer("Failed to toggle maintenance mode", show_alert=True)
    
    await callback.answer()


@router.callback_query(F.data == "stats_export")
async def stats_export(callback: CallbackQuery, state: FSMContext):
    """Export data"""
    user_id = callback.from_user.id
    
    if not await admin_service.can_perform_action(user_id, "export_data"):
        await callback.answer("Permission denied", show_alert=True)
        return
    
    await callback.message.edit_text(
        "📤 <b>Export Data</b>\n\n"
        "Select the type of data to export:\n\n"
        "• Users Data: All registered users\n"
        "• Payments Data: All successful payments\n"
        "• Quiz Results: All completed quiz sessions\n"
        "• Earnings Report: Detailed earnings breakdown",
        parse_mode="HTML",
        reply_markup=get_export_options()
    )
    await callback.answer()


@router.callback_query(F.data.startswith("export_"))
async def export_selected_data(callback: CallbackQuery):
    """Export selected data type"""
    user_id = callback.from_user.id
    data_type = callback.data.replace("export_", "")
    
    if not await admin_service.can_perform_action(user_id, "export_data"):
        await callback.answer("Permission denied", show_alert=True)
        return
    
    await callback.answer("Generating export file...")
    
    # Get data
    data = await admin_service.export_data(user_id, data_type)
    
    if not data:
        await callback.message.answer(
            "❌ No data available for export.",
            reply_markup=get_back_keyboard("stats")
        )
        return
    
    # Generate CSV
    csv_content = await file_processor.generate_stats_csv(data)
    
    # Create file
    filename = f"{data_type}_export_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.csv"
    filepath = file_processor.upload_dir / filename
    
    async with aiofiles.open(filepath, 'w', encoding='utf-8') as f:
        await f.write(csv_content)
    
    # Send file
    await callback.message.answer_document(
        FSInputFile(filepath),
        caption=f"📤 {data_type.title()} Export\n"
               f"📅 Generated: {format_datetime(datetime.utcnow())}\n"
               f"📊 Records: {len(data)}"
    )
    
    # Clean up
    await file_processor.cleanup_old_files()


# Add more admin handlers as needed...