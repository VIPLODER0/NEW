from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.filters import CommandStart, Command
from aiogram.fsm.context import FSMContext
from datetime import datetime
import html

from config import settings
from services.database import db
from services.admin_service import admin_service
from keyboards.user_kb import *
from keyboards.admin_kb import get_admin_main_menu
from utils.states import UserStates
from utils.helpers import format_currency, format_datetime
from utils.logger import log_user_action

router = Router()


@router.message(CommandStart())
async def cmd_start(message: Message, state: FSMContext):
    """Handle /start command"""
    user_id = message.from_user.id
    username = message.from_user.username
    first_name = message.from_user.first_name
    last_name = message.from_user.last_name
    
    # Check maintenance mode
    if settings.MAINTENANCE_MODE:
        await message.answer(
            "🚧 Bot is under maintenance. Please try again later.",
            reply_markup=get_back_keyboard()
        )
        return
    
    # Register or update user
    user = await db.get_user(user_id)
    if not user:
        user_data = {
            "id": user_id,
            "username": username,
            "first_name": first_name,
            "last_name": last_name,
            "is_premium": message.from_user.is_premium or False,
            "joined_date": datetime.utcnow(),
            "last_active": datetime.utcnow()
        }
        await db.create_user(user_data)
        log_user_action(user_id, "registered", {"username": username})
    else:
        await db.update_user(user_id, {"last_active": datetime.utcnow()})
    
    # Clear any existing state
    await state.clear()
    
    # Check if user is admin
    is_admin = await admin_service.is_admin(user_id)
    
    if is_admin:
        is_super_admin = await admin_service.is_super_admin(user_id)
        await message.answer(
            f"👋 Welcome back, {first_name}!\n\n"
            f"🆔 Your ID: <code>{user_id}</code>\n"
            f"👨‍💼 Role: {'Super Admin' if is_super_admin else 'Admin'}\n\n"
            "Please select an option:",
            parse_mode="HTML",
            reply_markup=get_admin_main_menu(is_super_admin)
        )
    else:
        await message.answer(
            f"🎉 Welcome to Quiz Bot, {first_name}!\n\n"
            "Test your knowledge, compete with others, and win exciting prizes!\n\n"
            "Please select an option:",
            reply_markup=get_main_menu()
        )
    
    log_user_action(user_id, "started_bot")


@router.callback_query(F.data == "back_to_main")
async def back_to_main(callback: CallbackQuery, state: FSMContext):
    """Return to main menu"""
    user_id = callback.from_user.id
    await state.clear()
    
    is_admin = await admin_service.is_admin(user_id)
    
    if is_admin:
        is_super_admin = await admin_service.is_super_admin(user_id)
        await callback.message.edit_text(
            f"👋 Welcome back!\n\n"
            f"🆔 Your ID: <code>{user_id}</code>\n"
            f"👨‍💼 Role: {'Super Admin' if is_super_admin else 'Admin'}\n\n"
            "Please select an option:",
            parse_mode="HTML",
            reply_markup=get_admin_main_menu(is_super_admin)
        )
    else:
        await callback.message.edit_text(
            "🎉 Welcome to Quiz Bot!\n\n"
            "Test your knowledge, compete with others, and win exciting prizes!\n\n"
            "Please select an option:",
            reply_markup=get_main_menu()
        )
    
    await callback.answer()


@router.callback_query(F.data == "join_quiz")
async def join_quiz(callback: CallbackQuery, state: FSMContext):
    """Handle join quiz button"""
    user_id = callback.from_user.id
    
    # Check if user is blocked
    user = await db.get_user(user_id)
    if user and user.get('is_blocked'):
        await callback.message.edit_text(
            "❌ Your account has been blocked.\n"
            "Please contact support for assistance.",
            reply_markup=get_back_keyboard()
        )
        await callback.answer()
        return
    
    # Get active quiz
    active_quiz = await db.get_active_quiz()
    
    if not active_quiz:
        await callback.message.edit_text(
            "📭 No active quiz at the moment.\n\n"
            "Please check back later or wait for announcements.",
            reply_markup=get_back_keyboard()
        )
        await callback.answer()
        return
    
    quiz_id = active_quiz['id']
    quiz_title = active_quiz['title']
    quiz_price = active_quiz.get('price', 0)
    
    # Check payment status
    from services.payment_service import payment_service
    payment_status = await payment_service.check_payment_status(user_id, quiz_id)
    
    if payment_status['has_payment']:
        # User has payment, show quiz options
        await callback.message.edit_text(
            f"📝 <b>{quiz_title}</b>\n\n"
            f"💰 Price: {format_currency(quiz_price)}\n"
            f"⏰ Duration: {active_quiz.get('duration_minutes', 30)} minutes\n"
            f"📊 Questions: {active_quiz.get('questions_count', 0)}\n\n"
            f"✅ <b>Payment Status: Active</b>\n"
            f"⏳ Expires: {format_datetime(payment_status.get('expires_at'))}\n\n"
            "Click 'Start Quiz' to begin:",
            parse_mode="HTML",
            reply_markup=get_quiz_options()
        )
    else:
        # Payment required
        await callback.message.edit_text(
            f"📝 <b>{quiz_title}</b>\n\n"
            f"💰 Price: {format_currency(quiz_price)}\n"
            f"⏰ Duration: {active_quiz.get('duration_minutes', 30)} minutes\n"
            f"📊 Questions: {active_quiz.get('questions_count', 0)}\n\n"
            "❌ <b>Payment Required</b>\n"
            "You need to make a payment to join this quiz.\n\n"
            "Please select a payment method:",
            parse_mode="HTML",
            reply_markup=get_payment_options(quiz_id)
        )
    
    await callback.answer()


@router.callback_query(F.data == "quiz_rules")
async def quiz_rules(callback: CallbackQuery):
    """Show quiz rules"""
    rules_text = (
        "📋 <b>Quiz Rules:</b>\n\n"
        "1. ✅ <b>Payment Required:</b> You must make payment before joining any paid quiz\n"
        "2. ⏰ <b>Time Limit:</b> Each question has a time limit (usually 30 seconds)\n"
        "3. 🔒 <b>Single Answer:</b> You can only select one answer per question\n"
        "4. ⏭️ <b>Skip:</b> You can skip questions, but they will be marked as wrong\n"
        "5. 🚫 <b>No Cheating:</b> Any cheating attempts will result in disqualification\n"
        "6. 🏆 <b>Scoring:</b> Points are awarded for correct answers\n"
        "7. 📊 <b>Leaderboard:</b> Top performers are displayed on the leaderboard\n"
        "8. ⏳ <b>Payment Validity:</b> Payments are valid for 24 hours\n\n"
        "<b>Important:</b> Answers cannot be changed once submitted.\n"
        "The quiz will auto-submit when time runs out."
    )
    
    await callback.message.edit_text(
        rules_text,
        parse_mode="HTML",
        reply_markup=get_back_keyboard()
    )
    await callback.answer()


@router.callback_query(F.data == "my_results")
async def my_results(callback: CallbackQuery):
    """Show user's quiz results"""
    user_id = callback.from_user.id
    
    # Get user's completed quiz sessions
    sessions = await db.db.quiz_sessions.find({
        "user_id": user_id,
        "status": "completed"
    }).sort("end_time", -1).limit(5).to_list(length=5)
    
    if not sessions:
        await callback.message.edit_text(
            "📊 <b>My Results</b>\n\n"
            "You haven't completed any quizzes yet.\n"
            "Join a quiz to see your results here!",
            parse_mode="HTML",
            reply_markup=get_back_keyboard()
        )
        await callback.answer()
        return
    
    results_text = "📊 <b>My Recent Results:</b>\n\n"
    
    for session in sessions:
        quiz_id = session['quiz_id']
        quiz = await db.get_quiz_by_id(quiz_id)
        quiz_title = quiz.get('title', 'Unknown Quiz') if quiz else 'Unknown Quiz'
        
        # Calculate stats
        answers = session.get('answers', [])
        total = len(answers)
        correct = sum(1 for a in answers if a.get('is_correct', False))
        score = session.get('score', 0)
        
        results_text += (
            f"📝 <b>{quiz_title}</b>\n"
            f"   ✅ Correct: {correct}/{total}\n"
            f"   📈 Score: {score:.1f}\n"
            f"   📅 Date: {format_datetime(session.get('end_time'))}\n\n"
        )
    
    # Get overall stats
    stats = await db.get_user_stats(user_id)
    if stats:
        results_text += (
            f"📈 <b>Overall Statistics:</b>\n"
            f"   🏆 Total Quizzes: {stats.get('total_quizzes', 0)}\n"
            f"   📊 Average Score: {stats.get('average_score', 0):.1f}\n"
            f"   ⏱️ Average Time: {stats.get('average_time', 0):.0f}s\n"
        )
    
    await callback.message.edit_text(
        results_text,
        parse_mode="HTML",
        reply_markup=get_back_keyboard()
    )
    await callback.answer()


@router.callback_query(F.data == "leaderboard")
async def show_leaderboard(callback: CallbackQuery):
    """Show global leaderboard"""
    # Get active quiz first
    active_quiz = await db.get_active_quiz()
    
    if not active_quiz:
        await callback.message.edit_text(
            "🏆 <b>Leaderboard</b>\n\n"
            "No active quiz at the moment.\n"
            "Please check back when a quiz is running.",
            parse_mode="HTML",
            reply_markup=get_back_keyboard()
        )
        await callback.answer()
        return
    
    quiz_id = active_quiz['id']
    quiz_title = active_quiz['title']
    
    # Get leaderboard
    leaderboard = await db.get_leaderboard(quiz_id, 10)
    
    if not leaderboard:
        await callback.message.edit_text(
            f"🏆 <b>Leaderboard - {quiz_title}</b>\n\n"
            "No results yet. Be the first to complete the quiz!",
            parse_mode="HTML",
            reply_markup=get_back_keyboard()
        )
        await callback.answer()
        return
    
    leaderboard_text = f"🏆 <b>Leaderboard - {quiz_title}</b>\n\n"
    
    for idx, entry in enumerate(leaderboard[:10], 1):
        username = entry.get('username') or entry.get('first_name', 'User')
        score = entry.get('score', 0)
        time_taken = entry.get('time_taken', 0)
        
        # Rank emoji
        if idx == 1:
            rank_emoji = "🥇"
        elif idx == 2:
            rank_emoji = "🥈"
        elif idx == 3:
            rank_emoji = "🥉"
        else:
            rank_emoji = f"{idx}."
        
        # Format time
        minutes = int(time_taken // 60)
        seconds = int(time_taken % 60)
        time_str = f"{minutes}:{seconds:02d}"
        
        leaderboard_text += f"{rank_emoji} {username}: {score:.1f} points ({time_str})\n"
    
    # Check user's rank
    user_id = callback.from_user.id
    user_rank = None
    user_score = None
    
    for idx, entry in enumerate(leaderboard, 1):
        if entry['user_id'] == user_id:
            user_rank = idx
            user_score = entry.get('score', 0)
            break
    
    if user_rank:
        leaderboard_text += f"\n👤 <b>Your Rank:</b> #{user_rank} ({user_score:.1f} points)"
    
    await callback.message.edit_text(
        leaderboard_text,
        parse_mode="HTML",
        reply_markup=get_leaderboard_navigation(quiz_id, 1, 1)
    )
    await callback.answer()


@router.callback_query(F.data == "payment_status")
async def payment_status(callback: CallbackQuery):
    """Show user's payment status"""
    user_id = callback.from_user.id
    user = await db.get_user(user_id)
    
    if not user:
        await callback.message.edit_text(
            "❌ User not found. Please use /start to register.",
            reply_markup=get_back_keyboard()
        )
        await callback.answer()
        return
    
    payment_active = user.get('payment_status', False)
    payment_expiry = user.get('payment_expiry')
    
    status_text = "🟢 <b>ACTIVE</b>" if payment_active else "🔴 <b>INACTIVE</b>"
    
    message_text = (
        f"💳 <b>Payment Status</b>\n\n"
        f"Status: {status_text}\n"
    )
    
    if payment_active and payment_expiry:
        from datetime import datetime
        now = datetime.utcnow()
        if payment_expiry > now:
            remaining = payment_expiry - now
            hours = int(remaining.total_seconds() // 3600)
            minutes = int((remaining.total_seconds() % 3600) // 60)
            
            message_text += f"⏳ Expires in: {hours}h {minutes}m\n"
            message_text += f"📅 Valid until: {format_datetime(payment_expiry)}\n"
        else:
            message_text += "⏰ <b>Payment has expired</b>\n"
            # Update user status
            await db.update_user(user_id, {"payment_status": False})
    
    # Get recent payments
    from services.payment_service import payment_service
    payments = await payment_service.get_payment_history(user_id)
    
    if payments:
        message_text += "\n📜 <b>Recent Payments:</b>\n"
        for payment in payments[:3]:
            status_emoji = "✅" if payment['status'] == 'success' else "❌"
            message_text += (
                f"{status_emoji} {format_currency(payment['amount'])} - "
                f"{payment['status'].title()} - "
                f"{format_datetime(payment['created_at'])}\n"
            )
    
    message_text += "\nClick 'Join Quiz' to check quiz-specific payment requirements."
    
    await callback.message.edit_text(
        message_text,
        parse_mode="HTML",
        reply_markup=get_back_keyboard()
    )
    await callback.answer()


@router.callback_query(F.data == "help")
async def show_help(callback: CallbackQuery):
    """Show help information"""
    user_id = callback.from_user.id
    is_admin = await admin_service.is_admin(user_id)
    
    help_text = (
        "❓ <b>Help & Support</b>\n\n"
        "<b>How to Play:</b>\n"
        "1. Click 'Join Quiz'\n"
        "2. Make payment if required\n"
        "3. Answer questions within time limit\n"
        "4. View your results and leaderboard\n\n"
        "<b>Payment Methods:</b>\n"
        "• Razorpay (Cards, UPI, NetBanking)\n"
        "• UPI Direct\n"
        "• Wallet Balance\n"
        "• Coupon Codes\n\n"
        "<b>Need Help?</b>\n"
        "• Check Quiz Rules for gameplay details\n"
        "• Contact support for payment issues\n"
        "• Report bugs or suggestions\n\n"
        "<b>Note:</b> All payments are secure and verified."
    )
    
    await callback.message.edit_text(
        help_text,
        parse_mode="HTML",
        reply_markup=get_help_keyboard(is_admin)
    )
    await callback.answer()


@router.callback_query(F.data == "help_play")
async def help_play(callback: CallbackQuery):
    """Detailed help about gameplay"""
    help_text = (
        "🎮 <b>How to Play</b>\n\n"
        "<b>Step 1: Join Quiz</b>\n"
        "• Click 'Join Quiz' from main menu\n"
        "• Check if payment is required\n"
        "• Make payment if needed\n\n"
        "<b>Step 2: Start Quiz</b>\n"
        "• Read instructions carefully\n"
        "• Click 'Start Quiz' when ready\n"
        "• Timer starts immediately\n\n"
        "<b>Step 3: Answer Questions</b>\n"
        "• Read each question carefully\n"
        "• Select one answer from options\n"
        "• Click option button to submit\n"
        "• Use 'Skip' if unsure (marks as wrong)\n"
        "• Time limit per question: 30 seconds\n\n"
        "<b>Step 4: View Results</b>\n"
        "• See your score immediately\n"
        "• Check leaderboard for ranking\n"
        "• View detailed results\n\n"
        "<b>Tips:</b>\n"
        "• Answer quickly for time bonus\n"
        "• Don't skip unless necessary\n"
        "• Check payment expiry time"
    )
    
    await callback.message.edit_text(
        help_text,
        parse_mode="HTML",
        reply_markup=get_back_keyboard("help")
    )
    await callback.answer()


@router.callback_query(F.data.startswith("back_to_"))
async def back_to_previous(callback: CallbackQuery, state: FSMContext):
    """Handle back button"""
    target = callback.data.replace("back_to_", "")
    
    if target == "main":
        await back_to_main(callback, state)
    elif target == "quiz":
        await join_quiz(callback, state)
    elif target == "help":
        await show_help(callback)
    else:
        await back_to_main(callback, state)


@router.message(Command("id"))
async def cmd_id(message: Message):
    """Show user ID"""
    user_id = message.from_user.id
    await message.answer(
        f"🆔 Your User ID: <code>{user_id}</code>\n\n"
        "This ID is used for:\n"
        "• Payment verification\n"
        "• Support requests\n"
        "• Admin actions",
        parse_mode="HTML"
    )


@router.message(Command("stats"))
async def cmd_stats(message: Message):
    """Show user statistics"""
    user_id = message.from_user.id
    
    stats = await db.get_user_stats(user_id)
    user = await db.get_user(user_id)
    
    if not stats or not user:
        await message.answer(
            "📊 No statistics available yet.\n"
            "Complete your first quiz to see stats!",
            reply_markup=get_back_keyboard()
        )
        return
    
    stats_text = (
        f"📊 <b>Your Statistics</b>\n\n"
        f"👤 User: {user.get('first_name', 'User')}\n"
        f"🆔 ID: <code>{user_id}</code>\n"
        f"📅 Joined: {format_datetime(user.get('joined_date'))}\n\n"
        f"🏆 <b>Quiz Stats:</b>\n"
        f"   📋 Total Quizzes: {stats.get('total_quizzes', 0)}\n"
        f"   📈 Average Score: {stats.get('average_score', 0):.1f}\n"
        f"   ⏱️ Average Time: {stats.get('average_time', 0):.0f}s\n"
        f"   📅 Last Quiz: {format_datetime(stats.get('last_quiz'))}\n\n"
        f"💳 <b>Payment Status:</b>\n"
        f"   Status: {'✅ Active' if user.get('payment_status') else '❌ Inactive'}\n"
    )
    
    if user.get('payment_expiry'):
        stats_text += f"   ⏳ Expires: {format_datetime(user.get('payment_expiry'))}\n"
    
    if user.get('wallet_balance', 0) > 0:
        stats_text += f"   💰 Wallet: ₹{user.get('wallet_balance', 0):.2f}\n"
    
    await message.answer(
        stats_text,
        parse_mode="HTML",
        reply_markup=get_back_keyboard()
    )


# Add more user handlers as needed...