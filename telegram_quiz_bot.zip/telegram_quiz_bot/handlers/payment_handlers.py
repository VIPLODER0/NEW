from aiogram import Router, F
from aiogram.types import CallbackQuery, Message
from aiogram.fsm.context import FSMContext
from datetime import datetime
import html

from config import settings
from services.database import db
from services.payment_service import payment_service
from keyboards.user_kb import *
from utils.states import PaymentStates, UserStates
from utils.helpers import format_currency, format_datetime
from utils.logger import log_payment

router = Router()


@router.callback_query(F.data.startswith("pay_razorpay:"))
async def pay_with_razorpay(callback: CallbackQuery, state: FSMContext):
    """Initiate Razorpay payment"""
    user_id = callback.from_user.id
    quiz_id = callback.data.split(":")[1]
    
    # Check if payment already exists
    existing_payment = await db.db.payments.find_one({
        "user_id": user_id,
        "quiz_id": quiz_id,
        "payment_status": "success"
    })
    
    if existing_payment:
        await callback.answer("You already have an active payment for this quiz", show_alert=True)
        return
    
    # Create payment order
    payment_order = await payment_service.create_payment_order(user_id, quiz_id)
    
    if not payment_order:
        await callback.answer("Failed to create payment order", show_alert=True)
        return
    
    await state.set_state(PaymentStates.waiting_for_payment)
    await state.update_data({
        "payment_id": payment_order['payment_id'],
        "quiz_id": quiz_id,
        "order_id": payment_order['order_id']
    })
    
    payment_text = (
        f"💳 <b>Payment Details</b>\n\n"
        f"🆔 Order ID: {payment_order['order_id']}\n"
        f"💰 Amount: {format_currency(payment_order['amount'])}\n"
        f"⏳ Valid for: 24 hours\n\n"
        f"<b>Payment Instructions:</b>\n"
        f"1. Click the 'Pay Now' button below\n"
        f"2. Complete payment using Razorpay\n"
        f"3. Return here after payment\n"
        f"4. Click 'Verify Payment'\n\n"
        f"<b>Note:</b> Do not refresh or close this chat until payment is verified."
    )
    
    # In real implementation, you would create a Razorpay payment link
    # For demo, we'll use a mock verification
    
    await callback.message.edit_text(
        payment_text,
        parse_mode="HTML",
        reply_markup=get_payment_verification_keyboard(payment_order['payment_id'])
    )
    
    log_payment(payment_order['payment_id'], user_id, payment_order['amount'], "pending")
    await callback.answer()


@router.callback_query(F.data.startswith("verify_payment:"))
async def verify_payment(callback: CallbackQuery, state: FSMContext):
    """Verify payment"""
    user_id = callback.from_user.id
    payment_id = callback.data.split(":")[1]
    
    state_data = await state.get_data()
    stored_payment_id = state_data.get("payment_id")
    
    if stored_payment_id != payment_id:
        await callback.answer("Invalid payment session", show_alert=True)
        return
    
    # For demo, simulate successful payment
    # In production, you would verify with Razorpay webhook or API
    
    razorpay_payment_id = f"rzp_pay_{datetime.utcnow().strftime('%Y%m%d%H%M%S')}"
    razorpay_signature = f"sig_{datetime.utcnow().timestamp()}"
    
    success, message = await payment_service.verify_payment(
        payment_id, razorpay_payment_id, razorpay_signature
    )
    
    if success:
        await state.clear()
        
        # Get updated payment info
        payment = await db.db.payments.find_one({"id": payment_id})
        quiz_id = payment['quiz_id']
        
        await callback.message.edit_text(
            f"✅ <b>Payment Successful!</b>\n\n"
            f"💰 Amount: {format_currency(payment['amount'])}\n"
            f"🆔 Transaction ID: {razorpay_payment_id}\n"
            f"📅 Paid at: {format_datetime(payment['completed_at'])}\n"
            f"⏳ Valid until: {format_datetime(payment['expires_at'])}\n\n"
            f"🎉 You can now join the quiz!\n"
            f"Click 'Join Quiz' to start.",
            parse_mode="HTML",
            reply_markup=get_back_keyboard()
        )
        
        # Update user payment status
        await db.update_user(user_id, {
            "payment_status": True,
            "payment_expiry": payment['expires_at']
        })
    else:
        await callback.message.edit_text(
            f"❌ <b>Payment Verification Failed</b>\n\n"
            f"Error: {message}\n\n"
            f"Please try again or contact support.",
            parse_mode="HTML",
            reply_markup=get_back_keyboard()
        )
    
    await callback.answer()


@router.callback_query(F.data.startswith("pay_upi:"))
async def pay_with_upi(callback: CallbackQuery, state: FSMContext):
    """Initiate UPI payment"""
    user_id = callback.from_user.id
    quiz_id = callback.data.split(":")[1]
    
    await state.set_state(PaymentStates.processing_upi)
    await state.update_data({"quiz_id": quiz_id})
    
    upi_text = (
        f"📱 <b>UPI Payment</b>\n\n"
        f"Please send your UPI ID (e.g., username@upi) to proceed with payment.\n\n"
        f"<b>Instructions:</b>\n"
        f"1. Share your UPI ID\n"
        f"2. You'll receive payment request\n"
        f"3. Complete payment in your UPI app\n"
        f"4. Payment will be verified automatically\n\n"
        f"<b>Note:</b> Payment must be completed within 30 minutes."
    )
    
    await callback.message.edit_text(
        upi_text,
        parse_mode="HTML",
        reply_markup=get_back_keyboard("quiz")
    )
    await callback.answer()


@router.message(PaymentStates.processing_upi)
async def process_upi_id(message: Message, state: FSMContext):
    """Process UPI ID"""
    user_id = message.from_user.id
    upi_id = message.text.strip()
    
    state_data = await state.get_data()
    quiz_id = state_data.get("quiz_id")
    
    # Simple UPI validation
    if "@" not in upi_id or len(upi_id) < 5:
        await message.answer(
            "❌ Invalid UPI ID format.\n"
            "Please enter a valid UPI ID (e.g., username@upi):",
            reply_markup=get_back_keyboard("quiz")
        )
        return
    
    # Create UPI payment
    payment = await payment_service.create_upi_payment(user_id, quiz_id, upi_id)
    
    await state.clear()
    
    upi_payment_text = (
        f"📱 <b>UPI Payment Request Created</b>\n\n"
        f"🆔 Transaction ID: {payment['upi_transaction_id']}\n"
        f"💰 Amount: {format_currency(payment['amount'])}\n"
        f"📱 UPI ID: {upi_id}\n"
        f"⏳ Valid for: {payment['expires_in']} minutes\n\n"
        f"<b>Instructions:</b>\n"
        f"{payment['instructions']}\n\n"
        f"After payment, it will be verified automatically.\n"
        f"You'll receive a confirmation message."
    )
    
    await message.answer(
        upi_payment_text,
        parse_mode="HTML",
        reply_markup=get_back_keyboard()
    )
    
    log_payment(payment['payment_id'], user_id, payment['amount'], "pending_upi")


@router.callback_query(F.data.startswith("apply_coupon:"))
async def apply_coupon(callback: CallbackQuery, state: FSMContext):
    """Apply coupon code"""
    user_id = callback.from_user.id
    quiz_id = callback.data.split(":")[1]
    
    await state.set_state(UserStates.coupon_entry)
    await state.update_data({"quiz_id": quiz_id})
    
    await callback.message.edit_text(
        "🎫 <b>Apply Coupon Code</b>\n\n"
        "Enter your coupon code:\n\n"
        "<b>Available Coupons:</b>\n"
        "• WELCOME50 - 50% discount\n"
        "• QUIZ100 - ₹100 off\n"
        "• FIRSTFREE - Free first quiz\n\n"
        "Enter code:",
        parse_mode="HTML",
        reply_markup=get_back_keyboard("quiz")
    )
    await callback.answer()


@router.message(UserStates.coupon_entry)
async def process_coupon_code(message: Message, state: FSMContext):
    """Process coupon code"""
    user_id = message.from_user.id
    coupon_code = message.text.strip().upper()
    
    state_data = await state.get_data()
    quiz_id = state_data.get("quiz_id")
    
    # Process coupon
    success, message_text, details = await payment_service.process_coupon(
        user_id, quiz_id, coupon_code
    )
    
    await state.clear()
    
    if success:
        await message.answer(
            f"✅ <b>Coupon Applied Successfully!</b>\n\n"
            f"🎫 Code: {coupon_code}\n"
            f"💰 Original: {format_currency(details['original_amount'])}\n"
            f"🎁 Discount: {format_currency(details['discount_amount'])}\n"
            f"💳 Final: {format_currency(details['final_amount'])}\n\n"
            f"🎉 You can now join the quiz!\n"
            f"Payment valid for 24 hours.",
            parse_mode="HTML",
            reply_markup=get_back_keyboard()
        )
    else:
        await message.answer(
            f"❌ <b>Coupon Error</b>\n\n"
            f"Error: {message_text}\n\n"
            f"Please try a different code or use another payment method.",
            parse_mode="HTML",
            reply_markup=get_back_keyboard("quiz")
        )


@router.callback_query(F.data.startswith("use_wallet:"))
async def use_wallet(callback: CallbackQuery):
    """Use wallet balance for payment"""
    user_id = callback.from_user.id
    quiz_id = callback.data.split(":")[1]
    
    user = await db.get_user(user_id)
    if not user:
        await callback.answer("User not found", show_alert=True)
        return
    
    wallet_balance = user.get('wallet_balance', 0)
    quiz = await db.get_quiz_by_id(quiz_id)
    quiz_price = quiz.get('price', 0) if quiz else 0
    
    if wallet_balance >= quiz_price:
        # Create wallet payment
        payment_data = {
            "id": str(ObjectId()),
            "user_id": user_id,
            "quiz_id": quiz_id,
            "amount": quiz_price,
            "currency": "INR",
            "payment_method": "wallet",
            "payment_status": "success",
            "wallet_deduction": quiz_price,
            "created_at": datetime.utcnow(),
            "completed_at": datetime.utcnow(),
            "expires_at": datetime.utcnow() + timedelta(days=1)
        }
        
        payment = await db.create_payment(payment_data)
        
        # Deduct from wallet
        new_balance = wallet_balance - quiz_price
        await db.update_user(user_id, {
            "wallet_balance": new_balance,
            "payment_status": True,
            "payment_expiry": payment_data['expires_at']
        })
        
        await callback.message.edit_text(
            f"💰 <b>Wallet Payment Successful!</b>\n\n"
            f"📝 Quiz: {quiz.get('title', 'Unknown')}\n"
            f"💳 Amount: {format_currency(quiz_price)}\n"
            f"👛 New Balance: {format_currency(new_balance)}\n"
            f"⏳ Valid until: {format_datetime(payment_data['expires_at'])}\n\n"
            f"🎉 You can now join the quiz!",
            parse_mode="HTML",
            reply_markup=get_back_keyboard()
        )
        
        log_payment(payment['id'], user_id, quiz_price, "wallet_success")
    else:
        await callback.message.edit_text(
            f"❌ <b>Insufficient Wallet Balance</b>\n\n"
            f"💰 Required: {format_currency(quiz_price)}\n"
            f"👛 Available: {format_currency(wallet_balance)}\n"
            f"📉 Short by: {format_currency(quiz_price - wallet_balance)}\n\n"
            f"Please add money to your wallet or use another payment method.",
            parse_mode="HTML",
            reply_markup=get_back_keyboard("quiz")
        )
    
    await callback.answer()


@router.callback_query(F.data == "check_payment")
async def check_payment_status(callback: CallbackQuery):
    """Check payment status for current quiz"""
    user_id = callback.from_user.id
    
    active_quiz = await db.get_active_quiz()
    if not active_quiz:
        await callback.answer("No active quiz", show_alert=True)
        return
    
    quiz_id = active_quiz['id']
    payment_status = await payment_service.check_payment_status(user_id, quiz_id)
    
    status_text = (
        f"💳 <b>Payment Status Check</b>\n\n"
        f"📝 Quiz: {active_quiz['title']}\n"
        f"💰 Price: {format_currency(active_quiz.get('price', 0))}\n\n"
    )
    
    if payment_status['has_payment']:
        status_text += (
            f"✅ <b>Status: {payment_status['status'].upper()}</b>\n"
            f"{payment_status['message']}\n"
        )
        
        if payment_status.get('expires_at'):
            status_text += f"⏳ Expires: {format_datetime(payment_status['expires_at'])}\n"
        
        status_text += "\n🎉 You can join the quiz now!"
    else:
        status_text += (
            f"❌ <b>Status: {payment_status['status'].upper()}</b>\n"
            f"{payment_status['message']}\n\n"
            f"Please make a payment to join the quiz."
        )
    
    await callback.message.edit_text(
        status_text,
        parse_mode="HTML",
        reply_markup=get_back_keyboard("quiz")
    )
    await callback.answer()


def get_payment_verification_keyboard(payment_id: str):
    """Get payment verification keyboard"""
    from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
    from aiogram.utils.keyboard import InlineKeyboardBuilder
    
    builder = InlineKeyboardBuilder()
    
    # In production, this would be a Razorpay payment link
    builder.row(
        InlineKeyboardButton(
            text="💰 Pay Now (Demo)",
            callback_data=f"mock_payment:{payment_id}"
        )
    )
    
    builder.row(
        InlineKeyboardButton(
            text="✅ Verify Payment",
            callback_data=f"verify_payment:{payment_id}"
        ),
        InlineKeyboardButton(
            text="❌ Cancel",
            callback_data="cancel_payment"
        )
    )
    
    return builder.as_markup()


@router.callback_query(F.data.startswith("mock_payment:"))
async def mock_payment(callback: CallbackQuery):
    """Mock payment for demo"""
    await callback.answer(
        "This is a demo. In production, you would be redirected to Razorpay.\n"
        "Click 'Verify Payment' to simulate successful payment.",
        show_alert=True
    )


@router.callback_query(F.data == "cancel_payment")
async def cancel_payment(callback: CallbackQuery, state: FSMContext):
    """Cancel payment process"""
    await state.clear()
    await callback.message.edit_text(
        "❌ Payment cancelled.\n\n"
        "You can try again or use a different payment method.",
        reply_markup=get_back_keyboard("quiz")
    )
    await callback.answer()


# Add more payment handlers as needed...