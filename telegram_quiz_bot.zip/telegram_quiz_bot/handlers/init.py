from .user_handlers import router as user_router
from .admin_handlers import router as admin_router
from .quiz_handlers import router as quiz_router
from .payment_handlers import router as payment_router
from .errors import router as error_router

__all__ = [
    'user_router',
    'admin_router',
    'quiz_router',
    'payment_router',
    'error_router'
]