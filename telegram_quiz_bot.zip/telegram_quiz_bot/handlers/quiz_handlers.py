from aiogram import Router, F
from aiogram.types import CallbackQuery
from aiogram.fsm.context import FSMContext
from datetime import datetime
import asyncio

from config import settings
from services.database import db
from services.quiz_service import quiz_service
from services.payment_service import payment_service
from keyboards.user_kb import *
from keyboards.admin_kb import get_admin_actions_keyboard
from utils.states import UserStates
from utils.helpers import format_time, calculate_score
from utils.logger import log_user_action, log_quiz_event

router = Router()


@router.callback_query(F.data == "start_quiz")
async def start_quiz(callback: CallbackQuery, state: FSMContext):
    """Start quiz for user"""
    user_id = callback.from_user.id
    
    # Check maintenance mode
    if settings.MAINTENANCE_MODE:
        await callback.answer("Bot is under maintenance. Please try later.", show_alert=True)
        return
    
    # Get active quiz
    active_quiz = await db.get_active_quiz()
    if not active_quiz:
        await callback.answer("No active quiz available", show_alert=True)
        return
    
    quiz_id = active_quiz['id']
    
    # Check payment status
    payment_status = await payment_service.check_payment_status(user_id, quiz_id)
    if not payment_status['has_payment']:
        await callback.answer("Payment required. Please make payment first.", show_alert=True)
        return
    
    # Start quiz session
    session = await quiz_service.start_quiz_for_user(user_id, quiz_id)
    if not session:
        await callback.answer("Failed to start quiz. Please try again.", show_alert=True)
        return
    
    # Set state
    await state.set_state(UserStates.waiting_for_answer)
    await state.update_data({
        "session_id": session['id'],
        "quiz_id": quiz_id,
        "current_question": 0,
        "start_time": datetime.utcnow()
    })
    
    # Get first question
    question = await quiz_service.get_current_question(session['id'])
    
    if not question:
        await callback.answer("No questions available", show_alert=True)
        return
    
    question_text = (
        f"📝 <b>Question {question['question_number']}</b>\n\n"
        f"{question['question_text']}\n\n"
        f"⏰ Time limit: {question['time_limit']} seconds\n"
        f"📊 Options:"
    )
    
    await callback.message.edit_text(
        question_text,
        parse_mode="HTML",
        reply_markup=get_question_keyboard(question['options'], question['id'])
    )
    
    log_user_action(user_id, "started_quiz", {"quiz_id": quiz_id, "session_id": session['id']})
    await callback.answer()


@router.callback_query(F.data.startswith("answer:"))
async def process_answer(callback: CallbackQuery, state: FSMContext):
    """Process user's answer"""
    user_id = callback.from_user.id
    data_parts = callback.data.split(":")
    
    if len(data_parts) < 3:
        await callback.answer("Invalid answer", show_alert=True)
        return
    
    question_id = data_parts[1]
    selected_option = int(data_parts[2])
    
    # Get session data
    state_data = await state.get_data()
    session_id = state_data.get("session_id")
    
    if not session_id:
        await callback.answer("No active quiz session", show_alert=True)
        return
    
    # Submit answer
    success, result = await quiz_service.submit_answer(user_id, session_id, selected_option)
    
    if not success:
        await callback.answer("Failed to submit answer", show_alert=True)
        return
    
    if result.get("quiz_complete"):
        # Quiz completed
        await show_quiz_results(callback, state, session_id)
        return
    
    # Get next question
    question = await quiz_service.get_current_question(session_id)
    
    if not question:
        await callback.answer("Error loading next question", show_alert=True)
        return
    
    # Show result feedback
    is_correct = result.get("is_correct", False)
    feedback = "✅ Correct!" if is_correct else "❌ Wrong!"
    
    await callback.answer(feedback, show_alert=True)
    
    # Small delay before showing next question
    await asyncio.sleep(1)
    
    # Show next question
    question_text = (
        f"📝 <b>Question {question['question_number']}</b>\n\n"
        f"{question['question_text']}\n\n"
        f"⏰ Time limit: {question['time_limit']} seconds\n"
        f"📊 Options:"
    )
    
    await callback.message.edit_text(
        question_text,
        parse_mode="HTML",
        reply_markup=get_question_keyboard(question['options'], question['id'])
    )
    
    log_user_action(user_id, "answered_question", {
        "session_id": session_id,
        "question_id": question_id,
        "correct": is_correct
    })


@router.callback_query(F.data == "skip_question")
async def skip_question(callback: CallbackQuery, state: FSMContext):
    """Skip current question"""
    user_id = callback.from_user.id
    
    # Get session data
    state_data = await state.get_data()
    session_id = state_data.get("session_id")
    
    if not session_id:
        await callback.answer("No active quiz session", show_alert=True)
        return
    
    # Skip question
    success = await quiz_service.skip_question(user_id, session_id)
    
    if not success:
        await callback.answer("Failed to skip question", show_alert=True)
        return
    
    # Get next question or complete
    question = await quiz_service.get_current_question(session_id)
    
    if question:
        # Show next question
        question_text = (
            f"📝 <b>Question {question['question_number']}</b>\n\n"
            f"{question['question_text']}\n\n"
            f"⏰ Time limit: {question['time_limit']} seconds\n"
            f"📊 Options:"
        )
        
        await callback.message.edit_text(
            question_text,
            parse_mode="HTML",
            reply_markup=get_question_keyboard(question['options'], question['id'])
        )
    else:
        # Quiz completed
        await show_quiz_results(callback, state, session_id)
    
    await callback.answer("Question skipped")
    log_user_action(user_id, "skipped_question", {"session_id": session_id})


@router.callback_query(F.data == "end_quiz")
async def end_quiz(callback: CallbackQuery, state: FSMContext):
    """End quiz early"""
    user_id = callback.from_user.id
    
    # Get session data
    state_data = await state.get_data()
    session_id = state_data.get("session_id")
    
    if not session_id:
        await callback.answer("No active quiz session", show_alert=True)
        return
    
    # Confirm ending
    await callback.message.edit_text(
        "⏹️ <b>End Quiz?</b>\n\n"
        "Are you sure you want to end the quiz early?\n\n"
        "⚠️ All unanswered questions will be marked as wrong.",
        parse_mode="HTML",
        reply_markup=get_confirmation_keyboard("end_quiz", session_id)
    )
    await callback.answer()


@router.callback_query(F.data.startswith("confirm:end_quiz:"))
async def confirm_end_quiz(callback: CallbackQuery, state: FSMContext):
    """Confirm ending quiz"""
    user_id = callback.from_user.id
    session_id = callback.data.split(":")[2]
    
    # Complete quiz session
    session = await db.quiz_sessions.find_one({"id": session_id})
    if session and session['user_id'] == user_id:
        await quiz_service.complete_quiz_session(session_id, session.get('score', 0))
        await show_quiz_results(callback, state, session_id)
    
    await callback.answer()


async def show_quiz_results(callback: CallbackQuery, state: FSMContext, session_id: str):
    """Show quiz results to user"""
    user_id = callback.from_user.id
    
    # Clear state
    await state.clear()
    
    # Get session and results
    session = await db.quiz_sessions.find_one({"id": session_id})
    if not session or session['user_id'] != user_id:
        await callback.message.edit_text(
            "❌ Error loading results",
            reply_markup=get_back_keyboard()
        )
        return
    
    quiz_id = session['quiz_id']
    results = await quiz_service.get_quiz_results(user_id, quiz_id)
    
    if not results:
        await callback.message.edit_text(
            "❌ Results not available",
            reply_markup=get_back_keyboard()
        )
        return
    
    # Format results
    time_taken = results['time_taken']
    minutes = int(time_taken // 60)
    seconds = int(time_taken % 60)
    
    results_text = (
        f"🏁 <b>Quiz Completed!</b>\n\n"
        f"📊 <b>Your Results:</b>\n"
        f"   ✅ Correct: {results['correct']}/{results['total_questions']}\n"
        f"   ❌ Wrong: {results['wrong']}/{results['total_questions']}\n"
        f"   📈 Score: {results['score']:.1f}\n"
        f"   ⏱️ Time: {minutes}:{seconds:02d}\n"
        f"   🏆 Rank: #{results['rank'] if results['rank'] else 'N/A'}\n\n"
    )
    
    # Get leaderboard top 3
    leaderboard = await db.get_leaderboard(quiz_id, 3)
    
    if leaderboard:
        results_text += "🏆 <b>Top 3:</b>\n"
        for idx, entry in enumerate(leaderboard[:3], 1):
            username = entry.get('username') or entry.get('first_name', 'User')
            score = entry.get('score', 0)
            
            if idx == 1:
                medal = "🥇"
            elif idx == 2:
                medal = "🥈"
            else:
                medal = "🥉"
            
            results_text += f"{medal} {username}: {score:.1f} points\n"
    
    await callback.message.edit_text(
        results_text,
        parse_mode="HTML",
        reply_markup=get_results_keyboard(quiz_id)
    )
    
    log_user_action(user_id, "completed_quiz", {
        "quiz_id": quiz_id,
        "score": results['score'],
        "rank": results['rank']
    })


@router.callback_query(F.data.startswith("view_leaderboard:"))
async def view_quiz_leaderboard(callback: CallbackQuery):
    """View quiz leaderboard"""
    data_parts = callback.data.split(":")
    quiz_id = data_parts[1]
    
    # Get leaderboard
    leaderboard = await db.get_leaderboard(quiz_id, 20)
    
    if not leaderboard:
        await callback.answer("No leaderboard data available", show_alert=True)
        return
    
    # Paginate
    page = int(data_parts[2]) if len(data_parts) > 2 else 1
    paginated = paginate_items(leaderboard, page, 10)
    
    # Format leaderboard
    quiz = await db.get_quiz_by_id(quiz_id)
    quiz_title = quiz.get('title', 'Quiz') if quiz else 'Quiz'
    
    leaderboard_text = f"🏆 <b>Leaderboard - {quiz_title}</b>\n\n"
    
    start_rank = (page - 1) * 10 + 1
    for idx, entry in enumerate(paginated['items'], start_rank):
        username = entry.get('username') or entry.get('first_name', 'User')
        score = entry.get('score', 0)
        time_taken = entry.get('time_taken', 0)
        
        time_str = format_time(int(time_taken))
        
        if idx == 1:
            rank_emoji = "🥇"
        elif idx == 2:
            rank_emoji = "🥈"
        elif idx == 3:
            rank_emoji = "🥉"
        else:
            rank_emoji = f"{idx}."
        
        leaderboard_text += f"{rank_emoji} {username}: {score:.1f} points ({time_str})\n"
    
    # Add pagination info
    leaderboard_text += f"\n📄 Page {page} of {paginated['total_pages']}"
    
    await callback.message.edit_text(
        leaderboard_text,
        parse_mode="HTML",
        reply_markup=get_leaderboard_navigation(quiz_id, page, paginated['total_pages'])
    )
    await callback.answer()


@router.callback_query(F.data.startswith("detailed_results:"))
async def detailed_results(callback: CallbackQuery):
    """Show detailed results"""
    quiz_id = callback.data.split(":")[1]
    user_id = callback.from_user.id
    
    results = await quiz_service.get_quiz_results(user_id, quiz_id)
    
    if not results:
        await callback.answer("No detailed results available", show_alert=True)
        return
    
    # Get quiz session for answer details
    session = await db.quiz_sessions.find_one({
        "user_id": user_id,
        "quiz_id": quiz_id,
        "status": "completed"
    })
    
    detailed_text = (
        f"📋 <b>Detailed Results</b>\n\n"
        f"📊 Performance Summary:\n"
        f"   ✅ Correct Answers: {results['correct']}\n"
        f"   ❌ Wrong Answers: {results['wrong']}\n"
        f"   📈 Total Score: {results['score']:.1f}\n"
        f"   🏆 Overall Rank: #{results['rank'] if results['rank'] else 'N/A'}\n\n"
    )
    
    if session and 'answers' in session:
        detailed_text += "<b>Question-wise Performance:</b>\n"
        
        # Get questions for this quiz
        questions = await db.get_questions_by_quiz(quiz_id)
        
        for idx, answer in enumerate(session['answers'][:10]):  # Show first 10
            if idx < len(questions):
                q_text = questions[idx]['question_text'][:50]
                if len(q_text) == 50:
                    q_text += "..."
                
                status = "✅" if answer.get('is_correct') else "❌"
                detailed_text += f"{status} Q{idx+1}: {q_text}\n"
    
    await callback.message.edit_text(
        detailed_text,
        parse_mode="HTML",
        reply_markup=get_back_keyboard("results")
    )
    await callback.answer()


@router.callback_query(F.data == "my_stats")
async def my_detailed_stats(callback: CallbackQuery):
    """Show user's detailed statistics"""
    user_id = callback.from_user.id
    
    # Get user stats
    stats = await db.get_user_stats(user_id)
    user = await db.get_user(user_id)
    
    if not stats or not user:
        await callback.answer("No statistics available", show_alert=True)
        return
    
    # Get recent quizzes
    sessions = await db.db.quiz_sessions.find({
        "user_id": user_id,
        "status": "completed"
    }).sort("end_time", -1).limit(5).to_list(length=5)
    
    stats_text = (
        f"📈 <b>Your Statistics</b>\n\n"
        f"👤 User: {user.get('first_name', 'User')}\n"
        f"📅 Member since: {format_datetime(user.get('joined_date'))}\n\n"
        f"🏆 <b>Overall Performance:</b>\n"
        f"   📋 Total Quizzes: {stats.get('total_quizzes', 0)}\n"
        f"   📈 Average Score: {stats.get('average_score', 0):.1f}\n"
        f"   ⏱️ Average Time: {stats.get('average_time', 0):.0f}s\n"
        f"   💰 Total Points: {stats.get('total_score', 0):.0f}\n\n"
    )
    
    if sessions:
        stats_text += "<b>Recent Quizzes:</b>\n"
        for session in sessions:
            quiz = await db.get_quiz_by_id(session['quiz_id'])
            quiz_name = quiz.get('title', 'Unknown Quiz') if quiz else 'Unknown Quiz'
            
            stats_text += (
                f"• {quiz_name}: {session.get('score', 0):.1f} points\n"
            )
    
    await callback.message.edit_text(
        stats_text,
        parse_mode="HTML",
        reply_markup=get_back_keyboard("results")
    )
    await callback.answer()


@router.callback_query(F.data == "next_quiz")
async def next_quiz(callback: CallbackQuery):
    """Show next available quiz"""
    # Get active quiz
    active_quiz = await db.get_active_quiz()
    
    if active_quiz:
        await join_quiz(callback, None)
    else:
        await callback.message.edit_text(
            "📭 No active quiz at the moment.\n\n"
            "Please check back later or wait for announcements.\n"
            "You can check 'Payment Status' to ensure you're ready for the next quiz.",
            reply_markup=get_back_keyboard()
        )
    
    await callback.answer()


# Add more quiz handlers as needed...