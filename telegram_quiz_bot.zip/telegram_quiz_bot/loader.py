from aiogram import Bot, Dispatcher
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.fsm.storage.redis import RedisStorage, DefaultKeyBuilder
from config import settings
import redis.asyncio as redis
import logging

from handlers import (
    user_router,
    admin_router,
    quiz_router,
    payment_router,
    error_router
)
from middlewares.throttling import ThrottlingMiddleware


async def create_redis_storage():
    """Create Redis storage for FSM"""
    redis_client = await redis.from_url(settings.REDIS_URL)
    storage = RedisStorage(
        redis=redis_client,
        key_builder=DefaultKeyBuilder(with_bot_id=True, with_destiny=True)
    )
    return storage


async def get_dispatcher():
    """Create and configure dispatcher"""
    # Create storage
    storage = MemoryStorage()  # Use MemoryStorage for simplicity
    # For production: storage = await create_redis_storage()
    
    # Create dispatcher
    dp = Dispatcher(storage=storage)
    
    # Include routers
    dp.include_router(user_router)
    dp.include_router(admin_router)
    dp.include_router(quiz_router)
    dp.include_router(payment_router)
    dp.include_router(error_router)
    
    # Register middleware
    dp.message.middleware(ThrottlingMiddleware())
    dp.callback_query.middleware(ThrottlingMiddleware())
    
    return dp


async def get_bot():
    """Create bot instance"""
    bot = Bot(token=settings.BOT_TOKEN, parse_mode="HTML")
    return bot